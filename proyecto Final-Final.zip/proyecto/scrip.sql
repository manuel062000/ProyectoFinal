
DROP DATABASE IF EXISTS Proyecto;
CREATE DATABASE  Proyecto;
USE Proyecto;
CREATE TABLE Persona(
    idPersona INT UNSIGNED NOT NULL AUTO_INCREMENT,
    idMunicipio INT UNSIGNED NOT NULL,
    img TEXT NOT NULL,/*solo se guardara la ruta de la img*/
    DUI VARCHAR(10) NOT NULL,
    nombre VARCHAR(50) NOT NULL,
    apellido VARCHAR(50) NOT NULL,
    fecha_nac date NOT NULL,
    fecha_expe_dui date NOT NULL,
    genero VARCHAR(1) NOT NULL,
    direccion TEXT NOT NULL,
    estadoCivil VARCHAR(50),
    salvadorenoPor VARCHAR(15) NOT NULL,
    voto bit DEFAULT 0 NOT NULL,
    estado bit DEFAULT 1 NOT NULL,
    PRIMARY KEY(idPersona)
);
CREATE TABLE Departamento(
    idDepartamento INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(12) NOT NULL,
    PRIMARY KEY(idDepartamento)
);
CREATE TABLE Municipio(
    idMunicipio INT UNSIGNED NOT NULL AUTO_INCREMENT,
    idDepartamento INT UNSIGNED NOT NULL,
    nombre VARCHAR(40) NOT NULL,
    nombreCentroVotacion VARCHAR(40) NOT NULL,
    estado bit DEFAULT 1 NOT NULL,
    PRIMARY KEY(idMunicipio)
);
CREATE TABLE Usuario(
    idUsuario INT UNSIGNED NOT NULL AUTO_INCREMENT,
    idPersona INT UNSIGNED NOT NULL,
    rol VARCHAR(50) NOT NULL,
    correo TEXT NOT NULL,
    contrasena VARCHAR(200) NOT NULL,
    cadenaVerificacion varchar(50) NOT NULL,
    verificacion varchar(11) DEFAULT 'DESACTIVADO' NOT NULL,
    estado bit DEFAULT 1 NOT NULL,
    PRIMARY KEY(idUsuario)
);
CREATE TABLE Partido(
    idPartido INT UNSIGNED NOT NULL AUTO_INCREMENT,
    idPersona INT UNSIGNED NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    abreviacion VARCHAR(15),
    img TEXT NOT NULL,/*solo se guardara la ruta de la img*/
    estado bit DEFAULT 1 NOT NULL,
    PRIMARY KEY(idPartido)
);
CREATE TABLE JuntaReceptora(
    idJuntaReceptora INT UNSIGNED NOT NULL AUTO_INCREMENT,
    idMunicipio INT UNSIGNED NOT NULL,
    nombre VARCHAR(50),
    estado bit DEFAULT 1 NOT NULL,
    PRIMARY KEY(idJuntaReceptora)
);
CREATE TABLE Votos( 
    idVotos INT UNSIGNED NOT NULL AUTO_INCREMENT,
    idPartido INT UNSIGNED NOT NULL,
    idJuntaReceptora INT UNSIGNED NOT NULL,
    PRIMARY KEY(idVotos)
);
CREATE TABLE Historial( 
    idHistorial INT UNSIGNED NOT NULL AUTO_INCREMENT,
    idUsuario INT UNSIGNED NOT NULL,
    id INT UNSIGNED NOT NULL,
    tipo INT NOT NULL,
    modificacion varchar(20),
    fecha date NOT NULL,
    PRIMARY KEY(idHistorial)
);
/*--------------------------------------------------------------*/
/*--------------------------------------------------------------*/

/*-------------------LLAVES FORANEAS---------------------------*/
alter table Historial add CONSTRAINT FK_Historial_usuario FOREIGN key(idUsuario)REFERENCES Usuario(idUsuario);

alter table Usuario add CONSTRAINT FK_Usuario_Persona FOREIGN key(idPersona)REFERENCES Persona(idPersona);
alter table Persona add CONSTRAINT FK_Persona_Municipio FOREIGN key(idMunicipio)REFERENCES Municipio(idMunicipio);
alter table Partido add CONSTRAINT FK_Partido_Persona FOREIGN key(idPersona)REFERENCES Persona(idPersona);
alter table JuntaReceptora add CONSTRAINT FK_JuntaReceptora_municipio FOREIGN key(idMunicipio)REFERENCES Municipio(idMunicipio);
alter table Municipio add CONSTRAINT FK_Municipio_Departamento FOREIGN key(idDepartamento)REFERENCES Departamento(idDepartamento);
alter table Votos add CONSTRAINT FK_Votos_Partido FOREIGN key(idPartido)REFERENCES Partido(idPartido);
alter table Votos add CONSTRAINT FK_Votos_JuntaReceptora FOREIGN key(idJuntaReceptora)REFERENCES JuntaReceptora(idJuntaReceptora);
/*--------------------------------------------------------------*/
/*--------------------------------------------------------------*/
/*--------------------insercion de datos------------------------*/
INSERT INTO departamento VALUES 
(null,'SONSONATE'),(null,'AHUACHAPAN'),(null,'CABAÑAS'),(null,'CHALATENANGO'),(null,'CUSCATLAN'),
(null,'MORAZAN'),(null,'LA LIBERTAD'),(null,'LA PAZ'),(null,'LA UNION'),(null,'SAN MIGUEL'),
(null,'SAN SALVADOR'),(null,'SAN VICENTE'),(null,'SANTA ANA'),(null,'USULUTAN');


INSERT INTO municipio values(1,1,'SONSONATE','CV-SONSONATE',1),(2,1,'ACAJUTLA','CV-ACAJUTLA',1),
(3,1,'ARMENIA','CV-ARMENIA',1),(4,1,'CALUCO','CV-CALUCO',1),(5,1,'CUISNAHUAT','CV-CUISNAHUAT',1),
(6,1,'IZALCO','CV-IZALCO',1),(7,1,'JUAYUA','CV-JUAYUA',1),(8,1,'NAHULINGO','CV-NAHULINGO',1),
(9,1,'NAHUIZALCO','CV-NAHUIZALCO',1),

(10,2,'AHUACHAPAN','CV-AHUACHAPAN',1),(11,2,'APANECA','CV-APANECA',1),(12,2,'ATIQUIZAYA','CV-ATIQUIZAYA',1),
(13,2,'EL REFUGIO','CV-EL REFUGIO',1),(14,2,'JUJUTLA','CV-JUJUTLA',1),(15,2,'SAN LORENZO','CV-SAN LORENZO',1),

(16,3,'SENSUNTEPEQUE','CV-SENSUNTEPEQUE',1),(17,3,'CINQUERA','CV-CINQUERA',1),(18,3,'DOLORES','CV-DOLORES',1),
(19,3,'GUACOTECTI','CV-GUACOTECTI',1),(20,3,'ILOBASCO','CV-ILOBASCO',1),(21,3,'JUTIAPA','CV-JUTIAPA',1),

(22,4,'ARCATAO','CV-ARCATAO',1),(23,4,'CITALA','CV-CITALA',1),(24,4,'EL CARRIZAL','CV-EL CARRIZAL',1),
(25,4,'EL PARAISO','CV-EL PARAISO',1),(26,4,'LA LAGUNA','CV-LA LAGUNA',1),(27,4,'LA PALMA','CV-LA PALMA',1),

(28,5,'COJUTEPEQUE','CV-COJUTEPEQUE',1),(29,5,'CANDELARIA','CV-CANDELARIA',1),(30,5,'EL CARMEN','CV-EL CARMEN',1),
(31,5,'EL ROSARIO','CV-EL ROSARIO',1),(32,5,'SAN RAMON','CV-SAN RAMON',1),(33,5,'SUCHITOTO','CV-SUCHITOTO',1),

(34,6,'ARAMBALA','CV-ARAMBALA',1),(35,6,'CACAOPERA','CV-CACAOPERA',1),(36,6,'CHILANGA','CV-CHILANGA',1),
(37,6,'CORINTO','CV-CORINTO',1),(38,6,'EL ROSARIO','CV-EL ROSARIO',1),(39,6,'JOCORO','CV-JOCORO',1),

(40,7,'SANTA TECLA','CV-SANTA TECLA',1),(41,7,'ANTIGUO CUSCATLAN','CV-ANTIGUO CUSCATLAN',1),
(42,7,'COLON','CV-COLON',1),(43,7,'CHILTIUPAN','CV-CHILTIUPAN',1),(44,7,'CIUDAD ARCE','CV-CIUDAD ARCE',1),

(45,8,'ZACATECOLUCA','CV-ZACATECOLUCA',1),(46,8,'CUYULTITAN','CV-CUYULTITAN',1),(47,8,'EL ROSARIO','CV-EL ROSARIO',1),
(48,8,'JERUSALEN','CV-JERUSALEN',1),(49,8,'SAN EMIGDIO','CV-SAN EMIGDIO',1),(50,8,'TAPALHUACA','CV-TAPALHUACA',1),

(51,9,'LA UNION','CV-LA UNION',1),(52,9,'ANAMOROS','CV-ANAMOROS',1),(53,9,'CONCHAGUA','CV-CONCHAGUA',1),
(54,9,'EL CARMEN','CV-EL CARMEN',1),(55,9,'EL SAUCE','CV-EL SAUCE',1),(56,9,'LISLIQUE','CV-LISLIQUE',1),

(57,10,'SAN MIGUEL','CV-SAN MIGUEL',1),(58,10,'CAROLINA','CV-CAROLINA',1),(59,10,'CHAPELTIQUE','CV-CHAPELTIQUE',1),
(60,10,'CHINAMECA','CV-CHINAMECA',1),(61,10,'CHIRILAGUA','CV-CHIRILAGUA',1),(62,10,'EL TRANSITO','CV-EL TRANSITO',1),

(63,11,'SAN SALVADOR','CV-SAN SALVADOR',1),(64,11,'AGUILARES','CV-AGUILARES',1),(65,11,'APOPA','CV-APOPA',1),
(66,11,'CUSCATANCINGO','CV-CUSCATANCINGO',1),(67,11,'DELGADO','CV-DELGADO',1),(68,11,'EL PAISNAL','CV-EL PAISNAL',1),

(69,12,'SAN VICENTE','CV-SAN VICENTE',1),(70,12,'APASTEPEQUE','CV-APASTEPEQUE',1),(71,12,'GUADALUPE','CV-GUADALUPE',1),
(72,12,'TECOLUCA','CV-TECOLUCA',1),(73,12,'TEPETITAN','CV-TEPETITAN',1),(74,12,'VERAPAZ','CV-VERAPAZ',1),

(75,13,'SANTA ANA','CV-SANTA ANA',1),(76,13,'CHALCHUAPA','CV-CHALCHUAPA',1),(77,13,'COATEPEQUE','CV-COATEPEQUE',1),
(78,13,'EL CONGO','CV-EL CONGO',1),(79,13,'EL PORVENIR','CV-EL PORVENIR',1),(80,13,'METAPAN','CV-METAPAN',1),

(81,14,'USULUTAN','CV-USULUTAN',1),(82,14,'ALEGRIA','CV-ALEGRIA',1),(83,14,'BERLIN','CV-BERLIN',1),
(84,14,'EL TRIUNFO','CV-EL TRIUNFO',1),(85,14,'TECAPAN','CV-TECAPAN',1),(86,14,'SANTA ELENA','CV-SANTA ELENA',1);



INSERT INTO juntaReceptora values
(null,1,'JR-1',1),(null,1,'JR-2',1),(null,1,'JR-3',1),(null,1,'JR-4',1),
(null,2,'JR-1',1),(null,2,'JR-2',1),(null,2,'JR-3',1),(null,2,'JR-4',1),
(null,3,'JR-1',1),(null,3,'JR-2',1),(null,3,'JR-3',1),(null,3,'JR-4',1),
(null,4,'JR-1',1),(null,4,'JR-2',1),(null,4,'JR-3',1),(null,4,'JR-4',1),
(null,5,'JR-1',1),(null,5,'JR-2',1),(null,5,'JR-3',1),(null,5,'JR-4',1),
(null,6,'JR-1',1),(null,6,'JR-2',1),(null,6,'JR-3',1),(null,6,'JR-4',1),
(null,7,'JR-1',1),(null,7,'JR-2',1),(null,7,'JR-3',1),(null,7,'JR-4',1),
(null,8,'JR-1',1),(null,8,'JR-2',1),(null,8,'JR-3',1),(null,8,'JR-4',1),
(null,9,'JR-1',1),(null,9,'JR-2',1),(null,9,'JR-3',1),(null,9,'JR-4',1),
(null,10,'JR-1',1),(null,10,'JR-2',1),(null,10,'JR-3',1),(null,10,'JR-4',1),
(null,11,'JR-1',1),(null,11,'JR-2',1),(null,11,'JR-3',1),(null,11,'JR-4',1),
(null,12,'JR-1',1),(null,12,'JR-2',1),(null,12,'JR-3',1),(null,12,'JR-4',1),
(null,13,'JR-1',1),(null,13,'JR-2',1),(null,13,'JR-3',1),(null,13,'JR-4',1),
(null,14,'JR-1',1),(null,14,'JR-2',1),(null,14,'JR-3',1),(null,14,'JR-4',1),
(null,15,'JR-1',1),(null,15,'JR-2',1),(null,15,'JR-3',1),(null,15,'JR-4',1),
(null,16,'JR-1',1),(null,16,'JR-2',1),(null,16,'JR-3',1),(null,16,'JR-4',1),
(null,17,'JR-1',1),(null,17,'JR-2',1),(null,17,'JR-3',1),(null,17,'JR-4',1),
(null,18,'JR-1',1),(null,18,'JR-2',1),(null,18,'JR-3',1),(null,18,'JR-4',1),
(null,19,'JR-1',1),(null,19,'JR-2',1),(null,19,'JR-3',1),(null,19,'JR-4',1),
(null,20,'JR-1',1),(null,20,'JR-2',1),(null,20,'JR-3',1),(null,20,'JR-4',1),
(null,21,'JR-1',1),(null,21,'JR-2',1),(null,21,'JR-3',1),(null,21,'JR-4',1),
(null,22,'JR-1',1),(null,22,'JR-2',1),(null,22,'JR-3',1),(null,22,'JR-4',1),
(null,23,'JR-1',1),(null,23,'JR-2',1),(null,23,'JR-3',1),(null,23,'JR-4',1),
(null,24,'JR-1',1),(null,24,'JR-2',1),(null,24,'JR-3',1),(null,24,'JR-4',1),
(null,25,'JR-1',1),(null,25,'JR-2',1),(null,25,'JR-3',1),(null,25,'JR-4',1),
(null,26,'JR-1',1),(null,26,'JR-2',1),(null,26,'JR-3',1),(null,26,'JR-4',1),
(null,27,'JR-1',1),(null,27,'JR-2',1),(null,27,'JR-3',1),(null,27,'JR-4',1),
(null,28,'JR-1',1),(null,28,'JR-2',1),(null,28,'JR-3',1),(null,28,'JR-4',1),
(null,29,'JR-1',1),(null,29,'JR-2',1),(null,29,'JR-3',1),(null,29,'JR-4',1),
(null,30,'JR-1',1),(null,30,'JR-2',1),(null,30,'JR-3',1),(null,30,'JR-4',1),
(null,31,'JR-1',1),(null,31,'JR-2',1),(null,31,'JR-3',1),(null,31,'JR-4',1),
(null,32,'JR-1',1),(null,32,'JR-2',1),(null,32,'JR-3',1),(null,32,'JR-4',1),
(null,33,'JR-1',1),(null,33,'JR-2',1),(null,33,'JR-3',1),(null,33,'JR-4',1),
(null,34,'JR-1',1),(null,34,'JR-2',1),(null,34,'JR-3',1),(null,34,'JR-4',1),
(null,35,'JR-1',1),(null,35,'JR-2',1),(null,35,'JR-3',1),(null,35,'JR-4',1),
(null,36,'JR-1',1),(null,36,'JR-2',1),(null,36,'JR-3',1),(null,36,'JR-4',1),
(null,37,'JR-1',1),(null,37,'JR-2',1),(null,37,'JR-3',1),(null,37,'JR-4',1),
(null,38,'JR-1',1),(null,38,'JR-2',1),(null,38,'JR-3',1),(null,38,'JR-4',1),
(null,39,'JR-1',1),(null,39,'JR-2',1),(null,39,'JR-3',1),(null,39,'JR-4',1),
(null,40,'JR-1',1),(null,40,'JR-2',1),(null,40,'JR-3',1),(null,40,'JR-4',1),
(null,41,'JR-1',1),(null,41,'JR-2',1),(null,41,'JR-3',1),(null,41,'JR-4',1),
(null,42,'JR-1',1),(null,42,'JR-2',1),(null,42,'JR-3',1),(null,42,'JR-4',1),
(null,43,'JR-1',1),(null,43,'JR-2',1),(null,43,'JR-3',1),(null,43,'JR-4',1),
(null,44,'JR-1',1),(null,44,'JR-2',1),(null,44,'JR-3',1),(null,44,'JR-4',1),
(null,45,'JR-1',1),(null,45,'JR-2',1),(null,45,'JR-3',1),(null,45,'JR-4',1),
(null,46,'JR-1',1),(null,46,'JR-2',1),(null,46,'JR-3',1),(null,46,'JR-4',1),
(null,47,'JR-1',1),(null,47,'JR-2',1),(null,47,'JR-3',1),(null,47,'JR-4',1),
(null,48,'JR-1',1),(null,48,'JR-2',1),(null,48,'JR-3',1),(null,48,'JR-4',1),
(null,49,'JR-1',1),(null,49,'JR-2',1),(null,49,'JR-3',1),(null,49,'JR-4',1),
(null,50,'JR-1',1),(null,50,'JR-2',1),(null,50,'JR-3',1),(null,50,'JR-4',1),
(null,51,'JR-1',1),(null,51,'JR-2',1),(null,51,'JR-3',1),(null,51,'JR-4',1),
(null,52,'JR-1',1),(null,52,'JR-2',1),(null,52,'JR-3',1),(null,52,'JR-4',1),
(null,53,'JR-1',1),(null,53,'JR-2',1),(null,53,'JR-3',1),(null,53,'JR-4',1),
(null,54,'JR-1',1),(null,54,'JR-2',1),(null,54,'JR-3',1),(null,54,'JR-4',1),
(null,55,'JR-1',1),(null,55,'JR-2',1),(null,55,'JR-3',1),(null,55,'JR-4',1),
(null,56,'JR-1',1),(null,56,'JR-2',1),(null,56,'JR-3',1),(null,56,'JR-4',1),
(null,57,'JR-1',1),(null,57,'JR-2',1),(null,57,'JR-3',1),(null,57,'JR-4',1),
(null,58,'JR-1',1),(null,58,'JR-2',1),(null,58,'JR-3',1),(null,58,'JR-4',1),
(null,59,'JR-1',1),(null,59,'JR-2',1),(null,59,'JR-3',1),(null,59,'JR-4',1),
(null,60,'JR-1',1),(null,60,'JR-2',1),(null,60,'JR-3',1),(null,60,'JR-4',1),
(null,61,'JR-1',1),(null,61,'JR-2',1),(null,61,'JR-3',1),(null,61,'JR-4',1),
(null,62,'JR-1',1),(null,62,'JR-2',1),(null,62,'JR-3',1),(null,62,'JR-4',1),
(null,63,'JR-1',1),(null,63,'JR-2',1),(null,63,'JR-3',1),(null,63,'JR-4',1),
(null,64,'JR-1',1),(null,64,'JR-2',1),(null,64,'JR-3',1),(null,64,'JR-4',1),
(null,65,'JR-1',1),(null,65,'JR-2',1),(null,65,'JR-3',1),(null,65,'JR-4',1),
(null,66,'JR-1',1),(null,66,'JR-2',1),(null,66,'JR-3',1),(null,66,'JR-4',1),
(null,67,'JR-1',1),(null,67,'JR-2',1),(null,67,'JR-3',1),(null,67,'JR-4',1),
(null,68,'JR-1',1),(null,68,'JR-2',1),(null,68,'JR-3',1),(null,68,'JR-4',1),
(null,69,'JR-1',1),(null,69,'JR-2',1),(null,69,'JR-3',1),(null,69,'JR-4',1),
(null,70,'JR-1',1),(null,70,'JR-2',1),(null,70,'JR-3',1),(null,70,'JR-4',1),
(null,71,'JR-1',1),(null,71,'JR-2',1),(null,71,'JR-3',1),(null,71,'JR-4',1),
(null,72,'JR-1',1),(null,72,'JR-2',1),(null,72,'JR-3',1),(null,72,'JR-4',1),
(null,73,'JR-1',1),(null,73,'JR-2',1),(null,73,'JR-3',1),(null,73,'JR-4',1),
(null,74,'JR-1',1),(null,74,'JR-2',1),(null,74,'JR-3',1),(null,74,'JR-4',1),
(null,75,'JR-1',1),(null,75,'JR-2',1),(null,75,'JR-3',1),(null,75,'JR-4',1),
(null,76,'JR-1',1),(null,76,'JR-2',1),(null,76,'JR-3',1),(null,76,'JR-4',1),
(null,77,'JR-1',1),(null,77,'JR-2',1),(null,77,'JR-3',1),(null,77,'JR-4',1),
(null,78,'JR-1',1),(null,78,'JR-2',1),(null,78,'JR-3',1),(null,78,'JR-4',1),
(null,79,'JR-1',1),(null,79,'JR-2',1),(null,79,'JR-3',1),(null,79,'JR-4',1),
(null,80,'JR-1',1),(null,80,'JR-2',1),(null,80,'JR-3',1),(null,80,'JR-4',1),
(null,81,'JR-1',1),(null,81,'JR-2',1),(null,81,'JR-3',1),(null,81,'JR-4',1),
(null,82,'JR-1',1),(null,82,'JR-2',1),(null,82,'JR-3',1),(null,82,'JR-4',1),
(null,83,'JR-1',1),(null,83,'JR-2',1),(null,83,'JR-3',1),(null,83,'JR-4',1),
(null,84,'JR-1',1),(null,84,'JR-2',1),(null,84,'JR-3',1),(null,84,'JR-4',1),
(null,85,'JR-1',1),(null,85,'JR-2',1),(null,85,'JR-3',1),(null,85,'JR-4',1),
(null,86,'JR-1',1),(null,86,'JR-2',1),(null,86,'JR-3',1),(null,86,'JR-4',1);

INSERT INTO persona values(null,1,'usuario.png','12345678-0','JUAN JOSE','PEREZ PEREZ','1999/06/24','2021/03/15',
'M','29 AV SUR COL 14 DICIEMBRE','VIUDO(A)','NACIMIENTO',0,1),
(null,10,'usuario.png','98453672-0','MANUEL ALEXANDER','DELGADO HENRRIQUEZ','2000/06/29','2021/03/15',
'M','29 AV SUR COL 14 DICIEMBRE','SOLTERO(A)','NACIMIENTO',0,1),
(null,19,'usuario.png','64530976-0','ANDREA ARACELI','RIVERA AQUINO','1999/07/10','2021/03/15',
'F','29 AV SUR COL 14 DICIEMBRE','SOLTERO(A)','NACIMIENTO',0,1),
(null,22,'usuario.png','98735614-0','ANGELA YAMILETH','SANTOS MOLINA','2000/04/02','2021/03/15',
'F','29 AV SUR COL 14 DICIEMBRE','SOLTERO(A)','NACIMIENTO',0,1),
(null,31,'usuario.png','76409274-0','ALDAIR','TORRES GONSALES','1995/12/20','2021/03/15',
'M','29 AV SUR COL 14 DICIEMBRE','CASADO(A)','NACIMIENTO',0,1),
(null,37,'usuario.png','97532678-0','JONATHAN MISAEL','SOLIS','1990/11/10','2021/03/15',
'M','29 AV SUR COL 14 DICIEMBRE','CASADO(A)','NATURALIZACION',0,1),
(null,42,'usuario.png','85372453-9','MARIA MIREYA','ACEVEDO MANRIQUEZ','1990/11/10','2021/03/15',
'F','29 AV SUR COL 14 DICIEMBRE','CASADO(A)','NATURALIZACION',0,1),
(null,48,'usuario.png','07453725-0','OSCAR GUILLERMO','ALVARADO MENDOZA','1990/11/10','2021/03/15',
'M','29 AV SUR COL 14 DICIEMBRE','CASADO(A)','NATURALIZACION',0,1),
(null,54,'usuario.png','54637284-9','JAVIER LEONARDO','VINAS','1990/11/10','2021/03/15',
'M','29 AV SUR COL 14 DICIEMBRE','CASADO(A)','NATURALIZACION',0,1),
(null,60,'usuario.png','54639132-4','SANDRA','FERNANDEZ CASTILLO','1990/11/10','2021/03/15',
'F','29 AV SUR COL 14 DICIEMBRE','CASADO(A)','NATURALIZACION',0,1),
(null,66,'usuario.png','43520973-6','BRENDA MARCELA','GARCIA LOPEZ','1990/11/10','2021/03/15',
'F','29 AV SUR COL 14 DICIEMBRE','CASADO(A)','NATURALIZACION',0,1),
(null,72 ,'usuario.png','54639842-6','HECTOR ARMANDO','DIAZ NUÑEZ','1990/11/10','2021/03/15',
'M','29 AV SUR COL 14 DICIEMBRE','CASADO(A)','NATURALIZACION',0,1);


INSERT INTO partido values(null,1,'partido politico 1','pp1','bandera-default.jpg',1),
(null,2,'partido politico 2','pp2','bandera-default.jpg',1),
(null,3,'partido politico 3','pp3','bandera-default.jpg',1),
(null,4,'partido politico 4','pp4','bandera-default.jpg',1);

INSERT INTO usuario values
(null,1,'ADMINISTRADOR','manuelalexander10horas@gmail.com','$argon2i$v=19$m=2048,t=4,p=3$cTBmRzdUaS9ZSnlxZ3REbQ$at7z6c6MqqDhzvyc2HlLdRzJrG70U+E9ZKXA69k1qZU','1234','VERIFICADO',1),
(null,2,'CO-ADMINISTRADOR','alexanderhenrriquez40@gmail.com','$argon2i$v=19$m=2048,t=4,p=3$ZWEvbjJnWkVrVnZiZ09hSQ$umIaIcyA7MqlnsTRl5BbwMzrINZKzXh3P/8fe9+tY+0','1234','VERIFICADO',1);
/*--------------------------------------------------------------*/
/*--------------------------------------------------------------*/

/*-----------------procedimientos almacenados CV-------------------*/
DELIMITER $$
CREATE PROCEDURE SP_agregar_CV (
    IN idDepartamento int,
    IN nombre varchar(50),
    IN nombreCV varchar(50))
BEGIN
INSERT INTO municipio VALUES (null,idDepartamento,nombre,nombreCV, 1);
END
$$
DELIMITER;
--------------
DELIMITER $$
CREATE PROCEDURE SP_eliminar_CV (
    IN idM INT)
BEGIN
UPDATE municipio SET estado=0 
WHERE idMunicipio=idM;
END
$$
--------------
DELIMITER $$
CREATE PROCEDURE SP_modificar_CV (
    IN idM INT,
    IN idD INT,
    IN Nombre varchar(50),
    IN NombreCV varchar(50))
BEGIN
UPDATE municipio SET idDepartamento=idD,nombre=Nombre,nombreCentroVotacion=NombreCV 
WHERE idMunicipio=idM;
END
$$
--------------
DELIMITER $$
CREATE PROCEDURE SP_getSearch_CV (
    IN nomMuni varchar(100))
BEGIN
SELECT m.idMunicipio,m.idDepartamento,d.nombre as nombreDepartamento,m.nombre,m.nombreCentroVotacion 
FROM municipio as m INNER JOIN departamento as d 
WHERE m.idDepartamento=d.idDepartamento && m.estado=1 && m.nombre LIKE nomMuni ORDER BY d.nombre, m.nombre ASC;
END
$$
--------------
DELIMITER $$
CREATE PROCEDURE SP_getAll_CV (
    IN comienzo INT,
    IN longitud INT)
BEGIN
SELECT m.idMunicipio,m.idDepartamento,d.nombre as nombreDepartamento,m.nombre,m.nombreCentroVotacion 
FROM municipio as m INNER JOIN departamento as d 
where m.idDepartamento=d.idDepartamento && m.estado=1 
ORDER BY d.nombre, m.nombre 
LIMIT comienzo,longitud;
END
$$
/*--------------------------------------------------------------*/
/*-----------------procedimientos almacenados JR-------------------*/
DELIMITER $$
CREATE PROCEDURE SP_agregar_JR (
    IN idM int,
    IN nombre varchar(50))
BEGIN   
INSERT INTO juntaReceptora VALUES (null,idM,nombre, 1);
END
$$
--------------
DELIMITER $$
CREATE PROCEDURE SP_eliminar_JR (
    IN idJ INT)
BEGIN
UPDATE juntaReceptora SET estado=0 
WHERE idJuntaReceptora=idJ;
END
$$
--------------
DELIMITER $$
CREATE PROCEDURE SP_modificar_JR (
    IN idJ INT,
    IN idM INT,
    IN Nombre varchar(50))
BEGIN
UPDATE juntaReceptora SET idMunicipio=idM,nombre=Nombre
WHERE idJuntaReceptora=idJ;
END
$$
--------------
DELIMITER $$
CREATE PROCEDURE SP_getSearch_JR (
    IN nomJR varchar(100))
BEGIN
SELECT d.idDepartamento,j.idJuntaReceptora,j.idMunicipio,j.nombre,m.nombreCentroVotacion AS nombreCentroVotacion,d.nombre as departamento
FROM JuntaReceptora as j INNER JOIN Municipio as m INNER JOIN departamento as d
WHERE j.idMunicipio=m.idMunicipio && m.idDepartamento=d.idDepartamento && j.estado=1 && m.estado=1 && (m.nombreCentroVotacion LIKE nomJR || j.nombre LIKE nomJR || d.nombre LIKE nomJR) 
ORDER BY m.nombreCentroVotacion,m.nombre ASC ;
END
$$
--------------
DELIMITER $$
CREATE PROCEDURE SP_getAll_JR (
    IN comienzo INT,
    IN longitud INT)
BEGIN
SELECT d.idDepartamento,j.idJuntaReceptora,j.idMunicipio,j.nombre,m.nombreCentroVotacion AS nombreCentroVotacion,d.nombre as departamento
FROM JuntaReceptora as j INNER JOIN Municipio as m INNER JOIN departamento as d
WHERE j.idMunicipio=m.idMunicipio && m.idDepartamento=d.idDepartamento && j.estado=1 && m.estado=1 
ORDER BY m.nombreCentroVotacion,m.nombre ASC
LIMIT comienzo,longitud;
END
$$
/*--------------------------------------------------------------*/
/*-----------------procedimientos almacenados persona-------------------*/
DELIMITER $$
CREATE PROCEDURE SP_agregar_Per (
    IN idMunicipio int,
    IN img text,
    IN dui varchar(10),
    IN nombre varchar(50),
    IN apellido varchar(50),
    IN fecha_nac date,
    IN fecha_expiracion_dui date,
    IN genero varchar(1),
    IN direccion text,
    IN estadoCivil varchar(50),
    IN salvadorenoPor varchar(15))
BEGIN
INSERT INTO persona VALUES (null,idMunicipio,img,dui,nombre,apellido,fecha_nac,fecha_expiracion_dui,genero,direccion,estadoCivil,salvadorenoPor,0,1);
END
$$
--------------
DELIMITER $$
CREATE PROCEDURE SP_eliminar_Per (
    IN idP INT)
BEGIN
UPDATE persona SET estado=0 
WHERE idPersona=idP;
END
$$
--------------
DELIMITER $$
CREATE PROCEDURE SP_modificarSinImg_Per (
    In idP int,
    IN idM int,
    IN dui varchar(10),
    IN nomb varchar(50),
    IN ape varchar(50),
    IN fechaNac date,
    IN expiracion_dui date,
    IN gen varchar(1),
    IN direc text,
    IN estado_Civil varchar(50),
    IN salvadoreno_Por varchar(15))
BEGIN
UPDATE persona 
SET DUI=dui,idMunicipio=idM,nombre=nomb,apellido=ape,fecha_nac=fechaNac,fecha_expe_dui=expiracion_dui,genero=gen,direccion=direc,
estadoCivil=estado_Civil,salvadorenoPor=salvadoreno_Por
WHERE idPersona=idP;
END
$$
-------------
DELIMITER $$
CREATE PROCEDURE SP_modificarConImg_Per (
    In idP int,
    IN idM int,
    IN imagen text,
    IN dui varchar(10),
    IN nomb varchar(50),
    IN ape varchar(50),
    IN fechaNac date,
    IN expiracion_dui date,
    IN gen varchar(1),
    IN direc text,
    IN estado_Civil varchar(50),
    IN salvadoreno_Por varchar(15))
BEGIN
UPDATE persona 
SET img=imagen,DUI=dui,idMunicipio=idM,nombre=nomb,apellido=ape,fecha_nac=fechaNac,fecha_expe_dui=expiracion_dui,genero=gen,direccion=direc,
estadoCivil=estado_Civil,salvadorenoPor=salvadoreno_Por
WHERE idPersona=idP;
END
$$
--------------
DELIMITER $$
CREATE PROCEDURE SP_getSearch_Per (
    IN nomPers varchar(100))
BEGIN
SELECT p.idPersona,p.idMunicipio,m.idDepartamento,m.nombre AS municipio,d.nombre 
AS departamento,p.img,p.DUI,p.nombre,p.apellido,p.fecha_nac,p.fecha_expe_dui,p.genero,
p.direccion,p.estadoCivil,p.salvadorenoPor
FROM persona AS p INNER JOIN municipio AS m INNER JOIN departamento AS d 
WHERE m.idDepartamento=d.idDepartamento && p.idMunicipio=m.idMunicipio && m.estado=1 
&& p.estado=1 && (CONCAT(p.nombre,' ',p.apellido) LIKE nomPers || p.DUI LIKE nomPers || 
    d.nombre LIKE nomPers || m.nombre LIKE nomPers || p.estadoCivil LIKE nomPers || 
    p.fecha_nac LIKE nomPers || p.salvadorenoPor LIKE nomPers || p.genero LIKE nomPers);
END
$$
--------------
DELIMITER $$
CREATE PROCEDURE SP_getAll_Per (
    IN comienzo INT,
    IN longitud INT) 
BEGIN
SELECT p.idPersona,p.idMunicipio,m.idDepartamento,m.nombre 
AS municipio,d.nombre AS departamento,p.img,p.DUI,p.nombre,p.apellido,p.fecha_nac,
p.fecha_expe_dui,p.genero,p.direccion,p.estadoCivil,p.salvadorenoPor 
FROM persona AS p INNER JOIN municipio AS m INNER JOIN departamento AS d 
WHERE p.idMunicipio=m.idMunicipio && m.idDepartamento=d.idDepartamento && m.estado=1 && p.estado=1 
LIMIT comienzo,longitud;
END
$$
/*--------------------------------------------------------------*/

/*-----------------procedimientos almacenados Partido Politico-------------------*/
DELIMITER $$
CREATE PROCEDURE SP_agregar_PP (
    IN idP int,
    IN Nombre varchar(100),
    IN Abreviatura varchar(15),
    IN img text)
BEGIN
INSERT INTO partido VALUES (null,idP,Nombre,Abreviatura,img,1);
END
$$
--------------
DELIMITER $$
CREATE PROCEDURE SP_eliminar_PP (
    IN idPP INT)
BEGIN
UPDATE partido SET estado=0 
WHERE idPartido=idPP;
END
$$
--------------
DELIMITER $$
CREATE PROCEDURE SP_modificarSinImg_PP (
    In idPP int,
    IN idP int,
    IN nomb varchar(100),
    IN Abre varchar(15))
BEGIN
UPDATE partido 
SET idPersona=idP,nombre=nomb,abreviacion=Abre
WHERE idPartido=idPP;
END
$$
-------------
DELIMITER $$
CREATE PROCEDURE SP_modificarConImg_PP (
    In idPP int,
    IN idP int,
    IN nomb varchar(100),
    IN Abre varchar(15),
    IN imagen text)
BEGIN
UPDATE partido 
SET idPersona=idP,nombre=nomb,abreviacion=Abre,img=imagen
WHERE idPartido=idPP;
END
$$
--------------
DELIMITER $$
CREATE PROCEDURE SP_getSearch_PP (
    IN nomPP varchar(100))
BEGIN
SELECT pp.idPartido,pp.idPersona,pp.nombre,pp.abreviacion,pp.img as imgPP,CONCAT(p.nombre,' ',p.apellido) as presidente,p.DUI,p.img as imgP 
FROM partido as pp INNER JOIN persona as p
WHERE pp.estado=1 && pp.idPersona=p.idPersona && (CONCAT(p.nombre,' ',p.apellido) LIKE nomPP || p.DUI LIKE nomPP || pp.nombre LIKE nomPP || pp.abreviacion LIKE nomPP);
END
$$
-- --------------
DELIMITER $$
CREATE PROCEDURE SP_getAll_PP (
    IN comienzo INT,
    IN longitud INT) 
BEGIN
SELECT pp.idPartido,pp.idPersona,pp.nombre,pp.abreviacion,pp.img as imgPP,CONCAT(p.nombre,' ',p.apellido) as presidente,p.DUI,p.img as imgP 
FROM partido as pp INNER JOIN persona as p
WHERE pp.estado=1 && pp.idPersona=p.idPersona
LIMIT comienzo,longitud;
END
$$
/*--------------------------------------------------------------*/
/*-----------------procedimientos almacenados Usuarios-------------------*/
DELIMITER $$
CREATE PROCEDURE SP_agregar_Usuario (
    IN idP int,
    IN rol varchar(50),
    IN correo text,
    IN contrasena varchar(200),
    IN cadVeri text)
BEGIN
INSERT INTO usuario VALUES (null,idP,rol,correo,contrasena,cadVeri,'VERIFICADO',1);
END
$$
--------------
DELIMITER $$
CREATE PROCEDURE SP_eliminar_Usuario (
    IN idUs INT)
BEGIN
UPDATE usuario SET estado=0 
WHERE idUsuario=idUs;
END
$$
--------------
DELIMITER $$
CREATE PROCEDURE SP_modificar_Usuario (
    In idU int,
    In idP int,
    IN Rol varchar(50),
    IN Correo text
)
BEGIN
UPDATE usuario 
SET idPersona=idP,rol=Rol,correo=Correo
WHERE idUsuario=idU;
END
--------------
DELIMITER $$
CREATE PROCEDURE SP_modificar_Usuario_Con_contra (
    In idU int,
    In idP int,
    IN Rol varchar(50),
    IN contra varchar(200),
    IN Correo text
)
BEGIN
UPDATE usuario 
SET idPersona=idP,rol=Rol,correo=Correo, contrasena=contra
WHERE idUsuario=idU;
END
-------------
DELIMITER $$
CREATE PROCEDURE SP_getSearch_Usuario (
    IN nomUs varchar(100))
BEGIN
SELECT u.idUsuario,u.idPersona,u.rol,u.correo,u.verificacion,CONCAT(p.nombre,' ',p.apellido) as nombre,p.DUI,p.img
FROM usuario as u INNER JOIN persona as p
WHERE u.idPersona=p.idPersona && u.estado=1  && (CONCAT(p.nombre,' ',p.apellido) LIKE nomUs || p.DUI LIKE nomUs || u.correo LIKE nomUs || u.rol LIKE nomUs || u.verificacion LIKE nomUs);
END
$$
-- --------------
DELIMITER $$
CREATE PROCEDURE SP_getAll_Usuario (
    IN comienzo INT,
    IN longitud INT) 
BEGIN
SELECT u.idUsuario,u.idPersona,u.rol,u.correo,u.verificacion,CONCAT(p.nombre,' ',p.apellido) as nombre,p.DUI,p.img
FROM usuario as u INNER JOIN persona as p
WHERE u.idPersona=p.idPersona && u.estado=1 
LIMIT comienzo,longitud;
END
$$
/*--------------------------------------------------------------*/

<?php 
session_start();
	date_default_timezone_set('America/El_Salvador');
	require_once '../../models/votar.php';
	$votar=new Votar();
	$res=$votar->ConsultaSimple("SELECT nombre,apellido,fecha_nac,img,genero FROM persona WHERE DUI='".$_SESSION['usuario']['dui']."'");
	$nombreJr=$votar->calcularJunta($_SESSION['usuario']['dui']);

	if($nombreJr[COUNT($nombreJr)-1]['fail']=='fail'){
		$array=array('fail'=>'fail');
	}else{
		$array=array('dui'=>$_SESSION['usuario']['dui'],
					'nombre'=>$res[0]['nombre'],
					'apellido'=>$res[0]['apellido'],
					'genero'=>$res[0]['genero'],
					'fechaNac'=>$res[0]['fecha_nac'],
					'img'=>$res[0]['img'],
					'jr'=>$nombreJr[0],
					'jrId'=>$nombreJr[1],
					'fechaAc'=>date('Y/m/d'),
					'fail'=>'true');
	}
echo json_encode($array);
?>
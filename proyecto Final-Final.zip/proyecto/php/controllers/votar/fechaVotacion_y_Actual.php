<?php 
date_default_timezone_set('America/El_Salvador');
$retorno = array('fecActual'=>date('Y/m/d'),'fecVotacion'=>'2020/02/02');
echo json_encode($retorno);
 ?>
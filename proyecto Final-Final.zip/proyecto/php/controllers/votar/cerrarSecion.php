<?php 
session_start();
session_unset();
session_destroy();

if(isset($_SESSION['usuario'])){
	echo 'FAIL';
}else{
	echo 'BIEN';
}
 ?>
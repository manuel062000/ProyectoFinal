<?php 
session_start();
	if(!isset($_SESSION['usuario']['dui'])){
		echo '<script>window.parent.document.location.href = "../../php/view/votar.php";</script>';
	}

 ?>
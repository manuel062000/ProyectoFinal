<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<script src="../../../js/Jquery/jquery-3.3.1.min.js"></script>
	<script src="../../../js/sweetalert2/sweetalert2.js"></script>
</head>
<body>
	
	<?php 
	date_default_timezone_set('America/El_Salvador');
	session_start();
	require_once '../../models/parametros.php';
	if(fechaVotaciones!= date('Y/m/d')){
		echo '<script>
				swal({
					title: "¡ERROR!",
					text: "Aún no comienzan las votaciones...",
					icon: "error",
					timer: 10000,
					confirmButtonColor:"#FF6B5C",
					showConfirmButton: true,
				}).then((value) => {
					location.href = "../../view/dashboard.php";
				});
			</script>';
	}else{
		$_SESSION['usuario']=array('jr'=>'Activa');
		if(isset($_SESSION['usuario']['jr'])){
			echo '<script>window.parent.document.location.href = "../../view/votar.php";</script>';
		}else{
			echo '<script>window.parent.document.location.href = "../../view/dashboard.php";</script>';
		}	
	}
	?>
</body>
</html>


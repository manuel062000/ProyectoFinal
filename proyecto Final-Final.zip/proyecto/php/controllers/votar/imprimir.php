<?php 
	require_once '../../models/reporte.php';
	$cls= new reporteJr();
	$cls->reportePersonaJr();


 ?>
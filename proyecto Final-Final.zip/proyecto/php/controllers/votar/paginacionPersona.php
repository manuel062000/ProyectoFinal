<?php 
	require_once '../../models/CRUD.php';
	$crud=new CRUD();
	$paginacion=array();
	$idMunicipio=$_POST['idMunicipio'] ?? 1;
	$paginacion=$crud->getPaginacion('persona AS p INNER JOIN municipio AS m WHERE p.idMunicipio=m.idMunicipio && m.estado=1 && p.estado=1 && p.idMunicipio='.$idMunicipio);
	$filasTotal=$paginacion['filasTotal'];
	$filasPagina=$paginacion['filasPagina'];

	echo ceil($filasTotal/$filasPagina);
?>
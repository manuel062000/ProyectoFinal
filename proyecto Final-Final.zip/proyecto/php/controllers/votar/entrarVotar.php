 <?php 
// declare(strict_types = 1);
session_start();
require_once '../../models/parametros.php';
require_once '../../models/votar.php';
$dui=$_POST['dui'] ?? '';

if(isset($_POST['dui']) && !empty($_POST['dui'])){
	$votar=new Votar();
	$res=$votar->ConsultaSimple("SELECT count(*) AS total,voto,fecha_expe_dui FROM persona WHERE DUI='".$dui."'");
	
	$fVot = explode('/',fechaVotaciones);
	$fVen= explode('-',$res[0]['fecha_expe_dui']);
	if($res[0]['total']==1){
		if($res[0]['voto']==0){
			$dV=true;
			if($fVot[0]<$fVen[0]){
				$dV=true;
			}else{
				if($fVot[1]<$fVen[1] && $fVen[0]==$fVot[0]){
					$dV=true;
				}else{
					if($fVot[2]<=$fVen[2] && $fVen[1]==$fVot[1] && $fVen[0]==$fVot[0]){
						$dV=true;
					}else{
						$dV=false;
					}
				}
			}
			if($dV){
				$_SESSION['usuario']=array('dui'=>$dui);
				echo 2;
			}else{
				echo 1;	
			}
		}else{
			echo 3;
		}
		
	}else{
		echo 'FAIL';
	}
}else{
	echo 'FAIL';
}





	
 ?>
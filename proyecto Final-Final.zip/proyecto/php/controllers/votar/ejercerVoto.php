<?php 
declare(strict_types = 1);
require_once '../../models/votar.php';
$votar=new Votar();
$idPP=$_POST['idPP'] ?? '';
$idJr=$_POST['idJr'] ?? '';
$dui=$_POST['dui'] ?? '';

if(isset($_POST['idPP']) && !empty($_POST['idPP']) && isset($_POST['idJr']) && !empty($_POST['idJr']) && isset($_POST['dui']) && !empty($_POST['dui'])){
	$votar->setIdPP($idPP);
	$votar->setIdJr($idJr);
	$votar->setDui($dui);
	$votar->EjercerVoto();
}else{
	echo 'ERROR';
}

 ?>
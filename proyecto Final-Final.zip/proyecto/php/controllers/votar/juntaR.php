<?php 
	session_start();
	if(!isset($_SESSION['usuario']['jr'])){
		echo '<script>window.parent.document.location.href = "../../index.php";</script>';
	}
 ?>
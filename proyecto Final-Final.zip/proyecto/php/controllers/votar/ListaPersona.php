<?php 
	declare(strict_Types=1);
	require_once("../../models/votar.php");
	require_once("../../models/tablas.php");
	require_once("../../models/CRUD.php");
	$tablas=new tablas();
	$votar=new Votar();
	$crud=new CRUD();
	$data=array();
	$idMunicipio=$_POST['idMunicipio'] ?? 1;
//Paginacion---------
	$paginacion=array();
	$pagina=$_POST['pagina'] ?? 1;
	$paginacion=$crud->getPaginacion('persona AS p INNER JOIN municipio AS m WHERE p.idMunicipio=m.idMunicipio && m.estado=1 && p.estado=1');
	$filasTotal=$paginacion['filasTotal'];
	$filasPagina=$paginacion['filasPagina'];
	$empezarDesde= ($pagina-1) * $filasPagina;

	
	$data=$votar->mostrarPerJr($idMunicipio,$empezarDesde,$filasPagina);
	echo $tablas->showTablePerJr($data);
 ?>
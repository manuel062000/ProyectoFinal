<?php 
require_once '../../models/votar.php';
require_once '../../models/tablas.php';

$votar=new Votar();
$tabla=new tablas();

$res=$votar->getPartidos();
echo $tabla->showBanderasPartidos($res);

 ?>
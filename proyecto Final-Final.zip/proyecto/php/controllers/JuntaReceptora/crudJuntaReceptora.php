<?php 
declare (strict_types = 1);
require_once ('../../models/CRUD.php');
$crud=new CRUD();
$opcion=$_POST['opcion'];
$idMunicipio=$_POST['idMunicipio'];
$idJuntaReceptora=$_POST['idJuntaReceptora'];
/*valida si el nombre ya posee JR- al inicio de la cadena para no volverselo asignar*/
if(substr(strtoupper($_POST['nombre']),0,3)=="JR-"){
	$nombre=strtoupper($_POST['nombre'] ?? '');
}else{
	$nombre='JR-'.strtoupper($_POST['nombre'] ?? '');
}

if(!empty($opcion)){
	switch ($opcion) {
		case 'editar':
			if(!empty($_POST['nombre']) && !empty($_POST['idJuntaReceptora']) && !empty($_POST['idMunicipio'])){
				$params=$idJuntaReceptora.",".$idMunicipio.",'".$nombre."'";
				$crud->modificar('SP_modificar_JR',$params);
			}else{
				echo "VACIO";
			}
		break;
		case 'eliminar':
			if(!empty($_POST['idJuntaReceptora'])){
				$params=$idJuntaReceptora;
				$crud->modificar('SP_eliminar_JR',$params);
			}else{
				echo "VACIO";
			}

		break;
		case 'agregar':
			if(!empty($_POST['nombre']) && !empty($_POST['idMunicipio'])){
				$params=$idMunicipio.",'".$nombre."'";
				$crud->agregar('SP_agregar_JR',$params);
			}else{
				echo "VACIO";
			}
		break;
	}
}else{
	echo "VACIO";
}
?>
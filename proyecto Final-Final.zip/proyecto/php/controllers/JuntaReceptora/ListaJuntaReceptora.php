<?php 
	declare(strict_Types=1);
	require_once("../../models/CRUD.php");
	require_once("../../models/tablas.php");
	$tablas=new tablas();
	$crud=new CRUD();
	$data=array();
//Paginacion---------
	$paginacion=array();
	$pagina=$_POST['pagina'] ?? 1;
	$termino = $_POST['termino'] ?? '';
	$paginacion=$crud->getPaginacion('JuntaReceptora');
	$filasTotal=$paginacion['filasTotal'];
	$filasPagina=$paginacion['filasPagina'];
	$empezarDesde= ($pagina-1) * $filasPagina;

	if($termino != ''){/*busqueda de registros*/
		$data=$crud->getSearch('SP_getSearch_JR',$termino);
	}else{/*todos los registros*/
		$data=$crud->getAll('SP_getAll_JR',$empezarDesde,$filasPagina);
	}
	echo $tablas->showTableJuntaReceptora($data);
 ?>
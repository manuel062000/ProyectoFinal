<?php 
	require_once '../../models/CRUD.php';
	$crud=new CRUD();
	$paginacion=array();
	$paginacion=$crud->getPaginacion('JuntaReceptora as j INNER JOIN municipio as m WHERE j.idMunicipio=m.idMunicipio && j.estado=1 && m.estado=1');
	$filasTotal=$paginacion['filasTotal'];
	$filasPagina=$paginacion['filasPagina'];

	echo ceil($filasTotal/$filasPagina);
?>
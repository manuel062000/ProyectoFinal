<?php 
	require_once '../../models/CRUD.php';
	$crud=new CRUD();
	$paginacion=array();
	$parametro=$_POST['parametro'] ?? 1;

	
	$paginacion=$crud->getPaginacion('historial WHERE tipo='.$parametro);
	

	$filasTotal=$paginacion['filasTotal'];
	$filasPagina=$paginacion['filasPagina'];

	echo ceil($filasTotal/$filasPagina);
?>
<?php 
	declare(strict_Types=1);
	require_once("../../models/CRUD.php");
	require_once("../../models/tablasHistorial.php");
	require_once("../../models/Historial.php");
	$tablas=new Tablas();
	$crud=new CRUD();
	$historial=new Historial();
	$data=array();
	$termino=$_POST['termino'] ?? '';
	$parametro=$_POST['tabla'] ?? 1;

	if($termino!=''){
		$termino='%'.$termino.'%';
	}

//Paginacion---------
	$paginacion=array();
	$pagina=$_POST['pagina'] ?? 1;
	$paginacion=$crud->getPaginacion('historial WHERE tipo='.$parametro);
	$filasTotal=$paginacion['filasTotal'];
	$filasPagina=$paginacion['filasPagina'];
	$empezarDesde= ($pagina-1) * $filasPagina;

	if($parametro==1){
		$data=$historial->mostrarCV($termino,$empezarDesde,$filasPagina);
		echo $tablas->showTableCV($data);
// ---------------------------------------
	}else if($parametro==2){
		$data=$historial->mostrarJR($termino,$empezarDesde,$filasPagina);
		echo $tablas->showTableJR($data);

	}else if($parametro==3){
		$data=$historial->mostrarPer($termino,$empezarDesde,$filasPagina);
		echo $tablas->showTablePer($data);
// --------------------------------------
	}else if($parametro==4){
		$data=$historial->mostrarPP($termino,$empezarDesde,$filasPagina);
		echo $tablas->showTablePP($data);
// --------------------------------------
	}else if($parametro==5){
		$data=$historial->mostrarUsuario($termino,$empezarDesde,$filasPagina);
		echo $tablas->showTableUsu($data);
// -----------------------------------------
	}
 ?>
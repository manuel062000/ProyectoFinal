<?php 
require_once '../../models/graficos.php';

$grafico = new Graficos();
echo json_encode($grafico->getAll());


// UPDATE persona SET voto=0;
//  DELETE FROM votos ;
 ?>
<?php 
require_once('../../models/CRUD.php');
	$crud=new CRUD();
	$html='';

		$elementos=$crud->llenarSelect('*','partido WHERE estado = 1');	

		if(count($elementos)!=0){
			foreach ($elementos as $value) {
				$html.='<option selected  value="'.$value['idPartido'].'">'.$value['abreviacion'].'</option>';
			}
		}else{
			$html="ERROR";
		}


echo $html;
 ?>
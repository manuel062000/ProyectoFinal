<?php 
require_once '../../models/graficos.php';
$grafico = new Graficos();
$idMunicipio = $_POST['idMunicipio'] ?? '';
$idDepartamento = $_POST['idDepartamento'] ?? '';
$idPartido = $_POST['idPartido'] ?? '';

$grafico->setIdPartido($idPartido);
$grafico->setIdMunicipio($idMunicipio);
$grafico->setIdDepartamento($idDepartamento);

$respuesta=$grafico->getDatos();

echo json_encode($respuesta);



?>
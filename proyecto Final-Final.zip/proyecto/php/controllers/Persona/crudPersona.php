<?php 
declare (strict_types = 1);
require_once ('../../models/CRUD.php');
$crud=new CRUD();
$opcion = $_POST['opcion']  ?? '';
$idPersona = $_POST['id'] ?? '';
$dui = $_POST['txt_DUI'] ?? '';
$nombre = strtoupper($_POST['txt_nombre'] ?? '');
$apellido = strtoupper($_POST['txt_apellido'] ?? '');
$fecha_nac = $_POST['txt_fecha_Nac'] ?? '';
$salvadorenoPor = strtoupper($_POST['txt_nacionalidad'] ?? '');
$fecha_expiracion_dui = $_POST['txt_fecha_Exp_dui'] ?? '';
$idMunicipio = $_POST['txt_municipio'] ?? '';
$estadoCivil = strtoupper($_POST['txt_estadoCivil'] ?? '');
$direccion = strtoupper($_POST['txt_Direccion'] ?? '');
$genero = strtoupper($_POST['genero'] ?? '');
$imagen = $_FILES['txt_img'] ?? '';

if(!empty($opcion)){
	switch ($opcion) {
		case 'editar':
			if(!empty($_POST['id']) && !empty($_POST['txt_DUI']) && !empty($_POST['txt_nombre']) && !empty($_POST['txt_apellido']) && 
			!empty($_POST['txt_fecha_Nac']) && !empty($_POST['txt_nacionalidad']) && 
			!empty($_POST['txt_fecha_Exp_dui']) && !empty($_POST['txt_municipio']) && 
			!empty($_POST['txt_estadoCivil'])&& !empty($_POST['txt_Direccion']) && !empty($_POST['genero'])){					
					$resultado=$crud->existencia('idPersona','persona',"dui='".$dui."'");
					if($resultado['total'] == 0 || $resultado['idPersona'] == $idPersona){
						if($imagen['tmp_name']==""){
							$params=$idPersona.",".$idMunicipio.",'".$dui."','".$nombre."','".$apellido."','".$fecha_nac."','".$fecha_expiracion_dui."','".$genero."','".$direccion."','".$estadoCivil."','".$salvadorenoPor."'";
							$crud->modificar('SP_modificarSinImg_Per',$params);
						}else{
							$carpeta = "../../../images/"; 
							opendir ($carpeta);
							$nombreGuardar=$idPersona.'-imagen';
							$destino = $carpeta.md5($nombreGuardar).'.jpg';
							if(move_uploaded_file($imagen['tmp_name'],$destino)){
								$params=$idPersona.",".$idMunicipio.",'".md5($nombreGuardar).".jpg','".$dui."','".$nombre."','".$apellido."','".$fecha_nac."','".$fecha_expiracion_dui."','".$genero."','".$direccion."','".$estadoCivil."','".$salvadorenoPor."'";
								$crud->modificarConImg('SP_modificarConImg_Per',$params);
							}
						}
					}else{
						echo 'DUI';
					}
			}else{
				if($imagen['type'] == 'image/jpg' || $imagen['type'] == 'image/jpeg'){
					echo "VACIO";
				}else{
					echo 'FORMATO';
				}
			}
		break;
		case 'eliminar':
			if(!empty($_POST['id'])){
				$resultado=$crud->existencia('idPartido','partido','estado=1 AND idPersona='.$idPersona);
				$usuario=$crud->existencia('idUsuario','usuario','estado=1 AND idPersona='.$idPersona);
				if($resultado['total'] == 0 && $usuario['total'] == 0){
					$params=$idPersona;
					$crud->modificar('SP_eliminar_Per',$params);
				}else{
					if($resultado['total'] > 0){
						echo 'PARTIDO';
					}else{
						echo 'USUARIO';
					}
				}
			}else{
				echo "VACIO";
			}
		break;
		case 'agregar':

			if(!empty($_POST['txt_DUI']) && !empty($_POST['txt_nombre']) && !empty($_POST['txt_apellido']) && 
				!empty($_POST['txt_fecha_Nac']) && !empty($_POST['txt_nacionalidad']) && 
				!empty($_POST['txt_fecha_Exp_dui']) && !empty($_POST['txt_municipio']) && 
				!empty($_POST['txt_estadoCivil']) && !empty($_POST['txt_Direccion']) && !empty($_POST['genero'])
				&& ($imagen['type'] == 'image/jpg' || $imagen['type'] == 'image/jpeg')){

				$resultado=$crud->existencia('idPersona','persona',"dui='".$dui."'");
				if($resultado['total'] == 0){

					$ultimo_id=$crud->ultimo_id('idPersona','persona')['id'];
					$carpeta = "../../../images/"; 
					opendir ($carpeta);
					$nombreGuardar=($ultimo_id+1).'-imagen';
					$destino = $carpeta.md5($nombreGuardar).'.jpg';
					if(move_uploaded_file($imagen['tmp_name'],$destino)){				
						$params=$idMunicipio.",'".md5($nombreGuardar).".jpg','".$dui."','".$nombre."','".$apellido."','".$fecha_nac."','".$fecha_expiracion_dui."','".$genero."','".$direccion."','".$estadoCivil."','".$salvadorenoPor."'";
						$crud->agregar('SP_agregar_Per',$params);
					}
				}else{
						echo 'DUI';
					}				
			}else{
				if($imagen['type'] == 'image/jpg' || $imagen['type'] == 'image/jpeg' || $imagen['tmp_name']==""){
					echo "VACIO";
				}else{
					echo 'FORMATO';
				}				
			}
		break;
	}
}else{
	echo "VACIO";
}
?>
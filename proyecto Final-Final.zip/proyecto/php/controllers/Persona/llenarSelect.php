<?php 
	require_once('../../models/CRUD.php');
	$crud=new CRUD();
	$idDepartamento=$_POST['idDepartamento'];
	$html='';

	if($idDepartamento!=''){
		$elementos=$crud->llenarSelect('*','municipio WHERE idDepartamento='.$idDepartamento.' && estado = 1');	
		if(count($elementos)!=0){
			$idSeleccion=$_POST['idSeleccion'];	
			foreach ($elementos as $value) {
				if($idSeleccion==$value['idMunicipio']){
					$html.='<option selected class="municipio" value="'.$value['idMunicipio'].'">'.$value['nombre'].'</option>';
				}else{
					$html.='<option class="municipio" value="'.$value['idMunicipio'].'">'.$value['nombre'].'</option>';
				}
			}
		}else{
			$html="ERROR";
		}
	}else {
		$elementos=$crud->llenarSelect('idDepartamento,nombre','departamento ORDER BY nombre ASC');	
		if(count($elementos)!=0){	
			foreach ($elementos as $value) {
				if($value['idDepartamento']=='1'){
					$html.='<option selected class="departamento" value="'.$value['idDepartamento'].'">'.$value['nombre'].'</option>';
				}else{
					$html.='<option class="departamento" value="'.$value['idDepartamento'].'">'.$value['nombre'].'</option>';
				}
			}
		}
	}
	echo $html;
 ?>
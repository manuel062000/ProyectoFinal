<?php 
require_once '../../models/correo.php';
 $correo=new Correo();
 $id=$_GET['id'] ?? '';
 $correo->setIdUsuario($id);
 $resultado=$correo->Activar();
 if($resultado=='bien'){
 	echo "<script type='text/javascript'>location.href='../../../index.php?r=1'</script>";
 }else{
 	echo "<script type='text/javascript'>location.href='../../../index.php?r=0'</script>";
 }

 ?>

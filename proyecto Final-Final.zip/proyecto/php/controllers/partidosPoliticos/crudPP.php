<?php 
declare (strict_types = 1);
require_once ('../../models/CRUD.php');
$crud=new CRUD();
$opcion = $_POST['opcion']  ?? '';
$idPartido = $_POST['id'] ?? '';
$idPersona = $_POST['idpersona'] ?? '';
$nombre = strtoupper($_POST['txt_nombre'] ?? '');
$abreviatura = strtoupper($_POST['txt_abreviatura'] ?? '');
$imagen = $_FILES['txt_img'] ?? '';

if(!empty($opcion)){
	switch ($opcion) {
		case 'editar':
			if(!empty($_POST['id']) && !empty($_POST['idpersona']) && !empty($_POST['txt_nombre']) && !empty($_POST['txt_abreviatura'])){	

				$resultado=$crud->existencia('idPartido','partido','estado=1 && idPersona='.$idPersona);
				if($resultado['total'] == 0 || $resultado['idPartido'] == $idPartido){
					if($imagen['tmp_name']==""){
						$params=$idPartido.",".$idPersona.",'".$nombre."','".$abreviatura."'";
						$crud->modificar('SP_modificarSinImg_PP',$params);
					}else{
						$carpeta = "../../../images/"; 
						opendir ($carpeta);
						$nombreGuardar=$idPersona.'-bandera';
						$destino = $carpeta.md5($nombreGuardar).'.jpg';
						if(move_uploaded_file($imagen['tmp_name'],$destino)){
							$params=$idPartido.",".$idPersona.",'".$nombre."','".$abreviatura."','".md5($nombreGuardar).".jpg'";
							$crud->modificarConImg('SP_modificarConImg_PP',$params);
						}
					}
				}else{
					echo 'DUI';
				}
			}else{
				if(($imagen['type'] == 'image/jpg' || $imagen['type'] == 'image/jpeg') || $_POST['idpersona']==''){
					echo "VACIO";
				}else{
					echo 'FORMATO';
				}
			}
		break;
		case 'eliminar':
			if(!empty($_POST['id'])){
				$params=$idPartido;
				$crud->modificar('SP_eliminar_PP',$params);
			}else{
				echo "VACIO";
			}
		break;
		case 'agregar':
			if(!empty($_POST['idpersona']) && !empty($_POST['txt_nombre']) && 
				!empty($_POST['txt_abreviatura']) && ($imagen['type'] == 'image/jpg' || $imagen['type'] == 'image/jpeg')){

				$resultado=$crud->existencia('idPartido','partido','estado=1 && idPersona='.$idPersona);
				if($resultado['total'] == 0){

					$ultimo_id=$crud->ultimo_id('idPartido','Partido')['id'];
					$carpeta = "../../../images/"; 
					opendir ($carpeta);
					$nombreGuardar=($ultimo_id+1).'-bandera';
					$destino = $carpeta.md5($nombreGuardar).'.jpg';
					if(move_uploaded_file($imagen['tmp_name'],$destino)){				
						$params=$idPersona.",'".$nombre."','".$abreviatura."','".md5($nombreGuardar).".jpg'";
						$crud->agregar('SP_agregar_PP',$params);
					}
				}else{
					echo 'DUI';
				}				
			}else{
				if($imagen['type'] == 'image/jpg' || $imagen['type'] == 'image/jpeg' || $imagen['tmp_name']==""){
					echo "VACIO";
				}else{
					echo 'FORMATO';
				}				
			}
		break;
	}
}else{
	echo "VACIO";
}
?>
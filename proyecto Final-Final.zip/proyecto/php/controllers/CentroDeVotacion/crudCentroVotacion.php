<?php 
declare (strict_types = 1);
require_once ('../../models/CRUD.php');
$crud=new CRUD();
$opcion=$_POST['opcion'];
$idMunicipio=$_POST['idMunicipio'];
$idDepartamento=$_POST['idDepartamento'];
$nombre=strtoupper($_POST['nombre'] ?? '');
$nombreCV='CV-'.$nombre;

if(!empty($opcion)){
	switch ($opcion) {
		case 'editar':
			if(!empty($_POST['nombre']) && !empty($_POST['idDepartamento']) && !empty($_POST['idMunicipio'])){
				$params=$idMunicipio.",".$idDepartamento.",'".$nombre."','".$nombreCV."'";
				$crud->modificar('SP_modificar_CV',$params);
			}else{
				echo "VACIO";
			}
		break;
		case 'eliminar':
			if(!empty($_POST['idMunicipio'])){
				$params=$idMunicipio;
				$crud->modificar('SP_eliminar_CV',$params);
			}else{
				echo "VACIO";
			}
		break;
		case 'agregar':
			if(!empty($_POST['nombre']) && !empty($_POST['idDepartamento'])){
				$params=$idDepartamento.",'".$nombre."','".$nombreCV."'";
				$crud->agregar('SP_agregar_CV',$params);
			}else{
				echo "VACIO";
			}
		break;
	}
}else{
	echo "VACIO";
}
?>
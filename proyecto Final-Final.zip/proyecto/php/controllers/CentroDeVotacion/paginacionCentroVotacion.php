<?php 
	require_once '../../models/CRUD.php';
	$crud=new CRUD();
	$paginacion=array();
	$paginacion=$crud->getPaginacion('municipio WHERE estado=1');
	$filasTotal=$paginacion['filasTotal'];
	$filasPagina=$paginacion['filasPagina'];

	echo ceil($filasTotal/$filasPagina);
?>
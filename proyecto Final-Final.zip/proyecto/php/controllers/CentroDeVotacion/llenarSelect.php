<?php 
	require_once('../../models/CRUD.php');
	$crud=new CRUD();
	$elementos=$crud->llenarSelect('*','departamento');
	$html='';
	if(count($elementos)!=0){	
		$i=0;	
		foreach ($elementos as $value) {
			$html.='<option value="'.$value['idDepartamento'].'">'.$value['nombre'].'</option>';
		}
	}
	echo $html;
 ?>
<?php 
declare (strict_types = 1);
require_once ('../../models/CRUD.php');
$crud=new CRUD();
$dui = $_POST['dui'];
$idUs=$_POST['id'];
$resultado = $crud->llenarSelect('idPersona,CONCAT(nombre," ",apellido) as nombre,img',"persona where estado=1 && DUI='".$dui."'");

if(count($resultado)!=0){

	$existe=$crud->existencia('idUsuario,rol','usuario','estado=1 && idPersona='.$resultado[0]['idPersona']);
	if($existe['total'] == 0 || $idUs==$existe['idUsuario']){
		$array=array('res'=>'BIEN','id'=>$resultado[0]['idPersona'],'nombre'=>$resultado[0]['nombre'],'img'=>$resultado[0]['img']);
		echo json_encode($array);
	}else{
		$array=array('res'=>'EXISTE','nombre'=>$resultado[0]['nombre'],'rol'=>$existe['rol'],'img'=>$resultado[0]['img']);
		echo json_encode($array);
	}
}else{
	$array=array('res'=>'DUI');
	echo json_encode($array);
}


 ?>
<?php 
declare (strict_types = 1);
require_once ('../../models/CRUD.php');
require_once ('../../models/login.php');
// require_once '../../models/correo.php';
$crud=new CRUD();
$login = new login();
// $coreo= new Correo();

$opcion = $_POST['opcion']  ?? '';
$idUsuario = $_POST['id'] ?? '';
$idPersona = $_POST['idpersona'] ?? '';
$correo = strtoupper($_POST['txt_correo'] ?? '');
$rol = strtoupper($_POST['txt_rol'] ?? '');
$contrasena = $_POST['txt_contra'] ?? '';

if(!empty($opcion)){
	switch ($opcion) {
		case 'editar':
			if(!empty($_POST['id']) && !empty($_POST['idpersona']) && !empty($_POST['txt_correo']) && !empty($_POST['txt_rol'])){	

				$resultado=$crud->existencia('idUsuario','usuario','estado=1 && idPersona='.$idPersona);
				if($resultado['total'] == 0 || $resultado['idUsuario'] == $idUsuario){
					if($contrasena == ''){
						$params=$idUsuario.",".$idPersona.",'".$rol."','".$correo."'";
						$crud->modificar('SP_modificar_Usuario',$params);
					}else{
						$contra=$login->encriptar($contrasena);
						$params=$idUsuario.",".$idPersona.",'".$rol."','".$contra."','".$correo."'";
						$crud->modificar('SP_modificar_Usuario_Con_contra',$params);
					}
				}else{
					echo 'DUI';
				}
			}else{
				echo "VACIO";
			}
		break;
		case 'eliminar':
			if(!empty($_POST['id'])){
				$resultado=$crud->existencia('idUsuario','usuario','estado=1 AND rol="ADMINISTRADOR" AND verificacion="VERIFICADO"');
				if($resultado['total'] == 1 && $resultado['idUsuario']==$idUsuario){
					echo 'USUARIOS';
				}else{
					$params=$idUsuario;
					$crud->modificar('SP_eliminar_Usuario',$params);
				}
			}else{
				echo "VACIO";
			}
		break;
		case 'agregar': 
			if(!empty($_POST['idpersona']) && !empty($_POST['txt_correo']) && 
				!empty($_POST['txt_rol'])){

				$resultado=$crud->existencia('idUsuario','usuario','estado=1 && idPersona='.$idPersona);
				if($resultado['total'] == 0){
					// ------------------------------
					// $contrasena= $login->generarContra();
					$contra=$login->encriptar('usuarioPrueba');
					$cadVery='1234567890';
					$params=$idPersona.",'".$rol."','".$correo."','".$contra."','".$cadVery."'";
					$crud->agregar('SP_agregar_Usuario',$params);
					// $id=$crud->ultimo_id('idUsuario','usuario');
					// $coreo->setContrasena($contrasena);
					// $coreo->setCorreo($correo);
					// $coreo->setIdUsuario($id['id']);
					// $coreo->enviarCorreo();
					// correo de validacion
				}else{
					echo 'DUI';
				}				
			}else{
				echo "VACIO";			
			}
		break;
	}
}else{
	echo "VACIO";
}
?>
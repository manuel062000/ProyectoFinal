<?php 
require_once '../../models/login.php';
session_start();

$login = new login();

$contra=$_POST['contra'];
$correo=strtoupper($_POST['correo'] ?? '');

$login->setContrasena($contra);
$login->setCorreo($correo);
$string = $login->logiar();

$cadena=explode(' -- ',$string);
if($cadena[0]=='BIEN'){
	$_SESSION['usuario']=array('id'=>$cadena[1],'rol'=>$cadena[2]);
}

echo $cadena[0];

 ?>
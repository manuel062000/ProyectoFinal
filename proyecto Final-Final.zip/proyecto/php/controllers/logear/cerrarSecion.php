<?php 
session_start();
session_unset();
session_destroy();

if(isset($_SESSION['usuario']['id'])){
	echo 'FAIL';
}else{
	echo 'BIEN';
}
 ?>
<?php 
session_start();
	if(!isset($_SESSION['usuario']['id'])){
		echo '<script>window.parent.document.location.href = "../../index.php";</script>';
	}else if($_SESSION['usuario']['rol']!='ADMINISTRADOR'){
		echo '<script>window.parent.document.location.href = "dashboard.php";</script>';
	}
	if(!isset($_GET['d'])){
		echo '<script>window.parent.document.location.href = "dashboard.php";</script>';
	}
 ?>
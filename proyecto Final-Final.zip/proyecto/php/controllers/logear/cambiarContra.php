<?php 
session_start();
require_once '../../models/login.php';

$votar=new Login();

$contraA=$_POST['ContraAn'];
$contraN=$_POST['ContraNue'];
$idUs=$_SESSION['usuario']['id'];

$string = $votar->cambiarContra($contraN,$contraA,$idUs);
echo $string;


 ?>
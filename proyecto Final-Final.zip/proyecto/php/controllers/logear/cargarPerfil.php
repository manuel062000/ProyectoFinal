<?php 
date_default_timezone_set('America/El_Salvador');
session_start();
require_once '../../models/CRUD.php';
$crud=new CRUD();
$resultado=$crud->llenarSelect('u.correo,p.nombre,p.apellido,p.fecha_nac,p.genero,p.img','usuario as u INNER JOIN persona as p WHERE u.idPersona=p.idPersona AND u.idUsuario='.$_SESSION['usuario']['id'].' AND u.estado=1');

$retornar=array('c'=>$resultado[0]['correo'],'n'=>$resultado[0]['nombre'],'a'=>$resultado[0]['apellido'],'fn'=>$resultado[0]['fecha_nac'],'g'=>$resultado[0]['genero'],'fa'=>date('Y/m/d'),'rol'=>$_SESSION['usuario']['rol'],'img'=>$resultado[0]['img']);
echo json_encode($retornar);

?>
<?php 
require_once '../../models/CRUD.php';
session_start();
$crud=new CRUD();
$consulta = $crud->llenarSelect('p.img,p.nombre,p.apellido,u.rol','usuario as u INNER JOIN persona as p WHERE u.idUsuario='.$_SESSION['usuario']['id'].' && p.idPersona=u.idPersona');
$array=array('img'=>$consulta[0]['img'],'nombre'=>$consulta[0]['nombre'],'apellido'=>$consulta[0]['apellido'],'rol'=>$consulta[0]['rol']);
echo json_encode($array);

 ?>
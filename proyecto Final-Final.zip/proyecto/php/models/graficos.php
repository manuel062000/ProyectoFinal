<?php 
declare(strict_types = 1);
require_once 'Conexion.php';
class Graficos extends Conexion
{
    private $idMunicipio;
    //-------- metodo get atributo idMunicipio --------
    public function getIdMunicipio(){return $this->idMunicipio;}
    //-------- metodo set idMunicipio --------
    public function setIdMunicipio($idMunicipio){$this->idMunicipio = $idMunicipio;return $this;}
    private $idDepartamento;
    //-------- metodo get atributo idDepartamento --------
    public function getIdDepartamento(){return $this->idDepartamento;}
    //-------- metodo set idDepartamento --------
    public function setIdDepartamento($idDepartamento){$this->idDepartamento = $idDepartamento;return $this;}
    private $idPartido;
    //-------- metodo get atributo idPartido --------
    public function getIdPartido(){return $this->idPartido;}
    //-------- metodo set idPartido --------
    public function setIdPartido($idPartido){$this->idPartido = $idPartido;return $this;}
    public function __construct()
    {
       parent::__construct(); 
       $this->idMunicipio = '';
       $this->idDepartamento = '';
       $this->idPartido = '';
    }
    
    public function getAll():array
    {
    	$query="SELECT p.abreviacion AS nombre,COUNT(v.idPartido) as total FROM votos as v INNER JOIN partido as p WHERE v.idPartido=p.idPartido AND p.estado=1 GROUP BY p.nombre;";
    	$retorno = $this->ConsultaSimple($query);
    	
    	if(COUNT($retorno)>0){
            $result3=$this->ConsultaSimple("SELECT abreviacion as nombre FROM partido WHERE estado=1");
            foreach ($result3 as $value) {
                $existe=true;
                foreach ($retorno as $values) {
                    if(isset($values['nombre'])){
                        if($value['nombre']==$values['nombre']){
                            $existe=false;
                            break;
                        }
                    }
                    
                }
                if($existe){
                    $retorno[COUNT($retorno)]['nombre']=$value['nombre'];
                    $retorno[COUNT($retorno)-1]['total']='0';
                }
            }
    		return $retorno;
    	}else{
    		$query="SELECT abreviacion AS nombre FROM partido WHERE estado=1;";
    		$consulta=$this->ConsultaSimple($query);
    		$tamanio=COUNT($consulta);
			for ($i = 0; $i <$tamanio ; $i++) {
				$consulta[$i]['total']=null;
			}
    		return $consulta;
    	}
    }
    public function getDatos():array
    {
        $query="";
        $query2="";
        $ban=false;
        if($this->getIdPartido()!=''){//por partido
            if($this->getIdDepartamento()!=''){//por departamento
                $query= "SELECT COUNT(*) AS Total FROM votos as v INNER JOIN juntareceptora as jr INNER JOIN municipio as m WHERE v.idPartido=".$this->getIdPartido()." AND v.idJuntaReceptora=jr.idJuntaReceptora AND jr.idMunicipio=m.idMunicipio AND m.idDepartamento=".$this->getIdDepartamento();

                $query2="SELECT COUNT(*) AS Total FROM persona as p INNER JOIN municipio as m WHERE p.idMunicipio=m.idMunicipio AND m.idDepartamento=".$this->getIdDepartamento();  

            }
            else if($this->getIdMunicipio()!=''){//por municipio
                $query= "SELECT COUNT(*) AS Total FROM votos as v INNER JOIN juntareceptora as jr WHERE v.idPartido=".$this->getIdPartido()." AND v.idJuntaReceptora=jr.idJuntaReceptora AND jr.idMunicipio=".$this->getIdMunicipio();
                $query2="SELECT COUNT(*) AS Total FROM persona WHERE idMunicipio=".$this->getIdMunicipio(); 

            }else{//total
                $query= "SELECT COUNT(*) AS Total FROM votos WHERE idPartido=".$this->getIdPartido();
                $query2="SELECT COUNT(*) AS Total FROM persona";
            }
            $ban=true;
         }
        else if($this->getIdDepartamento()!=''){//por departamento
            $query= "SELECT COUNT(*) AS Total,(SELECT abreviacion FROM partido WHERE idPartido=v.idPartido) AS nombre FROM votos as v INNER JOIN juntareceptora as jr INNER JOIN municipio as m WHERE v.idJuntaReceptora=jr.idJuntaReceptora AND jr.idMunicipio=m.idMunicipio AND m.idDepartamento=".$this->getIdDepartamento()." GROUP BY v.idPartido";
            $query2="SELECT COUNT(*) AS Total FROM persona as p INNER JOIN municipio as m WHERE p.idMunicipio=m.idMunicipio AND m.idDepartamento=".$this->getIdDepartamento();

        }
        else if($this->getIdMunicipio()!=''){//por municipio
            $query= "SELECT COUNT(*) AS Total,(SELECT abreviacion FROM partido WHERE idPartido=v.idPartido) AS nombre FROM votos as v INNER JOIN juntareceptora as jr WHERE v.idJuntaReceptora=jr.idJuntaReceptora AND jr.idMunicipio=".$this->getIdMunicipio()." GROUP BY v.idPartido";
            $query2="SELECT COUNT(*) AS Total FROM persona WHERE idMunicipio=".$this->getIdMunicipio();

        }
        else{//total
            $ban=true;
            $query= "SELECT COUNT(*) AS Total FROM votos";
            $query2="SELECT COUNT(*) AS Total FROM persona";
        }

        $resul1 = $this->ConsultaSimple($query);
        $resul2 = $this->ConsultaSimple($query2);

        if($ban){
            if($resul1[0]['Total']=='0'){
                $resul1[0]['nombre']='Ya ejercio sufragio';
                $resul1[1]['nombre']='No han ejercido sufragio';
                $resul1[1]['Total']='100';
                $resul1[2]=array('Total'=>100);
            }else{
                $resul1[0]['nombre']='Ya ejercio sufragio';
                $resul1[1]['nombre']='No han ejercido sufragio';
                $resul1[1]['Total']=$resul2[0]['Total']-$resul1[0]['Total'];
                $resul1[2]=$resul2[0];
            }
            // return array('total'=>$resul1[0]['Total'],'totalP'=>$resul2[0]['Total']);
            return $resul1;
        }else{
            $result3=$this->ConsultaSimple("SELECT abreviacion as nombre FROM partido WHERE estado=1");
            $con=0;
            foreach ($result3 as $value) {
                $existe=true;
                foreach ($resul1 as $values) {
                    if(isset($values['nombre'])){
                        if($value['nombre']==$values['nombre']){
                            $existe=false;
                            $con++;
                            break;
                        }
                    }
                    
                }
                if($existe){
                    $resul1[COUNT($resul1)]['nombre']=$value['nombre'];
                    $resul1[COUNT($resul1)-1]['Total']='0';
                }
            }
            if($resul2[0]['Total']=='0'){
                $resul1[COUNT($resul1)]=array('nombre'=>'No an ejercido sufragio','Total'=>'100');
                
                $resul1[COUNT($resul1)]=array('Total'=>'100');
            }else{
                if($con==0){
                    $resul1=array();
                    $resul1[0]=array('nombre'=>'No han ejercido sufragio','Total'=>'100');
                }
                $resul1[COUNT($resul1)]=$resul2[0]; 
            }
            return $resul1;
        }
    }
}
 ?>
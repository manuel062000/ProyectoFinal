<?php 
date_default_timezone_set('America/El_Salvador');
require_once 'Conexion.php';

class Historial extends Conexion
{
    
    public function __construct()
    {
     	parent::__construct();   
    }

    public function historial($SP,$param){
    	$tipo = explode('_',$SP);
    	$id = explode(',',$param);
    	if($tipo[2]=='CV'){
    		$this->guardar(1,$tipo[1],$id[0],'idMunicipio','Municipio');

    	}else if($tipo[2]=='JR'){
    		$this->guardar(2,$tipo[1],$id[0],'idJuntaReceptora','JuntaReceptora');

    	}else if($tipo[2]=='Per'){
    		$this->guardar(3,$tipo[1],$id[0],'idPersona','Persona');

    	}else if($tipo[2]=='PP'){
    		$this->guardar(4,$tipo[1],$id[0],'idPartido','Partido');

    	}else if($tipo[2]=='Usuario'){
    		$this->guardar(5,$tipo[1],$id[0],'idUsuario','Usuario');
    	}
    }
    public function ultimoId($campo,$tabla){
    	return $this->ConsultaSimple("SELECT MAX({$campo}) AS id FROM {$tabla};");
    }
    public function guardar($tipo,$modificacion,$idModi,$campo,$tabla){
    	session_start();
    	if($modificacion=='agregar'){
    		$id=$this->ultimoId($campo,$tabla);
    		$this->db->query("INSERT INTO Historial  VALUES (null,".$_SESSION['usuario']['id'].",".$id[0]['id'].",".$tipo.",'AGREGAR','".date('Y/m/d')."')");
    	}else if($modificacion=='eliminar'){
    		$this->db->query("INSERT INTO Historial VALUES (null,".$_SESSION['usuario']['id'].",".$idModi.",".$tipo.",'ELIMINAR','".date('Y/m/d')."')");
    	}else{
    		$this->db->query("INSERT INTO Historial VALUES (null,".$_SESSION['usuario']['id'].",".$idModi.",".$tipo.",'MODIFICAR','".date('Y/m/d')."')");
    	}
    }
    public function mostrarPer($termino,$comienzo,$longitud):array
    {
        if($termino==''){
            $query="SELECT p.DUI AS duiU,p.nombre AS nombreU,p.apellido AS apellidoU,(SELECT DUI FROM persona AS pp WHERE pp.idPersona=h.id)AS duiP,(SELECT nombre FROM persona AS pp WHERE pp.idPersona=h.id)AS nombreP,(SELECT apellido FROM persona AS pp WHERE pp.idPersona=h.id)AS apellidoP,h.modificacion AS accion,h.fecha FROM historial AS h INNER JOIN usuario as u INNER JOIN persona as p WHERE tipo=3 AND u.idUsuario=h.idUsuario AND p.idPersona=u.idPersona LIMIT $comienzo,$longitud;";
        }else{
             $query="SELECT p.DUI AS duiU,p.nombre AS nombreU,p.apellido AS apellidoU,(SELECT DUI FROM persona AS pp WHERE pp.idPersona=h.id)AS duiP,(SELECT nombre FROM persona AS pp WHERE pp.idPersona=h.id)AS nombreP,(SELECT apellido FROM persona AS pp WHERE pp.idPersona=h.id)AS apellidoP,h.modificacion AS accion,h.fecha FROM historial AS h INNER JOIN usuario as u INNER JOIN persona as p WHERE tipo=3 AND u.idUsuario=h.idUsuario AND p.idPersona=u.idPersona AND (h.modificacion LIKE '$termino' OR h.fecha LIKE '$termino')";
        }
        return $this->ConsultaSimple($query);
    }
    public function mostrarUsuario($termino,$comienzo,$longitud):array
    {
        if($termino==''){
            $query="SELECT p.DUI AS duiU,p.nombre AS nombreU,p.apellido AS apellidoU,(SELECT per.DUI FROM usuario as usu INNER JOIN persona as per WHERE usu.idUsuario=h.id AND per.idPersona=usu.idPersona)AS duiP,(SELECT per.nombre FROM usuario as usu INNER JOIN persona as per WHERE usu.idUsuario=h.id AND per.idPersona=usu.idPersona)AS nombreP,(SELECT per.apellido FROM usuario as usu INNER JOIN persona as per WHERE usu.idUsuario=h.id AND per.idPersona=usu.idPersona)AS apellidoP,h.modificacion AS accion,h.fecha FROM historial AS h INNER JOIN usuario as u INNER JOIN persona as p WHERE tipo=5 AND u.idUsuario=h.idUsuario AND p.idPersona=u.idPersona LIMIT $comienzo,$longitud;";
        }else{
             $query="SELECT p.DUI AS duiU,p.nombre AS nombreU,p.apellido AS apellidoU,(SELECT per.DUI FROM usuario as usu INNER JOIN persona as per WHERE usu.idUsuario=h.id AND per.idPersona=usu.idPersona)AS duiP,(SELECT per.nombre FROM usuario as usu INNER JOIN persona as per WHERE usu.idUsuario=h.id AND per.idPersona=usu.idPersona)AS nombreP,(SELECT per.apellido FROM usuario as usu INNER JOIN persona as per WHERE usu.idUsuario=h.id AND per.idPersona=usu.idPersona)AS apellidoP,h.modificacion AS accion,h.fecha FROM historial AS h INNER JOIN usuario as u INNER JOIN persona as p WHERE tipo=5 AND u.idUsuario=h.idUsuario AND p.idPersona=u.idPersona AND (h.modificacion LIKE '$termino' OR h.fecha LIKE '$termino')";
        }
        return $this->ConsultaSimple($query);
    }
    public function mostrarCV($termino,$comienzo,$longitud):array
    {
        if($termino==''){
            $query="SELECT p.DUI AS duiU,p.nombre AS nombreU,p.apellido AS apellidoU,(SELECT dep.nombre FROM municipio as m INNER JOIN departamento as dep WHERE m.idDepartamento=dep.idDepartamento AND m.idMunicipio=h.id)AS dep,(SELECT m.nombreCentroVotacion FROM municipio AS m WHERE m.idMunicipio=h.id)AS nombreCV,h.modificacion AS accion,h.fecha FROM historial AS h INNER JOIN usuario as u INNER JOIN persona as p WHERE tipo=1 AND u.idUsuario=h.idUsuario AND p.idPersona=u.idPersona LIMIT $comienzo,$longitud;";
        }else{
             $query="SELECT p.DUI AS duiU,p.nombre AS nombreU,p.apellido AS apellidoU,(SELECT dep.nombre FROM municipio as m INNER JOIN departamento as dep WHERE m.idDepartamento=dep.idDepartamento AND m.idMunicipio=h.id)AS dep,(SELECT m.nombreCentroVotacion FROM municipio AS m WHERE m.idMunicipio=h.id)AS nombreCV,h.modificacion AS accion,h.fecha FROM historial AS h INNER JOIN usuario as u INNER JOIN persona as p WHERE tipo=1 AND u.idUsuario=h.idUsuario AND p.idPersona=u.idPersona AND (h.modificacion LIKE '$termino' OR h.fecha LIKE '$termino')";
        }
        return $this->ConsultaSimple($query);
    }
    public function mostrarPP($termino,$comienzo,$longitud):array
    {
        if($termino==''){
            $query="SELECT p.DUI AS duiU,p.nombre AS nombreU,p.apellido AS apellidoU,(SELECT pp.abreviacion FROM partido as pp WHERE pp.idPartido=h.id)AS pp,h.modificacion AS accion,h.fecha FROM historial AS h INNER JOIN usuario as u INNER JOIN persona as p WHERE tipo=4 AND u.idUsuario=h.idUsuario AND p.idPersona=u.idPersona LIMIT $comienzo,$longitud;";
        }else{
             $query="SELECT p.DUI AS duiU,p.nombre AS nombreU,p.apellido AS apellidoU,(SELECT pp.abreviacion FROM partido as pp WHERE pp.idPartido=h.id)AS pp,h.modificacion AS accion,h.fecha FROM historial AS h INNER JOIN usuario as u INNER JOIN persona as p WHERE tipo=4 AND u.idUsuario=h.idUsuario AND p.idPersona=u.idPersona AND (h.modificacion LIKE '$termino' OR h.fecha LIKE '$termino')";
        }
        return $this->ConsultaSimple($query);
    }
    public function mostrarJR($termino,$comienzo,$longitud):array
    {
        if($termino==''){
            $query="SELECT p.DUI AS duiU,p.nombre AS nombreU,p.apellido AS apellidoU,(SELECT m.nombre FROM juntareceptora as jr INNER JOIN municipio as m WHERE jr.idJuntaReceptora=h.id AND jr.idMunicipio=m.idMunicipio)AS mun,(SELECT jr.nombre FROM juntareceptora AS jr WHERE jr.idJuntaReceptora=h.id)AS JR,h.modificacion AS accion,h.fecha FROM historial AS h INNER JOIN usuario as u INNER JOIN persona as p WHERE tipo=2 AND u.idUsuario=h.idUsuario AND p.idPersona=u.idPersona LIMIT $comienzo,$longitud;";
        }else{
             $query="SELECT p.DUI AS duiU,p.nombre AS nombreU,p.apellido AS apellidoU,(SELECT m.nombre FROM juntareceptora as jr INNER JOIN municipio as m WHERE jr.idJuntaReceptora=h.id AND jr.idMunicipio=m.idMunicipio)AS mun,(SELECT jr.nombre FROM juntareceptora AS jr WHERE jr.idJuntaReceptora=h.id)AS JR,h.modificacion AS accion,h.fecha FROM historial AS h INNER JOIN usuario as u INNER JOIN persona as p WHERE tipo=2 AND u.idUsuario=h.idUsuario AND p.idPersona=u.idPersona AND (h.modificacion LIKE '$termino' OR h.fecha LIKE '$termino')";
        }
        return $this->ConsultaSimple($query);
    }
   
}

 ?>
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';
require_once 'Conexion.php';

class Correo extends Conexion
{
    private $correo;
    private $contrasena;
    private $idUsuario;
    //-------- metodo get atributo idUsuario --------
    public function getIdUsuario(){return $this->idUsuario;}
    //-------- metodo set idUsuario --------
    public function setIdUsuario($idUsuario){$this->idUsuario = $idUsuario;return $this;}
    //-------- metodo get atributo contrasena --------
    public function getContrasena(){return $this->contrasena;}
    //-------- metodo set contrasena --------
    public function setContrasena($contrasena){$this->contrasena = $contrasena;return $this;}
    //-------- metodo get atributo correo --------
    public function getCorreo(){return $this->correo;}
    //-------- metodo set correo --------
    public function setCorreo($correo){$this->correo = $correo;return $this;}


    public function enviarCorreo(){
            // Instantiation and passing `true` enables exceptions
        $mail = new PHPMailer(true);

        try {
            //Server settings
            $mail->SMTPDebug = 0;// ver los errores 0 es desactivado
            $mail->isSMTP();                                            // Set mailer to use SMTP
            $mail->Host       = 'smtp.gmail.com';// direccion del servidor del correo a utilizar
            $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
            $mail->Username   = 'sis13b.proyecto2019@gmail.com';// correo a utilizar para enviar el mensaje
            $mail->Password   = 'SIS132019';//contraseña del correo a utilizar para enviar el mensaje                             
            $mail->SMTPSecure = 'TLS';                                  // Enable TLS encryption, `ssl` also accepted
            $mail->Port       = 587;                                    // TCP port to connect to
         

            //Recipients
            $mail->setFrom('sis13b.proyecto2019@gmail.com');//quien envia el correo
            $mail->addAddress($this->getCorreo());//para quien es el correo

            // Attachments
            /*$mail->addAttachment('/var/tmp/file.tar.gz', 'new.jpg');*/ //para adjuntar archivos

            // Content
            $mail->isHTML(true);//permite insertar html en el correo a enviar
            $mail->Subject = '<h4>Activación de cuenta</h4>';//asunto
            $mail->Body    =    '<strong>Usuario:</strong>&nbsp;'.$this->getCorreo().'
                                <br><strong>Contraseña:</strong>&nbsp;'.$this->getContrasena().'
                                <br><br><br><a href="http://localhost/proyecto/php/controllers/correo/nuevoUsuario.php?id='.$this->getIdUsuario().'">click aquí para activar tú cuenta...</a>';//cuerpo
            /*$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';*///mensaje alternativo

            if($mail->send()){
                return 1;
            }else{
                return 0;
            }
        } catch (Exception $e) {
            return 0;
        }
    }
    public function Activar(){
        try {
            $query="UPDATE usuario SET verificacion='VERIFICADO' WHERE idUsuario=:id";
            $consulta = $this->db->prepare($query);
            $array= array(':id',$this->getIdUsuario());
            $consulta->execute($array);
            if($consulta->rowCount()){
                return 'bien';
            }else{
                return 'error';
            }
        } catch (PDOException $e) {
            return 'error';
        }
    }
}
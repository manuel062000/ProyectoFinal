<?php 
declare (strict_types = 1);
class tablas
{
		//---------------------IMPRECION DE TABLAS--------------------------
    public function showTableMunicipio(array $array): string
    {
        $html = '';
        if (count($array)) {
            $html = '<table class="table table-striped" id="table">
                        <thead>
                            <th class="d-none"></th>
                            <th class="d-none"></th>
                            <th>DEPARTAMENTO</th>
                            <th>MUNICIPIO</th>
                            <th>NOMBRE CENTRO DE VOTACION</th>
                            <th class="text-center">OPCIONES</th>
                        </thead>

                        <tbody>
                     ';
            foreach ($array as $value) {
                $html .= '  <tr>
                        <td class="d-none">' . $value['idMunicipio'] . '</td>
                        <td class="d-none">' . $value['idDepartamento'] . '</td>
                        <td>' . $value['nombreDepartamento'] . '</td>
                        <td>' . $value['nombre'] . '</td>
                        <td>' . $value['nombreCentroVotacion'] . '</td>
                        <td class="text-center">
                            <button title="Ver este Municipio" class="ver btn btn-success" data-toggle="modal" data-target="#ventanaModal">
                                 <i class="fal fa-eye"></i>
                            </button>

                            <button title="Editar este Municipio" class="editar btn btn-secondary" data-toggle="modal" data-target="#ventanaModal">
                                 <i class="far fa-edit"></i>
                            </button>

                            <button title="Eliminar este Municipio" type="button" class="eliminar btn btn-danger" data-toggle="modal" data-target="#ventanaModal">
                                <i class="far fa-trash-alt"></i>
                            </button>
                        </td>
                        </tr>
                         ';
            }
            $html .= '  </tbody>
                    </table>';
        } else {
            $html = '<h4 class="text-center">No hay datos...</h4>';
        }
        return $html;
    }
    //-----------------------------
    public function showTableJuntaReceptora(array $array): string
    {
        $html = '';
        if (count($array)) {
            $html = '<table class="table table-striped" id="table">
                        <thead>
                            <th class="d-none"></th>
                            <th class="d-none"></th>
                            <th class="d-none"></th>
                            <th>NOMBRE</th>
                            <th>NOMBRE CENTRO VOTACION</th>
                            <th>DEPARTAMENTO</th>
                            <th class="text-center">OPCIONES</th>
                        </thead>

                        <tbody>
                     ';
            foreach ($array as $value) {
                $html .= '  <tr>
                        <td class="d-none">' . $value['idJuntaReceptora'] . '</td>
                        <td class="d-none">' . $value['idDepartamento'] . '</td>
                        <td class="d-none">' . $value['idMunicipio'] . '</td>
                        <td>' . $value['nombre'] . '</td>
                        <td>' . $value['nombreCentroVotacion'] . '</td>
                        <td>' . $value['departamento'] . '</td>
                        <td class="text-center">
                            <button title="Ver esta junta receptora" class="ver btn btn-success" data-toggle="modal" data-target="#ventanaModal">
                                 <i class="fal fa-eye"></i>
                            </button>

                            <button title="Editar esta junta receptora" class="editar btn btn-secondary" data-toggle="modal" data-target="#ventanaModal">
                                 <i class="far fa-edit"></i>
                            </button>

                            <button title="Eliminar esta junta receptora" type="button" class="eliminar btn btn-danger" data-toggle="modal" data-target="#ventanaModal">
                                <i class="far fa-trash-alt"></i>
                            </button>
                        </td>
                        </tr>
                         ';
            }
            $html .= '  </tbody>
                    </table>';
        } else {
            $html = '<h4 class="text-center">No hay datos...</h4>';
        }
        return $html;
    }
    public function showTablePersona(array $array): string
    {
        $html = '';
        if (count($array)) {
            $html = '<table class="table table-striped" id="table">
                        <thead>
                            <th class="d-none"></th>
                            <th class="d-none"></th>
                            <th class="d-none"></th>
                            <th class="d-none"></th>
                            <th class="text-center">DUI</th>
                            <th>NOMBRES</th>
                            <th>APELLIDOS</th>
                            <th>DEPARTAMENTO</th>
                            <th>MUNICIPIO</th>
                            <th class="d-none">GENERO</th>
                            <th class="d-none">FECHA DE NACIMIENTO</th>
                            <th>EXPIRACION DE DUI</th>
                            <th class="d-none">DIRECCION</th>
                            <th class="d-none">ESTADO CIVIL</th>
                            <th class="d-none">SALVADOREÑO POR</th>
                            <th class="text-center">OPCIONES</th>
                        </thead>

                        <tbody>
                     ';
            foreach ($array as $value) {
                $html .= '  <tr>
                        <td class="d-none">' . $value['idPersona'] . '</td>
                        <td class="d-none">' . $value['idDepartamento'] . '</td>
                        <td class="d-none">' . $value['idMunicipio'] . '</td>
                        <td class="d-none">' . $value['img'] . '</td>
                        <td>' . $value['DUI'] . '</td>
                        <td>' . $value['nombre'] . '</td>
                        <td>' . $value['apellido'] . '</td>
                        <td>' . $value['departamento'] . '</td>
                        <td>' . $value['municipio'] . '</td>
                        <td class="d-none">' . $value['genero'] . '</td>
                        <td class="d-none">' . $value['fecha_nac'] . '</td>
                        <td>' . $value['fecha_expe_dui'] . '</td>
                        <td class="d-none">' . $value['direccion'] . '</td>
                        <td class="d-none">' . $value['estadoCivil'] . '</td>
                        <td class="d-none">' . $value['salvadorenoPor'] . '</td>
                        <td class="text-center">
                            <button title="Ver a esta persona" class="ver btn btn-success" data-toggle="modal" data-target="#ventanaModal">
                                 <i class="fal fa-eye"></i>
                            </button>

                            <button title="Editar a esta persona" class="editar btn btn-secondary" data-toggle="modal" data-target="#ventanaModal">
                                 <i class="far fa-edit"></i>
                            </button>

                            <button title="Eliminar a esta persona" type="button" class="eliminar btn btn-danger" data-toggle="modal" data-target="#ventanaModal">
                                <i class="far fa-trash-alt"></i>
                            </button>
                        </td>
                        </tr>
                         ';
            }
            $html .= '  </tbody>
                    </table>';
        } else {
            $html = '<h4 class="text-center">No hay datos...</h4>';
        }
        return $html;
    }
    //---------------------
    public function showTablePP(array $array): string
    {
        $html = '';
        if (count($array)) {
            $html = '<table class="table table-striped" id="table">
                        <thead>
                            <th class="d-none"></th>
                            <th class="d-none"></th>
                            <th class="d-none"></th>
                            <th class="d-none"></th>
                            <th>NOMBRE</th>
                            <th>SIGLAS</th>
                            <th>CANDIDATO PRESIDENTE</th>
                            <th>DUI</th>
                            <th class="text-center">OPCIONES</th>
                        </thead>

                        <tbody>
                     ';
            foreach ($array as $value) {
                $html .= '  <tr>
                        <td class="d-none">' . $value['idPartido'] . '</td>
                        <td class="d-none">' . $value['idPersona'] . '</td>
                        <td class="d-none">' . $value['imgPP'] . '</td>
                        <td class="d-none">' . $value['imgP'] . '</td>
                        <td>' . $value['nombre'] . '</td>
                        <td>' . $value['abreviacion'] . '</td>
                        <td>' . $value['presidente'] . '</td>
                        <td>' . $value['DUI'] . '</td>
                        <td class="text-center">
                            <button title="Ver este Partido Politico" class="ver btn btn-success" data-toggle="modal" data-target="#ventanaModal">
                                 <i class="fal fa-eye"></i>
                            </button>

                            <button title="Editar este Partido Politico" class="editar btn btn-secondary" data-toggle="modal" data-target="#ventanaModal">
                                 <i class="far fa-edit"></i>
                            </button>

                            <button title="Eliminar este Partido Politico" type="button" class="eliminar btn btn-danger" data-toggle="modal" data-target="#ventanaModal">
                                <i class="far fa-trash-alt"></i>
                            </button>
                        </td>
                        </tr>
                         ';
            }
            $html .= '  </tbody>
                    </table>';
        } else {
            $html = '<h4 class="text-center">No hay datos...</h4>';
        }
        return $html;
    }
    //-----------------------------
    public function showTableUsuario(array $array): string
    {
        $html = '';
        if (count($array)) {
            $html = '<table class="table table-striped" id="table">
                        <thead>
                            <th class="d-none"></th>
                            <th class="d-none"></th>
                            <th class="d-none"></th>
                            <th>DUI</th>
                            <th>CORREO</th>
                            <th>NOMBRE</th>
                            <th>ROL</th>
                            <th>ESTADO</th>
                            <th class="text-center">OPCIONES</th>
                        </thead>

                        <tbody>
                     ';
            foreach ($array as $value) {
                if($value['verificacion']=='VERIFICADO'){
                    $very='<td class="text-success font-weight-bold">VERIFICADO</td>';
                }else{
                    $very='<td class="text-danger font-weight-bold">DESACTIVADO</td>';
                }
                $html .= '  <tr>
                        <td class="d-none">' . $value['idUsuario'] . '</td>
                        <td class="d-none">' . $value['idPersona'] . '</td>
                        <td class="d-none">' . $value['img'] . '</td>
                        <td>' . $value['DUI'] . '</td>
                        <td>' . $value['correo'] . '</td>
                        <td>' . $value['nombre'] . '</td>
                        <td>' . $value['rol'] . '</td>
                        ' . $very . '
                        <td class="text-center">
                            <button title="Ver este Usuario" class="ver btn btn-success" data-toggle="modal" data-target="#ventanaModal">
                                 <i class="fal fa-eye"></i>
                            </button>

                            <button title="Editar este Usuario" class="editar btn btn-secondary" data-toggle="modal" data-target="#ventanaModal">
                                 <i class="far fa-edit"></i>
                            </button>

                            <button title="Eliminar este Usuario" type="button" class="eliminar btn btn-danger" data-toggle="modal" data-target="#ventanaModal">
                                <i class="far fa-trash-alt"></i>
                            </button>
                        </td>
                        </tr>
                         ';
            }
            $html .= '  </tbody>
                    </table>';
        } else {
            $html = '<h4 class="text-center">No hay datos...</h4>';
        }
        return $html;
    }
    //--------------------------------------
    public function showBanderasPartidos(array $array): string
    {
        $html='';
        if(count($array)){
            foreach ($array as $value) {
                $html.='<div class="col-md-6 col-sm-12 p-1">
                        <div id="eVcontainer">  
                            <div class="product-image"> 
                                <input type="hidden" value="'.$value['idPartido'].'">
                                <img src="../../images/'.$value['img'].'" alt="Omar Dsoky">
                                <div class="equisVotar">
                                    <img class="equisVotar" src="../../images/equis.png" alt="Omar Dsoky">
                                </div>
                                <div class="info">
                                    <h2>Partido Politico</h2>
                                    <ul>
                                        <li>
                                            <strong>
                                                Nombre: 
                                            </strong>
                                            '.$value['nombre'].'
                                        </li>
                                        <li>
                                            <strong>
                                                Abreviatura: 
                                            </strong>
                                            '.$value['abreviacion'].'
                                        </li>
                                        <li>
                                            <strong class="d-block">
                                                Candidato Presidente: 
                                            </strong>
                                            '.$value['candidato'].'
                                        </li>
                                    </ul>
                                    <p style="text-align: center;">Click Para seleccionar</p>
                                </div>
                            </div>
                        </div>
                    </div>';
            }
            $html.='<div class="col-12">
                        <button class="btn btn-success btn-lg d-block mb-0 m-auto" style="width: 350px;" id="btn_votar" disabled title="Seleccione un partido politico">
                            Votar
                        </button>
                    </div>';
        }else{
            $html='<h3 class="text-center col-12 mt-5">No se encontro ningun partido politico...</h3>';
        }
        return $html;
    }
    //-----------------------------
    public function showTablePerJr(array $array): string
    {
        $html = '';
        if (count($array)) {
            $html = '<table class="table table-striped" id="table">
                        <thead>
                            <th>DUI</th>
                            <th>NOMBRE</th>
                            <th>APEELIDOS</th>
                            <th>JUNTA RECEPTORA</th>
                        </thead>

                        <tbody>
                     ';
            foreach ($array as $value) {
                $html .= '  <tr>
                        <td>' . $value['DUI'] . '</td>
                        <td>' . $value['nombre'] . '</td>
                        <td>' . $value['apellido'] . '</td>
                        <td>' . $value['jr'] . '</td>
                        </tr>
                         ';
            }
            $html .= '  </tbody>
                    </table>';
        } else {
            $html = '<h4 class="text-center">No hay datos...</h4>';
        }
        return $html;
    }
    //  ::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    //-----------------------------
    
//------------------------------------------------------------------
//------------------------------------------------------------------
}



?>
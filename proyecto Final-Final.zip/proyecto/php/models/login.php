<?php 
declare(strict_types = 1);
require_once 'Conexion.php';




class Login extends Conexion
{
    private $idUsuario;
    private $idPersona;
    private $correo;
    private $contrasena;
    private $cadenaVerificacio;
    private $rol;
    private $verificacion;

    //-------- metodo get atributo idUsuario --------
    public function getIdUsuario(){return $this->idUsuario;}
    //-------- metodo set idUsuario --------
    public function setIdUsuario($idUsuario){$this->idUsuario = $idUsuario;return $this;}
    //-------- metodo get atributo idPersona --------
    public function getIdPersona(){return $this->idPersona;}
    //-------- metodo set idPersona --------
    public function setIdPersona($idPersona){$this->idPersona = $idPersona;return $this;}
    //-------- metodo get atributo correo --------
    public function getCorreo(){return $this->correo;}
    //-------- metodo set correo --------
    public function setCorreo($correo){$this->correo = $correo;return $this;}
    //-------- metodo get atributo contrasena --------
    public function getContrasena(){return $this->contrasena;}
    //-------- metodo set contrasena --------
    public function setContrasena($contrasena){$this->contrasena = $contrasena;return $this;}
    //-------- metodo get atributo cadenaVerificacion --------
    public function getCadenaVerificacion(){return $this->cadenaVerificacion;}
    //-------- metodo set cadenaVerificacion --------
    public function setCadenaVerificacion($cadenaVerificacion){$this->cadenaVerificacion = $cadenaVerificacion;return $this;}
    //-------- metodo get atributo rol --------
    public function getRol(){return $this->rol;}
    //-------- metodo set rol --------
    public function setRol($rol){$this->rol = $rol;return $this;}
    //-------- metodo get atributo verificacion --------
    public function getVerificacion(){return $this->verificacion;}
    //-------- metodo set verificacion --------
    public function setVerificacion($verificacion){$this->verificacion = $verificacion;return $this;}

//--------------------METODO CONSTRUCTOR----------------------------
	public function __construct(){
		parent:: __construct();//instancio el metodo constructor de conexion
	}
//------------------------------------------------------------------
//------------------------------------------------------------------
	public function encriptar(string $contra):string
   {
	    $options = ['memory_cost' => 2048, 'time_cost' => 4, 'threads' => 3];
	    return password_hash($contra, PASSWORD_ARGON2I,$options);
   }
  public function generarContra():string
    {
      $largo=8;
      $cadena_base="ABCDEFGHIJKLMNOPQRSTUVWZYZ";
      $cadena_base.="abcdefghijklmnopqrstuvwxyz";
      $cadena_base.="01234567890";
      $pasword='';
      $limite=strlen($cadena_base);
      for($i=0;$i<$largo;$i++){
        $pasword.=$cadena_base[rand(0,$limite-1)];
      }
      return $pasword;
    }
   public function logiar():string
   {
      $query="select idUsuario,contrasena,rol,verificacion from usuario where correo='".$this->getCorreo()."' && estado=1";
      $usuarios = $this->db->query($query)->fetchAll(PDO::FETCH_ASSOC);

      if(count($usuarios)!=0){
        $ban=true;      	
        foreach ($usuarios as $value) {
          if(password_verify($this->getContrasena(),$value['contrasena'])){
          	$ban=false;
            if($value['verificacion'] == 'VERIFICADO'){
            	return 'BIEN -- '.$value['idUsuario'].' -- '.$value['rol'];
            }else{
            	return 'DESACTIVADO';
            }
            break;
          }
        }
        if($ban){
        	return 'NO';
        }
      }else{
        return 'NO';
      }
   }

  public function cambiarContra(string $contraN,string $contraA,int $id):string
  {
    // error_reporting(0);
    try {
      $sql="SELECT contrasena FROM usuario WHERE idUsuario=".$id;
      $contraAn=$this->db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
      if(password_verify($contraA,$contraAn[0]['contrasena'])){
        $query='UPDATE usuario SET contrasena=:contra WHERE idUsuario=:idU';
        $result = $this->db->prepare($query);
        $array =array(':contra'=>$this->encriptar($contraN),':idU'=>$id);
        $result->execute($array);
        return 'BIEN';
      }else{
        return 'CONTRA';
      }
    } catch (PDOException $e) {
      return 'ERROR'.$e;
    }
  }
}

 ?>
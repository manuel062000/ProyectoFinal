<?php 
declare (strict_types = 1);
require_once 'Conexion.php';

class Votar extends Conexion
{
	private $dui;
	//-------- metodo get atributo dui --------
	public function getDui(){return $this->dui;}
	//-------- metodo set dui --------
	public function setDui($dui){$this->dui = $dui;return $this;}
	private $idPP;
	//-------- metodo get atributo idPP --------
	public function getIdPP(){return $this->idPP;}
	//-------- metodo set idPP --------
	public function setIdPP($idPP){$this->idPP = $idPP;return $this;}

	private $idJr;
	//-------- metodo get atributo idJr --------
	public function getIdJr(){return $this->idJr;}
	//-------- metodo set idJr --------
	public function setIdJr($idJr){$this->idJr = $idJr;return $this;}

    public function __construct()
    {
        parent:: __construct();
    }
	
	public function getPartidos():array
	{
		$query="SELECT pp.idPartido,pp.img,pp.nombre,pp.abreviacion,CONCAT(p.nombre,' ',p.apellido) as candidato FROM partido AS pp INNER JOIN persona AS p WHERE pp.idPersona=p.idPersona AND pp.estado=1";
		return  $this->db->query($query)->fetchAll(PDO::FETCH_ASSOC);
	}   
	public function calcularJunta(string $dui)
	{
		$array=array();
		$indice=0;
		$per=$this->ConsultaSimple("SELECT DUI,apellido,nombre FROM persona WHERE idMunicipio=(SELECT idMunicipio FROM persona WHERE DUI='".$dui."') AND estado=1 ORDER BY apellido,nombre ASC" );
		$jr=$this->ConsultaSimple("SELECT  idJuntaReceptora,nombre FROM juntareceptora WHERE estado=1 && idMunicipio=(SELECT idMunicipio FROM persona WHERE DUI='".$dui."') ORDER BY nombre ASC");

		$totalPer=COUNT($per);
		$totaljr=COUNT($jr);
		if($totaljr<1){
			$array[0]=array('fail'=>'fail');//-------------------------------------------------
		}else{
			if($totalPer%$totaljr!=0){
				$grup=floor($totalPer/$totaljr)+1;
			}else{
				$grup=$totalPer/$totaljr;
			}
			$indice=1;
			foreach ($per as $value) {
				if($value['DUI']==$dui){
					break;
				}
				$indice++;
			}
			if($indice%$grup!=0){
				$pertenece=floor($indice/$grup)+1;
			}else{
				$pertenece=$indice/$grup;
			}
			$i=0;
			foreach ($jr as $value) {
				if($i==$pertenece-1){
					$array[]=$value['nombre'];
					$array[]=$value['idJuntaReceptora'];
					break;
				}
				$i++;
			}
			$array[COUNT($array)]=array('fail'=>'true');
		}
		return $array;
	}
	public function EjercerVoto()
	{
		error_reporting(0);
		try {
			$this->db->beginTransaction();//inicia transaccion
			// consulta 1 (inserta los datps en la tabla votar)
			$query = "INSERT INTO votos values(null,:idPP,:idJr);";
			$consulta = $this->db->prepare($query);
			$array = array(':idPP'=>$this->getIdPP(),':idJr'=>$this->getIdJr());
			$consulta->execute($array);
			// consulta 2 (modifica el estado de voto de la persona para que no pueda votar mas de 1 ves)
			$query2 = "UPDATE persona SET voto=1 WHERE DUI=:dui;";
			$consulta2 = $this->db->prepare($query2);
			$array2 = array(':dui'=>$this->getDui());
			$consulta2->execute($array2);
			if($consulta->rowCount() && $consulta2->rowCount()){/*retorna las filas afectadas*/	
				$this->db->commit();// realiza los cambios en la base de datos
		    	echo 'BIEN';				
	    	}else {
				$this->db->rollBack();// revierte los datos a como estaban en la base de datos en caso de que la persona ya voto 1 ves
	    		echo 'ERROR';
	    	}
		} catch (PDOException $e) {
			$this->db->rollBack();// revierte los datos a como estaban en la base de datos en caso de error
			echo 'ERROR';
		}
	}
	public function mostrarPerJr(string $idMunicipio,int $desde,int $asta):array
	{
		$indice=0;
		$mostrar=$this->ConsultaSimple("SELECT DUI,apellido,nombre FROM persona WHERE idMunicipio=".$idMunicipio." AND estado=1 ORDER BY apellido,nombre ASC LIMIT ".$desde.",".$asta );

		$per=$this->ConsultaSimple("SELECT DUI,apellido,nombre FROM persona WHERE idMunicipio=".$idMunicipio." AND estado=1 ORDER BY apellido,nombre ASC" );
		 $jr=$this->ConsultaSimple("SELECT  idJuntaReceptora,nombre FROM juntareceptora WHERE estado=1 && idMunicipio=".$idMunicipio." ORDER BY nombre ASC");
		 $can=COUNT($mostrar);
			$totalPer=COUNT($per);
			$totaljr=COUNT($jr);
			if($totaljr<1){
				return array();
			}else{
				for ($l = 0; $l < $can ; $l++) {
					if($totalPer%$totaljr!=0){
						$grup=floor($totalPer/$totaljr)+1;
					}else{
						$grup=$totalPer/$totaljr;
					}
					$indice=1;
					foreach ($per as $value) {
						if($value['DUI']==$mostrar[$l]['DUI']){
							break;
						}else{
							$indice++;
						}
					}
					if($indice%$grup!=0){
						$pertenece=floor($indice/$grup)+1;	
					}else{
						$pertenece=$indice/$grup;
					}
					$i=0;
					foreach ($jr as $value) {
						if($i==$pertenece-1){
							$mostrar[$l]['jr']=$value['nombre'];
							break;
						}else{
							$i++;
						}
					}
				}
			return $mostrar;
			}
	}
}


 ?>
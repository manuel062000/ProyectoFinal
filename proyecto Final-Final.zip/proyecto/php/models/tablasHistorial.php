<?php 
class Tablas
{
    public function showTablePer(array $array): string
    {
        $html = '';
        if (count($array)) {
            $html = '<table class="table table-striped" id="table">
                        <thead>
                            <th>DUI ADMIN</th>
                            <th>NOMBRE ADMIN</th>
                            <th>APELLIDOS ADMIN</th>
                            <th>DUI PERSONA</th>
                            <th>NOMBRE PERSONA</th>
                            <th>APELLIDOS PERSONA</th>
                            <th>ACCION</th>
                            <th>FECHA</th>
                        </thead>

                        <tbody>
                     ';
            foreach ($array as $value) {
                $html .= '  <tr>
                        	<td class="text-center">' . $value['duiU'] . '</td>
	                        <td class="text-center">' . $value['nombreU'] . '</td>
	                        <td class="text-center">' . $value['apellidoU'] . '</td>
	                        <td>' . $value['duiP'] . '</td>
	                        <td>' . $value['nombreP'] . '</td>
	                        <td>' . $value['apellidoP'] . '</td>
	                        <td>' . $value['accion'] . '</td>
	                        <td>' . $value['fecha'] . '</td>
                        </tr>
                         ';
            }
            $html .= '  </tbody>
                    </table>';
        } else {
            $html = '<h4 class="text-center">No hay datos...</h4>';
        }
        return $html;
    }
    //-----------------------------
    public function showTableJR(array $array): string
    {
        $html = '';
        if (count($array)) {
            $html = '<table class="table table-striped" id="table">
                        <thead>
                            <th>DUI ADMIN</th>
                            <th>NOMBRE ADMIN</th>
                            <th>APELLIDOS ADMIN</th>
                            <th>MUNICIPIO</th>
                            <th>JUNTA RECEPTORA</th>
                            <th>ACCION</th>
                            <th>FECHA</th>
                        </thead>

                        <tbody>
                     ';
            foreach ($array as $value) {
                $html .= '  <tr>
                        	<td class="text-center">' . $value['duiU'] . '</td>
	                        <td class="text-center">' . $value['nombreU'] . '</td>
	                        <td class="text-center">' . $value['apellidoU'] . '</td>
	                        <td>' . $value['mun'] . '</td>
	                        <td class="text-center">' . $value['JR'] . '</td>
	                        <td>' . $value['accion'] . '</td>
                        	<td>' . $value['fecha'] . '</td>
                        </tr>
                         ';
            }
            $html .= '  </tbody>
                    </table>';
        } else {
            $html = '<h4 class="text-center">No hay datos...</h4>';
        }
        return $html;
    }
    //-----------------------------
    public function showTableCV(array $array): string
    {
        $html = '';
        if (count($array)) {
            $html = '<table class="table table-striped" id="table">
                        <thead>
                            <th>DUI ADMIN</th>
                            <th>NOMBRE ADMIN</th>
                            <th>APELLIDOS ADMIN</th>
                            <th>DEPARTAMENTO</th>
                            <th>CENTRO DE VOTACION</th>
                            <th>ACCION</th>
	                        <th>FECHA</th>
                        </thead>

                        <tbody>
                     ';
            foreach ($array as $value) {
                $html .= '  <tr>
	                        <td class="text-center">' . $value['duiU'] . '</td>
	                        <td class="text-center">' . $value['nombreU'] . '</td>
	                        <td class="text-center">' . $value['apellidoU'] . '</td>
	                        <td>' . $value['dep'] . '</td>
	                        <td>' . $value['nombreCV'] . '</td>
	                        <td>' . $value['accion'] . '</td>
                        	<td>' . $value['fecha'] . '</td>
                        </tr>
                         ';
            }
            $html .= '  </tbody>
                    </table>';
        } else {
            $html = '<h4 class="text-center">No hay datos...</h4>';
        }
        return $html;
    }
    //-----------------------------
    public function showTableUsu(array $array): string
    {
        $html = '';
        if (count($array)) {
            $html = '<table class="table table-striped" id="table">
                        <thead>
                            <th class="text-center">DUI ADMIN</th>
                            <th>NOMBRE ADMIN</th>
                            <th>APELLIDOS ADMIN</th>
                            <th>DUI USUARIO</th>
                            <th>NOMBRE USUARIO</th>
                            <th>APELLIDOS USUARIO</th>
                            <th>ACCION</th>
                            <th>FECHA</th>
                        </thead>

                        <tbody>
                     ';
            foreach ($array as $value) {
                $html .= '  <tr>
                        	<td class="text-center">' . $value['duiU'] . '</td>
	                        <td class="text-center">' . $value['nombreU'] . '</td>
	                        <td class="text-center">' . $value['apellidoU'] . '</td>
	                        <td>' . $value['duiP'] . '</td>
	                        <td>' . $value['nombreP'] . '</td>
	                        <td>' . $value['apellidoP'] . '</td>
	                        <td>' . $value['accion'] . '</td>
	                        <td>' . $value['fecha'] . '</td>
                        </tr>
                         ';
            }
            $html .= '  </tbody>
                    </table>';
        } else {
            $html = '<h4 class="text-center">No hay datos...</h4>';
        }
        return $html;
    }
    //-----------------------------
    public function showTablePP(array $array): string
    {
        $html = '';
        if (count($array)) {
            $html = '<table class="table table-striped" id="table">
                        <thead>
                            <th>DUI ADMIN</th>
                            <th>NOMBRE ADMIN</th>
                            <th>APELLIDOS ADMIN</th>
                            <th>PARTIDO POLITICO</th>
                            <th>ACCION</th>
                            <th>FECHA</th>
                        </thead>

                        <tbody>
                     ';
            foreach ($array as $value) {
                $html .= '  <tr>
	                        <td class="text-center">' . $value['duiU'] . '</td>
	                        <td class="text-center">' . $value['nombreU'] . '</td>
	                        <td class="text-center">' . $value['apellidoU'] . '</td>
	                        <td>' . $value['pp'] . '</td>
	                        <td>' . $value['accion'] . '</td>
	                        <td>' . $value['fecha'] . '</td>
                        </tr>
                         ';
            }
            $html .= '  </tbody>
                    </table>';
        } else {
            $html = '<h4 class="text-center">No hay datos...</h4>';
        }
        return $html;
    }
}
 ?>
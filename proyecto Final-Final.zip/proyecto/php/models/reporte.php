<?php 
require_once 'Conexion.php';

class reporteJr extends Conexion
{
    public function __construct()
    {
       parent:: __construct(); 
    }
    public function reportePersonaJr(){
		
    }
}

?>
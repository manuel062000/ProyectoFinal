<?php 
declare (strict_types = 1);
date_default_timezone_set('America/El_Salvador');
require_once 'Historial.php';
require_once 'parametros.php';

class CRUD extends Historial
{

//--------------------METODO CONSTRUCTOR----------------------------
	public function __construct(){
		parent:: __construct();//instancio el metodo constructor de conexion
	}
//------------------------------------------------------------------
//------------------------------------------------------------------

//-----------------------------MOSTRAR------------------------------
    public function ultimo_id(string $campo,string $tabla):array
    {
        $query="SELECT MAX({$campo}) AS id FROM {$tabla};";
        return array('id'=>intval($this->db->query($query)->fetch(PDO::FETCH_BOTH)[0]));
    }
    public function getAll(string $SP,int $comienzo,int $longitud):array
    {
    	$query="CALL {$SP} ({$comienzo},{$longitud});";
    	return $this->ConsultaSimple($query);
    }
    public function getSearch(string $SP,string $termino):array
    {
        $query  = "CALL {$SP}(:municipio)";
        $result = $this->db->prepare($query);
        $array=array(':municipio'=>'%'.$termino.'%');
        $result->execute($array);
        return $result->fetchAll(PDO::FETCH_ASSOC);
    }
    public function existencia(string $campo,string $tabla,string $where):array
    {
        $query  = "SELECT {$campo},COUNT(*) as total FROM {$tabla} WHERE {$where}";
        return $this->db->query($query)->fetch(PDO::FETCH_ASSOC);
    }
    public function getPaginacion(string $tabla): array
    {
        $query = "SELECT COUNT(*) FROM {$tabla}";
        return array(
            'filasTotal'  => intval($this->db->query($query)->fetch(PDO::FETCH_BOTH)[0]),
            'filasPagina' => 5,
        );
    }
    public function llenarSelect(string $campos,string $tabla):array
    {
    	$query="SELECT {$campos} FROM {$tabla}";
    	return $this->ConsultaSimple($query);
    }
//------------------------------------------------------------------
//------------------------------------------------------------------

//-----------------------------AGREGAR------------------------------
    public function agregar(string $SP,string $params)
    {
    	
        if($this->validacion()==1 || $SP=='SP_agregar_Usuario'){
            error_reporting(0);
            try {
                $query="CALL {$SP} ({$params});";
                $this->db->query($query);
                $this->historial($SP,$params);
                echo 'BIEN';
            } catch (PDOException $e) {
                echo "ERROR ".$e;
            }
        }else{
            echo 'FECHAS';
        }
    }
//------------------------------------------------------------------
//------------------------------------------------------------------

//----------------------------MODIFICAR-----------------------------
    public function modificar(string $SP,string $param)
    {
        
        if($this->validacion()==1 || $SP=='SP_eliminar_Usuario' || $SP=='SP_modificar_Usuario' || $SP=='SP_modificar_Usuario_Con_contra'){
            session_start();
            error_reporting(0);
            try {
                $query="CALL {$SP} ({$param});";
                $result = $this->db->query($query);
                if($result->rowCount()){/*retorna las filas afectadas*/
                    $id=explode(',',$param);
                    $usuario=$this->existencia('idPersona','usuario','estado=1 AND idUsuario='.$_SESSION['usuario']['id']);
                    if($usuario['idPersona']==$id[0] && $SP=='SP_modificarSinImg_Per'){
                        $this->historial($SP,$param);
                        echo 'MISMO';
                    }else{
                        $this->historial($SP,$param);
                        echo 'BIEN';
                    }
                }else {               
                    echo 'IGUAL';
                }
            } catch (PDOException $e) {
                echo 'ERROR';
            }
        }else{
            echo 'FECHAS';
        }
    }
    public function modificarConImg(string $SP,string $param)
    {
        if($this->validacion()==1){
            session_start();
            error_reporting(0);
            try {
                $query="CALL {$SP} ({$param});";
                $result = $this->db->query($query);
                    $id=explode(',',$param);
                    $usuario=$this->existencia('idPersona','usuario','estado=1 AND idUsuario='.$_SESSION['usuario']['id']);
                    if($usuario['idPersona']==$id[0] && $SP == 'SP_modificarConImg_Per'){
                        $this->historial($SP,$param);
                        echo 'MISMO';
                    }else{
                        $this->historial($SP,$param);
                        echo 'BIEN';
                    }         
            } catch (PDOException $e) {
                echo 'ERROR';
            }
        }else{
            echo 'FECHAS';
        }
    }
    public function validacion(){
        $fVot = explode('/',fechaVotaciones);
        $fAct = explode('/',date('Y/m/d',strtotime('3 month')));
        $dV=1;
        if($fVot[0]>$fAct[0]){
            $dV=1;
        }else{
            if($fVot[1]>$fAct[1] && $fAct[0]==$fVot[0]){
                $dV=1;
            }else{
                if($fVot[2]>$fAct[2] && $fAct[1]==$fVot[1] && $fAct[0]==$fVot[0]){
                    $dV=1;
                }else{
                    $dV=0;
                }
            }
        }
        return $dV;
    }
//------------------------------------------------------------------
//------------------------------------------------------------------
}
?>
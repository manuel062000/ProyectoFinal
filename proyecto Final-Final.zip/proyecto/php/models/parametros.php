<?php 
define('fechaVotaciones', '2019/06/05');//año/mes/dia  

 ?>
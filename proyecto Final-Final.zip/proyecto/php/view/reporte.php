<?php require('../controllers/logear/cerrarSinSeccionCo_A.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>

	<link rel="stylesheet" type="text/css" href="../../css/bootstrap/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../../css/font-awesome/fontawesome-pro/css/all.min.css">
	<script type="text/javascript" src="../../js/Jquery/jquery-3.3.1.min.js"></script>
	<!-- <script type="text/javascript" src="../../js/popper/popper.min.js"></script> -->
	<!-- <script type="text/javascript" src="../../js/bootstrap/bootstrap.js"></script> -->

	<script src="../../js/highcharts/highcharts.js"></script>
	<script src="../../js/highcharts/highcharts-3d.js"></script>
	<script src="../../js/highcharts/exporting.js"></script>
	<script src="../../js/highcharts/export-data.js"></script>

	<script type="text/javascript" src="../../js/reporte.js"></script>
	<link rel="stylesheet" type="text/css" href="../../css/graficos.css">

</head>
<body>
	<!-- inicio grafico -->
	<div id="container"></div>
	<div id="sliders">
	    <table>
	    	<thead>
	    		<tr>
	    			<th colspan="2">PARAMETROS</th>
	    		</tr>
	    	</thead>
	        <tbody>
	        	<tr>
	        		<td>Ángulo Alfa</td>
	        		<td><input id="alpha" type="range" min="0" max="45" value="15"/> <span id="alpha-value" class="value"></span></td>
	        	</tr>
	        	<tr>
	        		<td>Ángulo Beta</td>
	        		<td><input id="beta" type="range" min="-45" max="45" value="15"/> <span id="beta-value" class="value"></span></td>
	        	</tr>
	        	<tr>
	        		<td>Profundidad</td>
	        		<td><input id="depth" type="range" min="20" max="100" value="50"/> <span id="depth-value" class="value"></span></td>
	        	</tr>
	        </tbody>
	    </table>
	</div>
	<!-- fin grafico -->
</body>
</html>
<?php require_once '../controllers/votar/juntaR.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../../css/font-awesome/fontawesome-pro/css/all.min.css">
	<script type="text/javascript" src="../../js/Jquery/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="../../js/popper/popper.min.js"></script>
	<script type="text/javascript" src="../../js/bootstrap/bootstrap.js"></script>
	<!-- google fonts-->
    <!-- <link href="//fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet"> -->
    <!-- /google fonts--> 
    <script src="../../js/comunes.js"></script>
	<link rel="stylesheet" type="text/css" href="../../css/estiloIndex.css">
	<script type="text/javascript" src="../../js/votar.js"></script>
    <script>
        $(document).ready(function() {
            <?php 
                echo "var texto1='Para votar ingresa tú dúi, en la caja blanca, y luego dale click al botón rojo';speechSynthesis.cancel();hablar1 = new SpeechSynthesisUtterance(texto1);window.speechSynthesis.speak(hablar1);";
                echo "setInterval('indicaciones()',10000);";

            ?>
        });
    </script>
</head>
<body class="bodyVotar">
<div class="validar" id="validarArriba">
        VALIDAR...
    </div>
<!--  -->	
<!-- cuerpo -->
<section>
	<div class="w3l-login-form mt-5">
        <div class="w3l-form-group mt-2">
            <label>Número de DUI:</label>
            <div class="group">
            	<i class="fal fa-id-card"></i>
                <input type="text" id="dui" placeholder="0000000-0"/>
            </div>
                <div id="validar" class="text-danger">
                	DUI no valido....
                </div>
        </div>
        <button id="logiarse" disabled>Ingresar</button>
    </div>
</section>
<!-- fin cuerpo -->
</body>
</html>
<?php require('../controllers/logear/cerrarSinSeccionCo_A.php');?>
<!DOCTYPE >
<html lang="en">
<head>

	<meta charset="UTF-8">

	<link rel="stylesheet" type="text/css" href="../../css/bootstrap/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../../css/font-awesome/fontawesome-pro/css/all.min.css">
	<script type="text/javascript" src="../../js/Jquery/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="../../js/popper/popper.min.js"></script>
	<script type="text/javascript" src="../../js/bootstrap/bootstrap.js"></script>
	<script type="text/javascript" src="../../js/sweetalert2/sweetalert2.js"></script>

	 <!-- google fonts-->
    <link href="//fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <!-- /google fonts-->
    <link rel="stylesheet" type="text/css" href="../../css/estilo.css">
	<script type="text/javascript" src="../../js/perfil.js"></script>
</head>
<body class="letra">
	<div class="container border mt-5 "style="border-radius: 15px;">
		<h1 class="text-center my-3">PERFIL DE USUARIO</h1>
		<hr class="mx-1 mb-5"> 
		
		

		<div class="row">
			<div class="col-sm-12 col-md-3 col-xl-3 col-lg-3">
				<center><img class="mb-3" id="imagen" src="../../images/usuario.png" style="max-width: 90%;max-height: 90%;"></center>
			</div>

			<div class="col-sm-12 col-md-9 col-xl-9 col-lg-9">
				<div class="d-block">
					<label class="h5 font-weight-bold">CORREO:&nbsp;</label>
					<label class="h5 font-italic" id="correo">DEFAULT</label>&nbsp;&nbsp;&nbsp;<a class="font-italic" href="#" data-toggle="modal" data-target="#ventanaModal" id="aCorreo">Modificar correo</a>
				</div>

				<div class="d-block">
					<label class="h5 font-weight-bold">CONTRASEÑA:&nbsp;</label>
					<label class="h5 font-italic">**********</label>&nbsp;&nbsp;&nbsp; <a class="font-italic" href="#" data-toggle="modal" data-target="#ventanaModal" id="aContra">Modificar contraseña</a>
				</div>

				<div class="d-block">
					<label class="h5 font-weight-bold">NOMBRES:&nbsp;</label>
					<label class="h5 font-italic" id="nombre">DEFAULT</label>
				</div>

				<div class="d-block">
					<label class="h5 font-weight-bold">APELLIDOS:&nbsp;</label>
					<label class="h5 font-italic" id="apellido">DEFAULT</label>
				</div>

				<div class="d-block">
					<label class="h5 font-weight-bold">EDAD:&nbsp;</label>
					<label class="h5 font-italic" id="edad">18</label>
					<label class="h5 font-italic">&nbsp;AÑOS</label>
				</div>

				<div class="d-block">
					<label class="h5 font-weight-bold">GENERO:&nbsp;</label>
					<label class="h5 font-italic" id="genero">DEFAULT</label>					
				</div>

				<div class="d-block">
					<label class="h5 font-weight-bold">ROL:&nbsp;</label>
					<label class="h5 font-italic" id="rol">DEFAULT</label>
				</div>
			</div>
		</div>
	</div>
<!-- Modal-->
<div class="modal fade" id="ventanaModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
		    	<!-- div para mostrar la alerta -->
		  	<div id="alerta"></div>

			<!-- Cabecera modal -->
		    	<div class="modal-header">
		       	 	<h5 id="titulo" class="modal-title h4 text-center text-uppercase">NUEVA JUNTA RECEPTORA</h5>
		        	 	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		        	 		 <span aria-hidden="true">&times;</span>
		       		 </button>
		     	</div>
		     	<!-- Fin cabecera modal -->

			<!-- Cuerpo  modal -->
		      	<div class="modal-body">
		      		<input type="hidden" name="" id="opcion">
					<!-- Gif "Cargando" -->
					<div class="form-group d-none" id="gif">
						<label><img src="../images/ajax-loader.gif"> Procesando...</label>
					</div>
					<!-- Campo correo -->
					<div class="form-group" id="nCorreo">
						<label for="">Nuevo Correo: </label>
						<input type="text" id="txt_nCorreo" class="form-control">
						<div class="text-danger" id="validacion">
							Formato de correo no valido...
						</div>
					</div>
					<!-- Campo antigua contraseña-->
					<div class="form-group" id="acContra">
						<label for="txt_aContra">Contraseña Actual:</label>
						<input type="password" id="txt_aContra" class="form-control">
					</div>
					<!-- Campo nueva contraseña-->
					<div class="form-group" id="nContra">
						<label for="txt_nContra">Nueva Contraseña:</label>
						<input type="password" id="txt_nContra" class="form-control">
					</div>
					<!-- Campo repetir nueva contraseña-->
					<div class="form-group" id="rContra">
						<label for="txt_rContra">Repetir Contraseña:</label>
						<input type="password" id="txt_rContra" class="form-control">
						<div class="text-danger" id="validacionC">
							Las contraseñas no coinsiden...
						</div>
					</div>
		     	 </div>
		     	 <!-- Fin cuerpo modal -->

			<!-- Pie del modal -->
			<div class="modal-footer">
				<button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
				<button type="button" class="btn btn-success" id="btn_guardar_cambios">Guardar cambios</button>
			</div>
			<!-- Fin pie modal -->
		</div>
	</div>
</div>
<!-- Fin modal -->
</body>
</html>
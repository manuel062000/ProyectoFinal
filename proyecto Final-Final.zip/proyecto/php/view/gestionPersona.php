<?php require('../controllers/logear/cerrarSinSeccionAdmin.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">

	<link rel="stylesheet" type="text/css" href="../../css/bootstrap/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../../css/font-awesome/fontawesome-pro/css/all.min.css">
	<script type="text/javascript" src="../../js/Jquery/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="../../js/popper/popper.min.js"></script>
	<script type="text/javascript" src="../../js/bootstrap/bootstrap.js"></script>
	
	<script type="text/javascript" src="../../js/sweetalert2/sweetalert2.js"></script>
	<link rel="stylesheet" type="text/css" href="../../css/estilo.css">
	<script type="text/javascript" src="../../js/MainPersonas.js"></script>
	<script type="text/javascript" src="../../js/comunes.js"></script>

	<title>Document</title>
</head>
<body>
	<!--Cuadro principal  -->
	<div  class="cuadro_grande">
		<h3 class="text-uppercase text-center mt-2">GESTION DE PERSONAS</h3>
		<!-- Botón abrir modal -->
		<div class="form-group">
			<button id="btn_insertar" class="btn btn-primary" title="Agregar nueva persona" data-toggle="modal" data-target="#ventanaModal"><i class="fa fa-user"></i>&nbsp;NUEVO</button>
		</div>
	
		<!-- Input campo de búsqueda -->
		<div class="form-group">
			<div class="input-group mb-3">
				<input type="text" id="txt_busqueda" class="form-control" placeholder="Escriba aquí su término de búsqueda" aria-label="Escriba aquí su término de búsqueda" aria-describedby="basic-addon2">
				<div class="input-group-append" id="btn_borrar_busqueda" title="Limpiar barra de busqueda">
			    	<button class="input-group-text" id="basic-addon2">X</button>
				</div>
			</div>
		</div>
	
		<!-- Tabla -->
		<div id="div_tabla">
	
		</div>
		<!-- Fin Tabla -->
	
		<!-- Paginación -->
		<div class="d-flex justify-content-center paginas" >
			<nav aria-label="Page navigation example" class="">
			  <ul class="pagination" id="pagination">
	
			  </ul>
			</nav>
		</div>
		<!-- Fin Paginación -->
	</div>
<!--Fin cuadro principal   -->

<!-- Modal -->

<div class="modal fade bd-example-modal-xl" id="ventanaModal" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-xl" role="document">
		<div class="modal-content">
		    <!-- div para mostrar la alerta -->
		  	<div id="alerta"></div>

			<!-- Cabecera modal -->
		    	<div class="modal-header">
		       	 	<h5 class="modal-title h4 text-center text-uppercase">Crear Nueva Persona</h5>
		        	 	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		        	 		 <span aria-hidden="true">&times;</span>
		       		 	</button>
		     	</div>
		     <!-- Fin cabecera modal -->

			<!-- Cuerpo  modal -->
		      	<div class="modal-body">
					<form enctype="multipart/form-data">
						<!-- Campos ocultos -->
						<div class="form-group">
							<input type="hidden" id="opcion" name="opcion">
							<input type="hidden" id="id" name="id">
						</div>
						
						<div class="row">
							<!-- Campo numero de dui -->
							<div class="form-group col-xs-12 col-sm-12 col-md-3 col-lg-4">
								<label for="txt_DUI">Número de DUI: </label>
								<input type="text" id="txt_DUI" name="txt_DUI" class="form-control" placeholder="00000000-0">
								<div class="text-danger" id="validacion_dui">
									Formato de DUI no valido...
								</div>
							</div>
									<!-- Campo fotografia -->
									<div class="form-group col-xs-12 col-sm-3 col-md-3 col-lg-2">
										<img class="imagen float-md-right"  src="../../images/usuario.png" id="Mostrar_img">
									</div>
									<div class="form-group col-xs-12 col-sm-9 col-md-6 col-lg-6">
										<label for="txt_img">Fotografia: </label>
										<div class="custom-file">
										    <input type="file" class="custom-file-input" id="txt_img" name="txt_img">
										    <label class="custom-file-label" for="txt_img">Click aqui...</label>
										</div>
										<div class="text-danger" id="validacion_img">
											Formato de imagen no valido seleccione una imagen <strong>jpg o jpeg...</strong>
										</div>
									</div>
								
						</div>

						<div class="row">
							<!-- Campo nombre -->
							<div class="form-group col-sm-12 col-md-6">
								<label for="txt_nombre">Nombres: </label>
								<input type="text" id="txt_nombre" name="txt_nombre" class="form-control" placeholder="Ingrese el nombre">
								<div class="text-danger" id="validacion_nombre">
									Formato del nombre no valido...
								</div>
							</div>
							<!-- Campo apellido -->
							<div class="form-group col-sm-12 col-md-6">
								<label for="txt_apellido">Apellidos: </label>
								<input type="text" id="txt_apellido" name="txt_apellido" class="form-control" placeholder="Ingrese los apellidos">
								<div class="text-danger" id="validacion_apellido">
									Formato del apellido no valido...
								</div>
							</div>
						</div>

						<div class="row">
							<!-- Campo fecha de nacimiento-->
							<div class="form-group col-sm-12 col-md-6 col-lg-4">
								<label for="txt_fecha_Nac">Fecha de Nacimiento: </label>
								<input type="date" id="txt_fecha_Nac" name="txt_fecha_Nac" class="form-control">
								<div class="text-danger" id="validacion_fNac">
									Fecha no valida la persona aun no puede votar...
								</div>
							</div>						
							<!-- Campo nacionalidad -->
							<div class="form-group col-sm-12 col-md-6 col-lg-4">
						    	<label for="txt_nacionalidad">Salvadoreño por:</label>
						   		<select id="txt_nacionalidad" name="txt_nacionalidad" class="form-control">
						   			<option value="NACIMIENTO">NACIMIENTO</option>
						    		<option value="NATURALIZACION">NATURALIZACION</option>
						    	</select>
						    </div>
							<!-- Campo fecha de expiracion de dui-->
							<div class="form-group col-sm-12 col-md-6 col-lg-4">
								<label for="txt_fecha_Exp_dui">Fecha de Expiración de DUI: </label>
								<input type="date" id="txt_fecha_Exp_dui" name="txt_fecha_Exp_dui" class="form-control">
							</div>
							<!-- Campo departamento-->
							<div class="form-group col-sm-12 col-md-6 col-lg-4">
								<label for="txt_Departamento">Departamento:</label>
								<select id="txt_Departamento" name="txt_Departamento" class="form-control">		   			
								</select>
							</div>
							<!-- Campo municipio-->
							<div class="form-group col-sm-12 col-md-6 col-lg-4">
								<label for="txt_municipio">Municipio:</label>
								<select id="txt_municipio" name="txt_municipio" class="form-control">		   			
								</select>
							</div>	
							<!-- Campo unta estado civil-->
							<div class="form-group col-sm-12 col-md-6 col-lg-4">
							   	<label for="txt_estadoCivil">Estado Civil:</label>
								<select id="txt_estadoCivil" name="txt_estadoCivil" class="form-control">	
							   		<option value="CASADO(A)">CASADO(A)</option>	   
							   		<option value="DIVORCIADO(A)">DIVORCIADO(A)</option>
							   		<option value="SOLTERO(A)">SOLTERO(A)</option>	   
							   		<option value="VIUDO(A)">VIUDO(A)</option>
							   		<option value="COMPROMETIDO(A)">COMPROMETIDO(A)</option>			
							   	</select>
							</div>					
						</div>

						<div class="row">						
							<!-- Campo direccion -->
							<div class="form-group col-md-12 col-lg-6">
								<label for="txt_Direccion">Dirección: </label>
								<input type="text" id="txt_Direccion" name="txt_Direccion" class="form-control" placeholder="Ingrese la dirección">
							</div>
							<!-- Campo genero -->
							<div class="form-group col-md-12 col-lg-6">
								<label class="d-block">Genero: </label>
								<div class="form-check d-inline-block">
								  <input class="form-check-input" type="radio" name="genero" id="masculino" value="M">
								  <label class="form-check-label" for="exampleRadios1">
								    Masculino
								  </label>
								</div>
								&nbsp;&nbsp;
								<div class="form-check d-inline-block">
								  <input class="form-check-input" type="radio" name="genero" id="femenino" value="F">
								  <label class="form-check-label" for="exampleRadios2">
								    femenino
								  </label>
								</div>
							</div>
						</div>
					</form>
		     	</div>
		    <!-- Fin cuerpo modal -->

			<!-- Pie del modal -->
			<div class="modal-footer">
				<button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>		
				<button type="button" class="btn btn-success" id="btn_guardar_cambios">Guardar cambios</button>
			</div>
			<!-- Fin pie modal -->
		</div>
	</div>
</div>
<!-- Fin modal -->
</body>
</html>
<?php require('../controllers/logear/cerrarSinSeccionAdmin.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>

	<link rel="stylesheet" type="text/css" href="../../css/bootstrap/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../../css/font-awesome/fontawesome-pro/css/all.min.css">
	<script type="text/javascript" src="../../js/Jquery/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="../../js/popper/popper.min.js"></script>
	<script type="text/javascript" src="../../js/bootstrap/bootstrap.js"></script>
	
	<script type="text/javascript" src="../../js/sweetalert2/sweetalert2.js"></script>
	<link rel="stylesheet" type="text/css" href="../../css/estilo.css">
	<script type="text/javascript" src="../../js/historial.js"></script>


</head>
<body>
	<div class="row">
		<div class="col-sm-12 col-md-12 col-lg-3 border-right">
			<h2 class="text-center ml-2 font-weight-bold font-italic mt-3" style="background: #A1DAE3;">FILTROS:</h2>
			<div class="row">
				<input type="hidden" value="1" id="txt_tabla" class="float-right">
				<div class="col-xl-12 col-sm-6 col-md-6 col-lg-12">
					<div class="form-group mx-2">
						<input type="radio" name="tipo" id="rbn_CV" checked>
						<label class="manito">Centro de Votación</label>
					</div>
				</div>
				<div class="col-xl-12 col-sm-6 col-md-6 col-lg-12">
					<div class="form-group mx-2">
						<input type="radio" name="tipo"  id="rbn_JRr">
						<label class="manito">Junta Receptora</label>
					</div>
				</div>
				<div class="col-xl-12 col-sm-6 col-md-6 col-lg-12">
					<div class="form-group mx-2 ">
						<input type="radio" name="tipo"  id="rbn_Per">
						<label class="manito">Persona</label>
					</div>
				</div>
			
				<div class="col-xl-12 col-sm-6 col-md-6 col-lg-12">
					<div class="form-group mx-2">
						<input type="radio" name="tipo"  id="rbn_PP">
						<label class="manito">Partido Político</label>
					</div>
						
				</div>
				<div class="col-xl-12 col-sm-6 col-md-6 col-lg-12">
					<div class="form-group mx-2">
						<input type="radio" name="tipo"  id="rbn_Us">
						<label class="manito">Usuarios</label>
					</div>
				</div>
				<div class="col-xl-12 col-sm-6 col-md-6 col-lg-12">
					<div class="form-group text-center">
						<button class="btn btn-primary btn-lg" id="aplicar">APLICAR</button>
					</div>
				</div>
			</div>
			<hr class="d-lg-none mx-2" style="background: #A1DAE3;">
		</div>
		<div class="col-sm-12 col-md-12 col-lg-9">
			<!--Cuadro principal  -->
			<div  class="cuadro_grande border-0">
				<h3 class="text-uppercase text-center mt-1 mb-4">HISTORIAL</h3>
				
			
				<!-- Input campo de búsqueda -->
				<div class="form-group">
					<div class="input-group mb-3">
						<input type="text" id="txt_busqueda" class="form-control" placeholder="Escriba aquí su término de búsqueda" aria-label="Escriba aquí su término de búsqueda" aria-describedby="basic-addon2">
						<div class="input-group-append" id="btn_borrar_busqueda" title="Limpiar barra de busqueda">
					    	<button class="input-group-text" id="basic-addon2">X</button>
						</div>
					</div>
				</div>
				
					<!-- Tabla -->
				<div id="div_tabla">
				
				</div>
					<!-- Fin Tabla -->
				
					<!-- Paginación -->
				<div class="d-flex justify-content-center paginas" >
					<nav aria-label="Page navigation example" class="">
						<ul class="pagination" id="pagination">
					
						</ul>
					</nav>
				</div>
					<!-- Fin Paginación -->
			</div>
	<!--Fin cuadro principal   -->



		</div>
	</div>
	
</body>
</html>
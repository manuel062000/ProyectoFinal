<?php require('../controllers/logear/cerrarSinSeccionCo_A.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">

	<link rel="stylesheet" type="text/css" href="../../css/bootstrap/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../../css/font-awesome/fontawesome-pro/css/all.min.css">
	<script type="text/javascript" src="../../js/Jquery/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="../../js/popper/popper.min.js"></script>
	<script type="text/javascript" src="../../js/bootstrap/bootstrap.js"></script>

	<link rel="stylesheet" type="text/css" href="../../css/estilo.css">
	<script type="text/javascript" src="../../js/activarVotar.js"></script>
	
</head>
<body>
	<div class="row mt-4">
		<div class="col-md-3 col-sm-12 border-right">
			
			<div class="form-group text-center">				
				<button class="btn btn-danger mb-3" id="AcVotar">Activar como junta receptora</button>
				
			</div>
			<div class="form-group m-2">
				<label for="txt_Departamento">Departamento:</label>
				<select class="form-control mb-3" id="txt_Departamento">
				</select>
			</div>
			<div class="form-group m-2">
				<label for="txt_municipio">Municipio:</label>
				<select class="form-control mb-3" id="txt_municipio">
				</select>
			</div>
			<div class="form-group text-center">
				<button class="btn btn-success" id="aplicar">APLICAR</button>
			</div>			
		</div>
		<div class="col-md-9 col-sm-12">
			<div  class="cuadro border-0">	
				<h3 class="text-uppercase text-center mt-2" id="titulo">LISTADO DE PERSONAS DEL MUNICIPIO DE SONSONATE </h3>
				<!-- <a href="../controllers/votar/imprimir.php" target="_blank"  class="btn btn-danger mb-3 ">Imprimir</a> -->
				<!-- Tabla -->
				<div id="div_tabla">
					
				</div>
				<!-- Fin Tabla -->

				<!-- Paginación -->
				<div class="d-flex justify-content-center paginas" >
					<nav aria-label="Page navigation example" class="">
					  <ul class="pagination" id="pagination">
					  </ul>
					</nav>
				</div>
				<!-- Fin Paginación -->
			</div>
			<!--Fin cuadro principal   -->
		</div>
	</div>
</body>
</html>
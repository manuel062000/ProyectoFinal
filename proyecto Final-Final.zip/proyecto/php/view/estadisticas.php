<?php require('../controllers/logear/cerrarSinSeccionCo_A.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>

	<link rel="stylesheet" type="text/css" href="../../css/bootstrap/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../../css/font-awesome/fontawesome-pro/css/all.min.css">
	<script type="text/javascript" src="../../js/Jquery/jquery-3.3.1.min.js"></script>

	<script src="../../js/highcharts/highcharts.js"></script>
	<script src="../../js/highcharts/highcharts-3d.js"></script>
	<script src="../../js/highcharts/exporting.js"></script>
	<script src="../../js/highcharts/export-data.js"></script>

	<script type="text/javascript" src="../../js/estadisticas.js"></script>
	<link rel="stylesheet" type="text/css" href="../../css/graficos.css">

</head>
<body>
	<div class="row">
		<div class="col-sm-12 col-md-12 col-lg-3 border-right">
			<h2 class="text-center ml-2 font-weight-bold font-italic" style="background: #A1DAE3;">FILTROS:</h2>
			<div class="row">
				<div class="col-xl-12 col-sm-6 col-md-6 col-lg-12">
					<div class="form-group mx-2">
						<input type="radio" name="tipo" value="Municipio" id="rbn_Mun">
						<label class="manito">Municipio</label>
					</div>
				</div>
				<div class="col-xl-12 col-sm-6 col-md-6 col-lg-12">
					<div class="form-group mx-2 ">
						<input type="radio" name="tipo" value="Departamento" id="rbn_Dep">
						<label class="manito">Departamento</label>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xl-12 col-sm-6 col-md-6 col-lg-12">
					<div class="form-group mx-2">
						<input type="radio" name="tipo" value="partido" id="rbn_PP">
						<label class="manito">Partido Político</label>
					</div>
						<!-- ------------------ -->
						<div class="row ml-2" id="h_PP">
							<div class="col-xl-12 col-sm-6 col-md-6 col-lg-12">
								<div class="form-group mx-2">
									<input type="radio" name="tipo1" value="" id="rbn_todos" checked>
									<label class="manito">Nivel Nacional</label>
								</div>
							</div>
							<div class="col-xl-12 col-sm-6 col-md-6 col-lg-12">
								<div class="form-group mx-2">
									<input type="radio" name="tipo1" value="" id="rbn_Municipio">
									<label class="manito">Municipio</label>
								</div>
							</div>
							<div class="col-xl-12 col-sm-12 col-md-6 col-lg-12">
								<div class="form-group mx-2">
									<input type="radio" name="tipo1" value="" id="rbn_Departamento">
									<label class="manito">Departamento</label>
								</div>
							</div>
							
						</div>
						<!-- ------------------- -->
				</div>
				<div class="col-xl-12 col-sm-6 col-md-6 col-lg-12">
					<div class="form-group mx-2">
						<input type="radio" name="tipo" value="total" id="rbn_total_per" checked>
						<label class="manito">Personas que han realizado sufragio</label>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xl-12 col-sm-6 col-md-6 col-lg-12" id="p_PP">
					<div class="form-group mx-2">
						<label for="">Partido Político:</label>
						<select class="form-control" id="txt_PP">
							<option></option>
						</select>
					</div>
				</div>
				<div class="col-xl-12 col-sm-6 col-md-6 col-lg-12" id="p_Dep">
					<div class="form-group mx-2">
						<label for="txt_Departamento">Departamento:</label>
						<select class="form-control" id="txt_Departamento">
							<option></option>
						</select>
					</div>
				</div>
				<div class="col-xl-12 col-sm-6 col-md-6 col-lg-12" id="p_Mun">
					<div class="form-group mx-2">
						<label for="txt_Municipio">Municipio:</label>
						<select class="form-control" id="txt_Municipio">
							<option></option>
						</select>
					</div>
				</div>
				<div class="col-xl-12 col-sm-6 col-md-6 col-lg-12">
					<div class="form-group text-center">
						<button class="btn btn-primary btn-lg" id="aplicar">APLICAR</button>
					</div>
				</div>
			</div>
			<hr class="d-lg-none mx-2" style="background: #A1DAE3;">
		</div>
		<div class="col-sm-12 col-md-12 col-lg-9">
			<!-- inicio grafico -->
			<div id="container" ></div>
			
			<!-- fin grafico -->
		<div>
	</div>
</body>
</html>
<?php require('../controllers/logear/cerrarSinSeccionAdmin.php');?>
<!DOCTYPE html>
<html lang="en">
<head>

	<meta charset="UTF-8">

	<link rel="stylesheet" type="text/css" href="../../css/bootstrap/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../../css/font-awesome/fontawesome-pro/css/all.min.css">
	<script type="text/javascript" src="../../js/Jquery/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="../../js/popper/popper.min.js"></script>
	<script type="text/javascript" src="../../js/bootstrap/bootstrap.js"></script>
	
	<script type="text/javascript" src="../../js/sweetalert2/sweetalert2.js"></script>
	<link rel="stylesheet" type="text/css" href="../../css/estilo.css">
	<script type="text/javascript" src="../../js/MainPP.js"></script>
	<script type="text/javascript" src="../../js/comunes.js"></script>

	<title>Document</title>
</head>
<body>
	<!--Cuadro principal  -->
	<div  class="cuadro_grande">
		<h3 class="text-uppercase text-center mt-2">GESTION DE PARTIDOS POLITICOS</h3>
		<!-- Botón abrir modal -->
		<div class="form-group">
			<button id="btn_insertar" class="btn btn-primary" title="Agregar nuevo partido politico" data-toggle="modal" data-target="#ventanaModal"><i class="fa fa-user"></i>&nbsp;NUEVO</button>
		</div>
	
		<!-- Input campo de búsqueda -->
		<div class="form-group">
			<div class="input-group mb-3">
				<input type="text" id="txt_busqueda" class="form-control" placeholder="Escriba aquí su término de búsqueda" aria-label="Escriba aquí su término de búsqueda" aria-describedby="basic-addon2">
				<div class="input-group-append" id="btn_borrar_busqueda" title="Limpiar barra de busqueda">
			    	<button class="input-group-text" id="basic-addon2">&times;</button>
				</div>
			</div>
		</div>
	
		<!-- Tabla -->
		<div id="div_tabla">
	
		</div>
		<!-- Fin Tabla -->
	
		<!-- Paginación -->
		<div class="d-flex justify-content-center paginas" >
			<nav aria-label="Page navigation example" class="">
			  <ul class="pagination" id="pagination">
	
			  </ul>
			</nav>
		</div>
		<!-- Fin Paginación -->
	</div>
<!--Fin cuadro principal   -->

<!-- Modal -->

<div class="modal fade" id="ventanaModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
		    <!-- div para mostrar la alerta -->
		  	<div id="alerta"></div>

			<!-- Cabecera modal -->
		    	<div class="modal-header">
		       	 	<h5 class="modal-title h4 text-center text-uppercase">Crear Nuevo Partido Politico</h5>
		        	 	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		        	 		 <span aria-hidden="true">&times;</span>
		       		 	</button>
		     	</div>
		     <!-- Fin cabecera modal -->

			<!-- Cuerpo  modal -->
		      	<div class="modal-body">
					<form enctype="multipart/form-data">
						<!-- Campos ocultos -->
						<div class="form-group">
							<input type="hidden" id="opcion" name="opcion">
							<input type="hidden" id="id" name="id">
							<input type="hidden" id="idpersona" name="idpersona">
						</div>
						

						<div class="row">	
							<div class="form-group col-12 m-0 text-center">
								<h4>Datos Candidato a Presidente:</h4>
							</div>
						<!-- vista previa de la imagen presidente-->
							<div class="form-group col-3 mb-1">
								<img class="imagen" src="../../images/usuario.png"  id="img_presidente">
							</div>
						<!-- Campo numero de dui -->
							<div class="form-group col-8 mb-1"">
								<label for="txt_DUI">Número de DUI: </label>
								<div class="input-group">
									<input type="text" id="txt_DUI" class="form-control" placeholder="00000000-0">
									<!-- <div class="input-group-append" title="Buscar Persona">
								    	<button type="button" class="input-group-text" id="btn_buscar_persona">
								    		<li class="fas fa-search"></li>
								    	</button>
									</div> -->
								</div>								
								<div class="text-danger" id="validacion_dui">
									PERSONA NO ENCONTRADA...
								</div>	
								<div class="text-danger" id="validacion_existe">						
								</div>							
							</div>	
						</div>


						<div class="row" id="nombre_presidente">
							<!-- campo nombre presidente -->
							<div class="form-group col-12  m-0">
								<span class="h5">Nombre:</span>
								<div class="d-inline-block h6" id="txt_nombre_presidente">
								</div>
							</div>
						</div>

						<hr class="mx-1">

						<div class="row">
							<div class="form-group col-12 m-0 text-center">
								<h4>Datos Partido Politico:</h4>
							</div>	
						<!-- vista previa de la imagen bandera -->
							<div class="form-group col-3">
								<img class="imagen" src="../../images/usuario.png"  id="img_bandera">
							</div>						
						<!-- Campo fotografia -->
							<div class="form-group col-8">
								<label for="txt_img">Fotografia: </label>
								<div class="custom-file">
								    <input type="file" class="custom-file-input " id="txt_img" name="txt_img">
								    <label class="custom-file-label" for="txt_img">Click aqui...</label>
								</div>
								<div class="text-danger" id="validacion_img">
									Formato de imagen no valido seleccione una imagen <strong>jpg o jpeg...</strong>
								</div>
							</div>
						</div>
						
						<div class="row">
							<!-- Campo nombre -->
							<div class="form-group col-12">
								<label for="txt_nombre">Nombre: </label>
								<input type="text" id="txt_nombre" name="txt_nombre" class="form-control" placeholder="Ingrese el nombre del Partido Politico">
								<div class="text-danger" id="validacion_nombre">
									Formato del nombre no valido...
								</div>
							</div>
							<!-- Campo abrebiatura -->
							<div class="form-group col-12">
								<label for="txt_abreviatura">Abreviatura: </label>
								<input type="text" id="txt_abreviatura" name="txt_abreviatura" class="form-control" placeholder="Ingrese las siglas del Partido Politico">
								<div class="text-danger" id="validacion_abreviatura">
									Formato del abrebiatura no valido...
								</div>
							</div>
						</div>	
					</form>
		     	</div>
		    <!-- Fin cuerpo modal -->

			<!-- Pie del modal -->
			<div class="modal-footer">
				<button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>		
				<button type="button" class="btn btn-success" id="btn_guardar_cambios">Guardar cambios</button>
			</div>
			<!-- Fin pie modal -->
		</div>
	</div>
</div>
<!-- Fin modal -->
</body>
</html>
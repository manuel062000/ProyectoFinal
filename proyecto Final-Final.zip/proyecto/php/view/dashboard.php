<?php require('../controllers/logear/dashboard.php');?>
<!DOCTYPE>
<html lang="en">
<head>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<meta charset="UTF-8">

	<link rel="stylesheet" type="text/css" href="../../css/bootstrap/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../../css/font-awesome/fontawesome-pro/css/all.min.css">
	<script type="text/javascript" src="../../js/Jquery/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="../../js/popper/popper.min.js"></script>
	<script type="text/javascript" src="../../js/bootstrap/bootstrap.js"></script>


	<link rel="stylesheet" type="text/css" href="../../css/estilo.css">
	<script type="text/javascript" src="../../js/dashboar.js"></script>
	<title>VOTACIONES</title>
</head>
<body>
<!--:::::::::::::::::::::barra de navegacion:::::::::::::::::::::-->
	<header class="bg-dark clearfix">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<nav class="navbar navbar-expand-md navbar-dark ">	
						<div class="container">
							<a class="navbar-brand text-light">SelectSalv</a>
							<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#tercera_navegacion">
								<span class="navbar-toggler-icon"></span>
							</button>
							<div class="collapse navbar-collapse" id="tercera_navegacion">
								<ul class="navbar-nav ml-auto">
									<li class="nav-item dropdown" id="menu_crud">
										<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
											<i class="fas fa-clipboard-list"></i>&nbsp;GESTION
										</a>
										
										<div class="dropdown-menu">			
												<a href="#" class="dropdown-item" id="ges_centros_votacion">
													<i class="fal fa-person-booth"></i>&nbsp;
													CENTROS DE VOTACION
												</a>
												<a href="#" class="dropdown-item" id="ges_junta_receptora">
													<i class="fal fa-person-carry"></i>&nbsp;
													JUNTAS RECEPTORAS
												</a>
												<a href="#" class="dropdown-item" id="ges_persona">
													<i class="far fa-user-edit"></i>&nbsp;
													PERSONAS
												</a>
												<a href="#" class="dropdown-item" id="ges_PP">
													<i class="fal fa-money-bill-wave-alt"></i>&nbsp;
													PARTIDOS POLITICOS
												</a>
												<a href="#" class="dropdown-item" id="ges_Usuario">
													<i class="far fa-users-medical"></i>&nbsp;
													USUARIOS
												</a>
												<a href="#" class="dropdown-item" id="ges_historial">
													<i class="fal fa-cabinet-filing"></i>&nbsp;
													HISTORIAL
												</a>
										</div>
									</li>
									<li class="nav-item">
										<a href="#" class="nav-link" id="reporte">
											<i class="fas fa-file-signature"></i>&nbsp;REPORTES
										</a>
									</li>
									<li class="nav-item">
										<a href="#" class="nav-link" id="estadisticas">
											<i class="fas fa-chart-line"></i>&nbsp;ESTADISTICAS
										</a>
									</li>
									<li class="nav-item">
										<a href="#" class="nav-link" id="votar">
											<i class="fal fa-ballot-check"></i>&nbsp;VOTAR
										</a>
									</li>
								</ul>
							</div>
						</div>
					</nav>
				</div>
			</div>
		</div>
	</header>
<!--:::::::::::::::::::::fin barra de navegacion::::::::::::::::::::: -->

<!--:::::::::::::::::::::Contenido:::::::::::::::::::::-->
	<article class="Contenido">
		<iframe width="100%" height="100%" scrolling="yes" frameborder="0" id="iframe" class="clearfix" src="perfil.php?d=true"></iframe>
	</article>
<!--:::::::::::::::::::::fin de Contenido:::::::::::::::::::::-->

<!--:::::::::::::::::::::Pie de paguina:::::::::::::::::::::-->
	<footer class="bg-dark clearfix">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<nav class="navbar navbar-expand-md navbar-dark ">	
						<div class="container">
							<a class="navbar-brand p-0 ">								
								<table>
									<tr>
										<td rowspan="2">
										<img src="" class="puntero" style="height: 50px;width: 50px; background:#ccc;" id="img_us">	
										</td>
										<td class="Usuario text-light text-uppercase" id="nombre">
											
										</td>
									</tr>
									<tr>
										<td class="Usuario text-light text-uppercase" id="apellido">
											
										</td>
									</tr>
								</table>
							</a>
							<ul class="navbar-nav ml-auto">
								<li class="nav-item">
									<button class="btn btn-danger" id="cerrarSesion">
										<i class="fas fa-power-off"></i>
										Cerrar Seción
									</button>
								</li>									
							</ul>							
						</div>
					</nav>
				</div>
			</div>
		</div>
	</footer>
<!--:::::::::::::::::::::fin Pie de paguina:::::::::::::::::::::-->
</body>
</html>
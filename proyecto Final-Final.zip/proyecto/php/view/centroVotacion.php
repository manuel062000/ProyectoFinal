<?php require('../controllers/logear/cerrarSinSeccionAdmin.php');?>
<!DOCTYPE >
<html lang="en">
<head>

	<meta charset="UTF-8">

	<link rel="stylesheet" type="text/css" href="../../css/bootstrap/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../../css/font-awesome/fontawesome-pro/css/all.min.css">
	<script type="text/javascript" src="../../js/Jquery/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="../../js/popper/popper.min.js"></script>
	<script type="text/javascript" src="../../js/bootstrap/bootstrap.js"></script>

	<script type="text/javascript" src="../../js/sweetalert2/sweetalert2.js"></script>
	<link rel="stylesheet" type="text/css" href="../../css/estilo.css">
	<script type="text/javascript" src="../../js/MainCentroVotacion.js"></script>
	<script type="text/javascript" src="../../js/comunes.js"></script>

	<title>Document</title>
</head>
<body >
	<!--Cuadro principal  -->
<div class="cuadro">
		<h3 class="text-uppercase text-center mt-2">GESTION DE CENTROS DE VOTACION</h3>
		
		<!-- Botón abrir modal -->
		<div class="form-group">
			<button id="btn_insertar" class="btn btn-primary" title="Agregar nuevo centro de votación" data-toggle="modal" data-target="#ventanaModal"><i class="fa fa-user"></i>&nbsp;NUEVO</button>
		</div>
		
		<!-- Input campo de búsqueda -->
		<div class="form-group">
			<div class="input-group mb-3">
				<input type="text" id="txt_busqueda" class="form-control" placeholder="Escriba aquí su término de búsqueda" aria-label="Escriba aquí su término de búsqueda" aria-describedby="basic-addon2">
				<div class="input-group-append" id="btn_borrar_busqueda" title="Limpiar barra de busqueda">
			    	<button class="input-group-text" id="basic-addon2">X</button>
				</div>
			</div>			
		</div>
		
		<!-- Tabla -->
		<div id="div_tabla">
		
		</div>
		<!-- Fin Tabla -->
		
		<!-- Paginación -->
		<div class="d-flex justify-content-center paginas" >
			<nav aria-label="Page navigation example" class="">
			  <ul class="pagination" id="pagination">
		
			  </ul>
			</nav>
		</div>
		<!-- Fin Paginación -->
	
</div>
<!--Fin cuadro principal   -->

<!-- Modal-->
<div class="modal fade" id="ventanaModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
		    	<!-- div para mostrar la alerta -->
		  	<div id="alerta"></div>

			<!-- Cabecera modal -->
		    	<div class="modal-header">
		       	 	<h5 class="modal-title h4 text-center text-uppercase">NUEVO CENTRO DE VOTACION</h5>
		        	 	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		        	 		 <span aria-hidden="true">&times;</span>
		       		 </button>
		     	</div>
		     	<!-- Fin cabecera modal -->

			<!-- Cuerpo  modal -->
		      	<div class="modal-body">
					<!-- Gif "Cargando" -->
					<div class="form-group d-none" id="gif">
						<label><img src="../images/ajax-loader.gif"> Procesando...</label>
					</div>
					<!-- Campos ocultos -->
					<div class="form-group">
						<input type="hidden" id="opcion">
						<input type="hidden" id="id">
					</div>
					<!-- Campo nombre -->
					<div class="form-group">
						<label for="txt_nombre">Nombre de Municipio: </label>
						<input type="text" value="" id="txt_nombre" class="form-control" placeholder="Ingrese su nombre">
						<div class="text-danger" id="validacion">
							Nombre de municipio no valido...
						</div>
					</div>
					<!-- Campo departamento-->
					<div class="form-group">
						<label for="txt_Departamento">Departamento:</label>
						<select id="txt_Departamento" class="form-control" >				   			
						</select>
					</div>
		     	 </div>
		     	 <!-- Fin cuerpo modal -->

			<!-- Pie del modal -->
			<div class="modal-footer">
				<button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
				<button type="button" class="btn btn-success" id="btn_guardar_cambios">Guardar cambios</button>
			</div>
			<!-- Fin pie modal -->
		</div>
	</div>
</div>
<!-- Fin modal -->
</body>
</html>
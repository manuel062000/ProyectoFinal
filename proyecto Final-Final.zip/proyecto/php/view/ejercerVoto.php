<?php require_once '../controllers/votar/sesionVotar.php'; ?>
<!DOCTYPE html>
<html lang="en" class="ejerVotoBody">
<head>
	
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../../css/font-awesome/fontawesome-pro/css/all.min.css">
	<script type="text/javascript" src="../../js/Jquery/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="../../js/popper/popper.min.js"></script>
	<script type="text/javascript" src="../../js/bootstrap/bootstrap.js"></script>

	<link rel="stylesheet" type="text/css" href="../../css/estilo.css">
	<script type="text/javascript" src="../../js/ejercerVoto.js"></script>

	<script type="text/javascript" src="../../js/sweetalert2/sweetalert2.js"></script>
	<script>
        
        	let inicializar=(nombre,apellido,genero)=>{
        		let bienvenida='';
        		if(genero=='M'){
        			bienvenida='Bienvenido';
        		}else{
        			bienvenida='Bienvenida';
        		}
        		if($(window).width()<992){
        			var texto1=bienvenida+', '+ nombre+' ' +apellido+'. Si no eres tú, has click en el botón rojo que se encuentra abajo de tú información al lado derecho. A continuacion de daré las instrucciones para ejercer tú voto';
        		}else{
        			var texto1=bienvenida+', '+ nombre+' ' +apellido+'. Si no eres tú, has click en el botón rojo que se encuentra abajo de tú información al lado izquierdo. A continuacion de daré las instrucciones para ejercer tú voto';
           		}
        		<?php 
	                echo "speechSynthesis.cancel();hablar1 = new SpeechSynthesisUtterance(texto1);window.speechSynthesis.speak(hablar1);";
	                echo "setInterval('indicaciones()',15000);";

	            ?>
			}
    </script>
</head>
<body class="ejerVotoBody bg-light">
	<div class="row ejerVotoMenu">
		<!-- usuario -->
		<div class="col-md-3 col-sm-12 p-3">
			<div class="card border-0 ml-3">
			  <img id="imagen" class="card-img-top" src="../../images/8a559bf3b7718096fea02a1d011c3123.jpg" alt="Card image cap">
			  <ul class="list-group list-group-flush mt-1">
			    <li class="list-group-item">
			    	<label class="font-weight-bold">DUI:</label>
					<label class="font-italic" id="dui">12345678-0</label>
			    </li>
			    <li class="list-group-item">
			    	<label class="font-weight-bold">Nombres:</label>
					<label class="font-italic" id="nombre">MANUEL ALEXANDER</label>
			    </li>
			    <li class="list-group-item">
			    	<label class="font-weight-bold">Apellidos:</label>
					<label class="font-italic" id="apellido">DELGADO HENRRIQUEZ</label>
			    </li>
			    <li class="list-group-item">
			    	<label class="font-weight-bold">Edad:</label>
					<label class="font-italic" id="edad">18&nbsp;AÑOS</label>
			    </li>
			    <li class="list-group-item">
			    	<label class="font-weight-bold">Junta Receptora:</label>
					<label class="font-italic" id="jr">JR1</label>
					<input type="hidden" id="jrID">
			    </li>
			  </ul>
			  <div class="card-body">
			    <button class="btn btn-danger float-right btn-lg" id="salir">Cancelar</button>
			  </div>
			</div>
		</div>
		<!-- fin usuario -->
		<!-- partidos -->
		<div class="col-md-9 col-sm-12 border-left ejerCon" >
			<div class="row" id="candidatos">
				
			</div>
		</div>
		<!-- fin partidos -->
	</div>
</body>
</html>
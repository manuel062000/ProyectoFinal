<?php require_once 'php/controllers/votar/votar_secion.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>INICIO DE SESION</title>
    <!-- meta tags -->
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="keywords" content="Art Sign Up Form Responsive Widget, Audio and Video players, Login Form Web Template, Flat Pricing Tables, Flat Drop-Downs, Sign-Up Web Templates, 
		Flat Web Templates, Login Sign-up Responsive Web Template, Smartphone Compatible Web Template, Free Web Designs for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design"
    />
    <!-- /meta tags -->
    <!-- custom style sheet -->
    <link href="css/estiloIndex.css" rel="stylesheet" type="text/css" />
    <!-- /custom style sheet -->

    <!-- google fonts-->
    <!-- <link href="//fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet"> -->
    <!-- /google fonts-->    
    <link rel="stylesheet" type="text/css" href="css/font-awesome/fontawesome-pro/css/all.min.css">
    <script type="text/javascript" src="js/Jquery/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="js/mainIndex.js"></script>
    <!-- <script type="text/javascript">
        $(document).ready(function() {
            <?php
             if(isset($_GET['r'])){
                if($_GET['r']==1){
                    echo "$('#validar').html('Usuario verificado con exito...').css({
                                display: 'block',
                            }).animate({height:'20px'}).delay(3000).animate({height:'0px'},function(){
                                $(this).css({display: 'none',});
                            });";
                }else{
                    echo "$('#validar').html('Error al verificar el usuario...').css({
                                display: 'block',
                            }).animate({height:'20px'}).delay(3000).animate({height:'0px'},function(){
                                $(this).css({display: 'none',});
                            });";
                }
            } ?>
        }); 
    </script> -->
</head>
<body>
    <div class="validar" id="validar">
        VALIDAR...
    </div>


    <div class=" w3l-login-form">
        <h2>Login</h2>
        <div class=" w3l-form-group">
            <label>Correo Electronico:</label>
            <div class="group">
                <i class="fas fa-user"></i>
                <input type="text" id="correo" class="form-control" placeholder="ejemplo@ejemplo.com"/>
            </div>
        </div>
        <div class=" w3l-form-group">
            <label>Contraseña:</label>
            <div class="group">
                <i class="fas fa-unlock"></i>
                <input id="Contra" type="password" autocomplete="off" class="form-control" placeholder="Contraseña"/>
                <i id="visualizarContra" class="far fa-eye"></i>
            </div>
        </div>
        <button id="logiarse">Login</button>
        <!-- <p class=" w3l-register-p">¿Has olvidado tu contraseña?&nbsp;<a href="#" class="register"> Click aqui...</a></p> -->
    </div>
    <footer>
        <p class="copyright-agileinfo"> &copy; SelectSalv</p>
    </footer>

</body>

</html>

var urlLista='../controllers/JuntaReceptora/ListaJuntaReceptora.php';
var urlPaginacion='../controllers/JuntaReceptora/paginacionJuntaReceptora.php';
$(document).ready(function(){
	let input_busqueda=$("#txt_busqueda");
	listar('');
	tipoListado(input_busqueda);
	crearPaginacion(2);
	ejecutarAccion();
	botonLimpiarBusqueda();
	ocultarCamposValidacion();
	llenarSelect('','');
	llenarSelect('1','');
	$("#txt_departamento").change(function() {/*llena el select municipio al cambiar de departamento*/
		let idDepa=$(this).val();
		llenarSelect(idDepa,'');
	});
});
let ocultarCamposValidacion=()=>{/*oculta los div de validacion*/
	$("#validacion").hide();
}
/*--------------------------------------------------------------*/
let llenarSelect=(idDepartamento,idSeleccion)=>{/*llena el select de departamento y municipio*/
	if(idDepartamento!=''){/*llenado del municipio*/
		$.ajax({
			url: '../controllers/JuntaReceptora/llenarSelect.php',
			type: 'POST',
			data:{
				idDepartamento:idDepartamento,
				idSeleccion:idSeleccion
			}
		})
		.done(function(data) {
			if(data == 1){
				$("#txt_junta_receptora").html('');
				$("#alerta").html
				('<div class="alert alert-danger text-center"><strong>¡ERROR!&nbsp;</strong>No existen municipios en el departamento seleccionado</div>');
			}else{
				$("#alerta").html('');
				$("#txt_junta_receptora").html(data);
			}
		});	
	}else{/*llenado del departamento*/
		$.ajax({
			url: '../controllers/JuntaReceptora/llenarSelect.php',
			type: 'POST',
			data:{
				idDepartamento:idDepartamento
			}
		})
		.done(function(data) {
			$("#txt_departamento").html(data);
		});	
	}
}
/*--------------------------------------------------------------*/
/*------------CRUD----------*/
let quitarAlerta=()=>{/*quitara el mensaje de alerta al intentar crud de nuevo*/
	$("#alerta").html("");
}
let botonLimpiarBusqueda=()=>{/*limpia la busqueda al cliquiar el boton con la X*/
	$("#btn_borrar_busqueda").on("click",function(){
		if($("#txt_busqueda").val()!=''){
			$("#txt_busqueda").val('');
		}
	});
}
let desbloquearBoton=()=>{
	$("#btn_guardar_cambios").removeAttr('disabled');
}
let alerta=(opcion,respuesta)=>{/*prepara el mensaje a mostrar*/
	let mensaje="";
	let cerrar=false;
	switch(opcion) {
		case 'editar':
			mensaje="Informacion de Junta Receptora Modificada con Exito";
			cerrar=true;
			break;
		case 'agregar':
			mensaje="Junta Receptora Agregada Correctamente";
			break;
		case 'eliminar':
			mensaje="Junta Receptora Eliminada Exitosamente";
			cerrar=true;
			break;
	}
	switch(respuesta) {
		case 'BIEN':
			sweetalert('¡EXCELENTE!',mensaje,'success',cerrar);
			break;
		case 'ERROR':
			sweetalert('¡ERROR!','Solicitud no procesada','error',false);
			break;
		case 'IGUAL':
			sweetalert('¡ADVERTENCIA!','Ha enviado los mismos datos','warning',false);
			break;
		case 'VACIO':
			sweetalert('¡ERROR!','No puede enviar datos vacios','info',false);
			break;
		case 'FECHAS':
			sweetalert('¡ERROR!','Ya no puedes alterar los dato porque faltan 3 o menos meses para las votaciones...','error',false);
			break;
	}
}
let ejecutarAccion=()=>{/*metodo que me modifica,agrega y elimina*/
	$("#btn_guardar_cambios").on("click",function(){
		let nombre=$("#txt_nombre").val();
		let opcion=$("#opcion").val();
		let idJuntaReceptora=$("#id").val();
		let idMunicipio=$("#txt_junta_receptora").val();

		var exprecion=/^[A-Za-z\-0-9\s]+$/;
		if(nombre == '' || !exprecion.test(nombre)){
			$("#validacion").fadeIn();
			return false;
		}else{
			$("#validacion").fadeOut();
			$.ajax({
				beforeSend: function(){
					$("#git").toggleClass('d-none');
				},
				url: '../controllers/JuntaReceptora/crudJuntaReceptora.php',
				method: 'POST',
				data:{
					opcion:opcion,
					idJuntaReceptora:idJuntaReceptora,
					nombre:nombre,
					idMunicipio:idMunicipio
				}
			}).done(function(data) {
				$("#git").toggleClass('d-none');
				alerta(opcion,data);
				listar($("#txt_busqueda").val());
				crearPaginacion(2);
				if(opcion=='agregar' && data=='BIEN'){
					$("#id").val("");
					$("#txt_nombre").val("");
				}else if(opcion=='eliminar' && data=='BIEN'){
					$("#btn_guardar_cambios").attr("disabled",true);				
				}
			});
		}
	});	
}
/*-------------------------------------------------*/
/*-------------------------------------------------*/

/*-------------agrega los datos a los campos automaticamente------------*/
let prepararDatos=()=>{
	let values=[];
	/*-- Evento boton editar --*/
	$("#table .editar").on("click",function(){
		ocultarCamposValidacion();
		values=ciclo($(this));
		$("#opcion").val("editar");
		$("#id").val(values[0]);
		$("#txt_nombre").val(values[3]).removeAttr('disabled');
		$("#txt_junta_receptora").removeAttr('disabled');
		$("#txt_departamento").removeAttr('disabled');	
		//select departamento
		$('#txt_departamento option[value="'+values[1]+'"]').attr("selected", true);			
		//select municipio
		llenarSelect($("#txt_departamento").val(),values[2]);	
		//salvadoreño por	
		cambiarTitulo("Editar Junta Receptora");
		quitarAlerta();
		desbloquearBoton();
		$("#btn_guardar_cambios").show();
		$("#btn_guardar_cambios").html('Guardar Cambios');
	});
	/*-- Evento boton eliminar --*/
	$("#table .eliminar").on("click",function(){
		ocultarCamposValidacion();
		values=ciclo($(this));
		$("#opcion").val("eliminar");
		$("#id").val(values[0]);
		$("#txt_nombre").val(values[3]).attr("disabled",true);
		$("#txt_junta_receptora").attr("disabled",true);	
		$("#txt_departamento").attr("disabled",true);	
		//select departamento
		$('#txt_departamento option[value="'+values[1]+'"]').attr("selected", true);			
		//select municipio
		llenarSelect($("#txt_departamento").val(),values[2]);	
		cambiarTitulo("Eliminar Junta Receptora");
		quitarAlerta();
		desbloquearBoton();
		$("#btn_guardar_cambios").show();
		$("#btn_guardar_cambios").html('Eliminar');
	});
	/*-- Evento boton ver --*/
	$("#table .ver").on("click",function(){
		ocultarCamposValidacion();
		values=ciclo($(this));
		$("#opcion").val("ver");
		$("#id").val(values[0]);
		$("#txt_nombre").val(values[3]).attr("disabled",true);
		$("#txt_junta_receptora").attr("disabled",true);	
		$("#txt_departamento").attr("disabled",true);	
		//select departamento
		$('#txt_departamento option[value="'+values[1]+'"]').attr("selected", true);			
		//select municipio
		llenarSelect($("#txt_departamento").val(),values[2]);	
		cambiarTitulo("Ver Junta Receptora");
		quitarAlerta();
		desbloquearBoton();
		$("#btn_guardar_cambios").hide();
	});
	/*-- Evento boton agregar --*/
	$("#btn_insertar").on("click",function(){
		ocultarCamposValidacion();
		$("#opcion").val("agregar");
		$("#id").val("");
		$("#txt_nombre").val("").removeAttr('disabled');
		$("#txt_junta_receptora").removeAttr('disabled');
		$("#txt_departamento").removeAttr('disabled');
		cambiarTitulo("Agregar Junta Receptora");
		quitarAlerta();
		desbloquearBoton();
		$("#btn_guardar_cambios").show();
		$("#btn_guardar_cambios").html('Agregar');
	});
}
let cambiarTitulo=(titulo)=>{/*cambia el titulo del cuadro modal dependiendo la accion*/
	$(".modal-header .modal-title").text(titulo)
}
let ciclo=(selector)=>{/*recorre la fila de los datos que se desean hacerle crud*/
	let datos=[];
	$(selector).parents('tr').find('td').each(function(i) {
		if(i<5){/*6 significa total columnas existentes*/
			datos[i]=$(this).text();
		}else{
			return false;
		}
	});
	return datos;
}
/*-------------------------------------------------------------*/
/*-------------------------------------------------------------*/

/*------------------Listar Las Personas------------------------*/
let listar=(param)=>{/*muestra los registros solicitados*/
	$.ajax({
		url: '../controllers/JuntaReceptora/ListaJuntaReceptora.php',
		method:'POST',
		data:{
			termino:param
		}
	})
	.done(function(data) {
		$("#div_tabla").html(data);
		prepararDatos();
	});	
}
let tipoListado=(input)=>{/*comprueba que registros se solicitan*/
	$(input).on("keyup",function(){
		let termino='';
		if($(this).val()!=''){
			termino=$(this).val();
		}
		listar(termino);
	});
}
/*-----------------------------------------------------------------*/
/*-----------------------------------------------------------------*/
var urlLista='../controllers/partidosPoliticos/ListaPP.php';
var urlPaginacion='../controllers/partidosPoliticos/paginacionPP.php';
$(document).ready(function(){
	guion('txt_DUI');
	$("#txt_DUI").on('keyup', function() {
		var Exp_dui=/^\d{8}-[0-9]$/;
		if(Exp_dui.test($(this).val())){
			llenarCampoDui();
		}else if($(this).val().length==0){
			$("#idpersona").val('');
			$("#validacion_dui").hide();
			$("#validacion_existe").hide();	
			$("#img_presidente").attr('src','../../images/usuario.png');
			$("#nombre_presidente").hide();
			$("#validacion_dui").hide();
			$(this).removeClass("is-invalid");
			$(this).removeClass("is-valid");
		}else if($(this).val().length>0){
			$(this).addClass("is-invalid");
			$(this).removeClass("is-valid");
			$("#idpersona").val('');
			$("#validacion_dui").hide();
			$("#validacion_existe").hide();	
			$("#img_presidente").attr('src','../../images/usuario.png');
			$("#nombre_presidente").hide();
			$("#validacion_dui").show();
		}				
	});

	$("#txt_busqueda").val('');/*limpia el campo busqueda para que siempre salga vacio al iniciar*/
	let input_busqueda=$("#txt_busqueda");
	let campoImagen=$("#Mostrar_img");
	listar('');
	tipoListado(input_busqueda);
	crearPaginacion(2);
	ejecutarAccion();
	botonLimpiarBusqueda();
	ocultarCamposValidacion();
	
	$("#txt_img").on('change',function(){/*preparar la vista previa de las imagenes a subir*/
		var archivos=document.getElementById("txt_img").files;
		var navegador= window.URL || window.webkitURL;

		var type=archivos[0].type;
		var name=archivos[0].name;

		if(type!='image/jpg' && type!='image/jpeg'){
			$("#validacion_img").html("Formato de imagen no valido seleccione una imagen <strong>jpg o jpeg...</strong>");
			$("#validacion_img").fadeIn();
		}else if(archivos.length > 1){
			$("#validacion_img").html("No se puede seleccionar mas de una imagen...");
			$("#validacion_img").fadeIn();
		}
		else{
			var objeto_url=navegador.createObjectURL(archivos[0]);
			$("#img_bandera").attr("src",objeto_url);
			$("#validacion_img").fadeOut();
		}
	});
});
let llenarCampoDui=()=>{
	let dui=$("#txt_DUI").val();
	let idPartido=$("#id").val();
	$.ajax({
		url: '../controllers/partidosPoliticos/llenarIdPersona.php',
		type: 'post',
		dataType: 'json',
		data: {dui: dui,id: idPartido},
	}).done(function(data) {
		if(data.res=='EXISTE'){
			$("#idpersona").val('');
			$("#nombre_presidente").show();
			$("#txt_nombre_presidente").html(data.nombre);
			$("#validacion_existe").html('La persona ya es candidato para el partido: '+data.partido).fadeIn();
			$("#img_presidente").attr('src','../../images/'+data.img);
			$("#validacion_dui").hide();

			$("#txt_DUI").addClass("is-invalid");
			$("#txt_DUI").removeClass("is-valid");
		}else if(data.res=='DUI'){
			$("#idpersona").val('');
			$("#nombre_presidente").hide();
			$("#img_presidente").attr('src','../../images/usuario.png');
			$("#validacion_dui").show();
			$("#validacion_existe").hide();
			
			$("#txt_DUI").addClass("is-invalid");
			$("#txt_DUI").removeClass("is-valid");	
		}else if(data.res=='BIEN'){
			$("#idpersona").val(data.id);
			$("#txt_nombre_presidente").html(data.nombre);
			$("#nombre_presidente").show();
			$("#img_presidente").attr('src','../../images/'+data.img);
			$("#validacion_dui").hide();
			$("#validacion_existe").hide();
			
			$("#txt_DUI").addClass("is-valid");
			$("#txt_DUI").removeClass("is-invalid");
		}
	});
	
}
let ocultarCamposValidacion=()=>{/*oculta los div de validacion*/
	$("#validacion_dui").hide();
	$("#nombre_presidente").hide();
	$("#validacion_img").hide();
	$("#validacion_nombre").hide();
	$("#validacion_abreviatura").hide();
}
/*------------CRUD----------*/
let quitarAlerta=()=>{/*quitara el mensaje de alerta al intentar crud de nuevo*/
	$("#alerta").html("");
}
let botonLimpiarBusqueda=()=>{/*limpia la busqueda al cliquiar el boton con la X*/
	$("#btn_borrar_busqueda").on("click",function(){
		if($("#txt_busqueda").val()!=''){
			listar('');
			$("#txt_busqueda").val('');
		}
	});
}
let desbloquearBoton=()=>{/*habilita el boton de guardar cambios por si se elimino y luego se quiere agregar o modificar*/
	$("#btn_guardar_cambios").removeAttr('disabled');
}
let alerta=(opcion,respuesta)=>{/*prepara el mensaje a mostrar en el header del modal*/
	let mensaje="";
	let cerrar=false;
	switch(opcion) {
		case 'editar':
			mensaje="Informacion de Partido Politico Modificada con Exito";
			cerrar=true;
			break;
		case 'agregar':
			mensaje="Partido Politico Agregado Correctamente";
			break;
		case 'eliminar':
			mensaje="Partido Politico Eliminado Exitosamente";
			cerrar=true;
			break;
	}
	switch(respuesta) {/*evalua distintas validaciones retornadas desde php para mostrar un mensaje en el div alerta en el  modal*/
		case 'BIEN':
			sweetalert('¡EXCELENTE!',mensaje,'success',cerrar);
			break;
		case 'ERROR':
			sweetalert('¡ERROR!','Solicitud no procesada','error',false);
			break;
		case 'IGUAL':
			sweetalert('¡ADVERTENCIA!','Ha enviado los mismos datos','warning',false);
			break;
		case 'VACIO':
			sweetalert('¡ERROR!','No puede enviar datos vacios','info',false);
			break;
		case 'FORMATO':
			sweetalert('¡ERROR!','Formato de imagen no valido seleccionar imagen formato "jpg o jpeg"','info',false);
			break;
		case 'DUI':
			sweetalert('¡ERROR!','El DUI ingresado ya existe en otro partido politico','info',false);
			break;
		case 'FECHAS':
			sweetalert('¡ERROR!','Ya no puedes alterar los dato porque faltan 3 o menos meses para las votaciones...','error',false);
			break;
	}
}
let ejecutarAccion=()=>{/*metodo que me modifica,agrega y elimina*/
	$("#btn_guardar_cambios").on("click",function(){
		/*validaciones de campos--------*/
		
		var Exp_nombre=/^[A-Za-z\sñÑáéíóúÁÉÍÓÚ1-9]+$/g;
		var Exp_Abre=/^[A-Za-z\sñÑáéíóúÁÉÍÓÚ1-9]+$/g;
		var bandera=true;/*bandera para saber si los campos son validos TRUE=campos validos,FALSE=campos no validos*/
		if($("#txt_nombre").val() == '' || !Exp_nombre.test($("#txt_nombre").val())
			|| $("#txt_nombre").val().length>100){
			bandera=false;
			$("#validacion_nombre").fadeIn();
		}else{
			$("#validacion_nombre").fadeOut();
		}
		if($("#txt_abreviatura").val() == '' || !Exp_Abre.test($("#txt_abreviatura").val())
			|| $("#txt_abreviatura").val().length>15){
			bandera=false;
			$("#validacion_abreviatura").fadeIn();
		}else{
			$("#validacion_abreviatura").fadeOut();
		}
		/*fin validacion de campos--------*/

		if(bandera){/*verifica que la validacion de campos este correcta*/
			let opcion=$("#opcion").val();
			let parametros=new FormData($("form")[0]);
			$.ajax({
				beforeSend: function(){
					$("#git").toggleClass('d-none');
				},
				data:parametros,
				url: '../controllers/partidosPoliticos/crudPP.php',
				method: 'POST',
				contentType:false,
				processData:false,
			}).done(function(data) {
				$("#git").toggleClass('d-none');
				alerta(opcion,data);
				listar($("#txt_busqueda").val());
				crearPaginacion(2);
				if(opcion=='agregar' && data=='BIEN'){
					$("#id").val("");
					$("#txt_DUI").val('');
					$("#txt_nombre").val('');
					$("#txt_abreviatura").val('');
					$("#img_bandera").attr('src','../../images/bandera-default.jpg');
					$("#img_presidente").attr('src','../../images/usuario.png');
					$("#txt_img").val('');
					$("#validacion_dui").hide();
					$("#validacion_existe").hide();
					$("#txt_DUI").removeClass("is-valid");
					$("#txt_DUI").removeClass("is-invalid");
					limpiarInputFile();	
				}else if(opcion=='eliminar' && data=='BIEN'){
					$("#btn_guardar_cambios").attr("disabled",true);				
				}else if(opcion=='editar' && (data=='BIEN' || data=='IGUAL')){
					limpiarInputFile();				
				}
			});
		}
	});	
}
/*-------------------------------------------------*/
/*-------------------------------------------------*/

/*-------------agrega los datos a los campos automaticamente------------*/
let limpiarInputFile=()=>{/*borra el valor del input file*/
	var control=$("input:file");
	control.replaceWith( control = control.val('').clone( true ) );
}
let prepararDatos=()=>{/*prepara los datos llevandolos de la tabla a los campos del modal*/
	let values=[];
	/*-- Evento boton editar --*/
	$("#table .editar").on("click",function(){
		ocultarCamposValidacion();
		values=ciclo($(this));
		$("#opcion").val("editar");
		$("#id").val(values[0]);
		$("#idpersona").val(values[1]);
		$("#img_bandera").attr('src','../../images/'+values[2]);
		$("#img_presidente").attr('src','../../images/'+values[3]);
		$("#txt_nombre").val(values[4]).removeAttr('disabled');
		$("#txt_abreviatura").val(values[5]).removeAttr('disabled');
		$("#txt_nombre_presidente").html(values[6]).attr("disabled",true);
		$("#nombre_presidente").show();
		$("#txt_DUI").val(values[7]).removeAttr('disabled');
		$("#btn_buscar_persona").removeAttr('disabled');
		$("#txt_img").val('').removeAttr('disabled');
		$("#validacion_dui").hide();
		$("#validacion_existe").hide();
		$("#txt_DUI").removeClass("is-valid");
		$("#txt_DUI").removeClass("is-invalid");
		limpiarInputFile();
		cambiarTitulo("Editar Partido Politico");
		quitarAlerta();
		desbloquearBoton();
		$("#btn_guardar_cambios").show();
		$("#btn_guardar_cambios").html('Guardar Cambios');
	});
	/*-- Evento boton eliminar --*/
	$("#table .eliminar").on("click",function(){
		ocultarCamposValidacion();
		values=ciclo($(this));
		$("#opcion").val("eliminar");
		//-------------------
		$("#id").val(values[0]);
		$("#idpersona").val(values[1]);
		$("#img_bandera").attr('src','../../images/'+values[2]);
		$("#img_presidente").attr('src','../../images/'+values[3]);
		$("#txt_nombre").val(values[4]).attr("disabled",true);
		$("#txt_abreviatura").val(values[5]).attr("disabled",true);
		$("#txt_nombre_presidente").html(values[6]).attr("disabled",true);
		$("#nombre_presidente").show();
		$("#txt_DUI").val(values[7]).attr("disabled",true);
		$("#btn_buscar_persona").attr("disabled",true);
		$("#txt_img").attr("disabled",true);
		$("#validacion_dui").hide();
		$("#validacion_existe").hide();
		$("#txt_DUI").removeClass("is-valid");
		$("#txt_DUI").removeClass("is-invalid");
		//-------------------		
		cambiarTitulo("Eliminar Partido Politico");
		quitarAlerta();
		desbloquearBoton();
		$("#btn_guardar_cambios").show();
		$("#btn_guardar_cambios").html('Eliminar');
	});
	/*-- Evento boton ver --*/
	$("#table .ver").on("click",function(){
		ocultarCamposValidacion();
		values=ciclo($(this));
		$("#opcion").val("ver");
		//-------------------
		$("#id").val(values[0]);
		$("#idpersona").val(values[1]);
		$("#img_bandera").attr('src','../../images/'+values[2]);
		$("#img_presidente").attr('src','../../images/'+values[3]);
		$("#txt_nombre").val(values[4]).attr("disabled",true);
		$("#txt_abreviatura").val(values[5]).attr("disabled",true);
		$("#txt_nombre_presidente").html(values[6]).attr("disabled",true);
		$("#nombre_presidente").show();
		$("#txt_DUI").val(values[7]).attr("disabled",true);
		$("#btn_buscar_persona").attr("disabled",true);
		$("#txt_img").attr("disabled",true);
		$("#validacion_dui").hide();
		$("#validacion_existe").hide();
		$("#txt_DUI").removeClass("is-valid");
		$("#txt_DUI").removeClass("is-invalid");
		//-------------------		
		cambiarTitulo("Ver Partido Politico");
		quitarAlerta();
		desbloquearBoton();
		$("#btn_guardar_cambios").hide();
	});
	/*-- Evento boton agregar --*/
	$("#btn_insertar").on("click",function(){
		ocultarCamposValidacion();
		$("#opcion").val("agregar");
		$("#id").val('');
		$("#idpersona").val('');
		$("#txt_DUI").val('').removeAttr('disabled');
		$("#btn_buscar_persona").removeAttr('disabled');
		$("#txt_nombre").val('').removeAttr('disabled');
		$("#txt_abreviatura").val('').removeAttr('disabled');
		$("#txt_img").val('').removeAttr('disabled');
		$("#img_bandera").attr('src','../../images/bandera-default.jpg');
		$("#img_presidente").attr('src','../../images/usuario.png');
		$("#validacion_dui").hide();
		$("#validacion_existe").hide();
		$("#txt_DUI").removeClass("is-valid");
		$("#txt_DUI").removeClass("is-invalid");
		cambiarTitulo("Crear Nuevo Partido Politico");
		quitarAlerta();
		desbloquearBoton();
		$("#btn_guardar_cambios").show();
		$("#btn_guardar_cambios").html('Agregar');
	});
}

let cambiarTitulo=(titulo)=>{/*cambia el titulo del cuadro modal dependiendo la accion*/
	$(".modal-header .modal-title").text(titulo)
}
let ciclo=(selector)=>{/*recorre la fila de los datos que se desean hacerle crud*/
	let datos=[];
	$(selector).parents('tr').find('td').each(function(i) {
		if(i<8){/*8 significa total columnas existentes*/
			datos[i]=$(this).text();
		}else{
			return false;
		}
	});
	return datos;
}
/*-------------------------------------------------------------*/
/*-------------------------------------------------------------*/

/*------------------Listar Las Partido Politico------------------------*/
// var cambiarPagina = () => {/*cambia la paginacion de los registros*/
//     $('.page-item>.page-link').on('click', function() {
//         $.ajax({
//             url: '../controllers/partidosPoliticos/ListaPP.php',
//             method: 'POST',
//             data: {
//                 pagina: $(this).text()
//             }
//         }).done(function(data) {
//             $('#div_tabla').html(data);
//             prepararDatos();
//         });
//     });
// }
// let crearPaginacion=()=>{/*creacion de los botones de paginacion*/
// 	$.ajax({
// 		url: '../controllers/partidosPoliticos/paginacionPP.php',
// 		method: 'POST'
// 	})
// 	.done(function(data) {
// 		$("#pagination li").remove();
// 		for (var i = 1; i <= data; i++) {
// 			$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute">'+i+'</a></li>');
// 		}
// 		cambiarPagina();
// 	});
// }
let listar=(param)=>{/*muestra los registros solicitados*/
	$.ajax({
		url: '../controllers/partidosPoliticos/ListaPP.php',
		method:'POST',
		data:{
			termino:param
		}
	})
	.done(function(data) {
		$("#div_tabla").html(data);
		prepararDatos();
	});	
}
let tipoListado=(input)=>{/*comprueba que registros se solicitan*/
	$(input).on("keyup",function(){
		let termino='';
		if($(this).val()!=''){
			termino=$(this).val();
		}
		listar(termino);
	});
}
/*-----------------------------------------------------------------*/
/*-----------------------------------------------------------------*/
$(document).ready(function(){
	$("#votar").click(function(){
		if($("#iframe").attr("src")!="activarVotar.php"){
			$("#iframe").fadeOut(300,function(){
				$(this).fadeIn(1000).attr("src","activarVotar.php?d=true");
			});
		}		
	});

	$("#ges_historial").click(function(){
		if($("#iframe").attr("src")!="Historial.php"){
			$("#iframe").fadeOut(300,function(){
				$(this).fadeIn(1000).attr("src","Historial.php?d=true");
			});
		}		
	});

	$("#estadisticas").click(function(){
		if($("#iframe").attr("src")!="estadisticas.php"){
			$("#iframe").fadeOut(300,function(){
				$(this).fadeIn(1000).attr("src","estadisticas.php?d=true");
			});
		}		
	});

	$("#reporte").click(function(){
		if($("#iframe").attr("src")!="reporte.php"){
			$("#iframe").fadeOut(300,function(){
				$(this).fadeIn(1000).attr("src","reporte.php?d=true");
			});
		}		
	});

	$("#ges_persona").click(function(){
		if($("#iframe").attr("src")!="gestionPersona.php"){
			$("#iframe").fadeOut(300,function(){
				$(this).fadeIn(1000).attr("src","gestionPersona.php?d=true");
			});
		}		
	});

	$("#ges_centros_votacion").click(function(){
		if($("#iframe").attr("src")!="/centroVotacion.php"){
			$("#iframe").fadeOut(300,function(){
				$(this).fadeIn(1000).attr("src","centroVotacion.php?d=true");
			});
		}
	});
	$("#ges_junta_receptora").click(function(){
		if($("#iframe").attr("src")!="juntaReceptora.php"){
			$("#iframe").fadeOut(300,function(){
			$(this).fadeIn(1000).attr("src","juntaReceptora.php?d=true");
		});
		}
	});

	$("#ges_PP").click(function(){
		if($("#iframe").attr("src")!="partidosPoliticos.php"){
			$("#iframe").fadeOut(300,function(){
			$(this).fadeIn(1000).attr("src","partidosPoliticos.php?d=true");
		});
		}
	});

	$("#ges_Usuario").click(function(){
		if($("#iframe").attr("src")!="Usuarios.php"){
			$("#iframe").fadeOut(300,function(){
			$(this).fadeIn(1000).attr("src","Usuarios.php?d=true");
		});
		}
	});
	$("#img_us").click(function(){
		if($("#iframe").attr("src")!="perfil.php"){
			$("#iframe").fadeOut(300,function(){
			$(this).fadeIn(1000).attr("src","perfil.php?d=true");
		});
		}
	});
	$("#cerrarSesion").on('click',function(){
		$.ajax({
			url: '../controllers/logear/cerrarSecion.php',
			type: 'POST',
		})
		.done(function(data) {
			if(data=='BIEN'){
				location.href='../../index.php';
			}
		});		
	});
	cargarUS();
});

let cargarUS=()=>{
	$.ajax({
		url: '../controllers/logear/cargarUsuario.php',
		type: 'post',
		dataType: 'json',
	})
	.done(function(data) {
		$("#nombre").html(data.nombre);
		$("#apellido").html(data.apellido);
		$("#img_us").attr('src','../../images/'+data.img);
		if(data.rol!='ADMINISTRADOR'){
			$("#menu_crud").hide();
		}
	});
	
}
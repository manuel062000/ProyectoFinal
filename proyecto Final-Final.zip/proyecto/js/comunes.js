/*------------------paginacion------------------------*/
var paginaAc=1;
var totalPaginas=0;
var primerapg=1;
var cambiarPagina = () => {/*cambia la paginacion de los registros*/
    $('.page-item>.page-link').stop().on('click', function(e) {
    	let pg= parseInt($(this).text());
    	if($(this).attr('id')!='Ant' && $(this).attr('id')!='sig' && $(this).text()!='...'){
	        paginaAc=pg;
			$.ajax({
	            url: urlLista,
	            method: 'POST',
	            data: {
	                pagina: paginaAc
	            },
	            success:function(data){
	            	$("#txt_busqueda").val('');
		            $('#div_tabla').html(data);
		            prepararDatos();
		            verificarPg(pg);
	            },
	        });
    	}
    });
}
var cambiarPaginaSig = () => {/*cambia la paginacion de los registros*/
    $('#sig').stop().click(function() {
    	let pg=paginaAc+1;
    	if(pg<=totalPaginas){
    		paginaAc=pg;
		    $.ajax({
		        url: urlLista,
		        method: 'POST',
		        data: {
		            pagina: pg,
		        },
		        success: function(data){
		        	$("#txt_busqueda").val('');
			        $('#div_tabla').html(data);
			        prepararDatos();
			        verificarPg(pg);
		        },
		    });
    	}
    	
    });
}
let verificarPg=(pg)=>{
	if(pg==primerapg+4 && pg<totalPaginas-3){//si el ultimo
	    crearPaginacion(2); 
	}
	else if(pg==primerapg && pg>4){//dubujar para atras(click en primera pg)
		crearPaginacion(5);
	}
	else if(pg==1 || pg==2 || pg==3 || pg==4){//si es de las primeras 4
		crearPaginacion(4);
	}
	else if(pg>=totalPaginas-3){//si es de los ultimos 4
		crearPaginacion(3);
	}
	else if(pg >primerapg && pg<primerapg+4){//si es de los de enmedio
		crearPaginacion(1);
	}else{
		primerapg=paginaAc-4;
		verificarPg(parseInt(pg));
	}
}
var cambiarPaginaAnt = () => {/*cambia la paginacion de los registros*/
    $('#Ant').stop().on('click', function() {
    	let pg=paginaAc-1;
    	if(paginaAc>1){
    		paginaAc=pg;
	        $.ajax({
	            url: urlLista,
	            method: 'POST',
	            data: {
	                pagina: pg,
	            },
	            success:function(data){
	            	$("#txt_busqueda").val('');
		            $('#div_tabla').html(data);
		            prepararDatos();
		            verificarPg(pg);
	            },
	        });
    	}
    });
}
let crearPaginacion=(valor)=>{/*creacion de los botones de paginacion*/
	$.ajax({
		url: urlPaginacion,
		method: 'POST'
	})
	.done(function(data) {
		$("#pagination li").remove();
		$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" id="Ant"><i class="far fa-angle-double-left"></i>&nbsp;</a></li>');
		if(paginaAc>=5 && totalPaginas > 5){
			$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute">1</a></li>');				
			$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute">...</a></li>');				
		}
		let con;
		totalPaginas=parseInt(data);
			if(valor == 1){//si es de los de enmedio
				con=primerapg+4;
				for (var j = primerapg; j <= totalPaginas; j++) {
					if(j<=primerapg+4){
						if(paginaAc==j){
							$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" style="background: #ffc187;">'+j+'</a></li>');
						}else{
							$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute">'+j+'</a></li>');
						}
					}
				}
			}else if(valor==2){//cuando es el ultimo
				for(var j = paginaAc; j <= data; j++) {
					if(j<paginaAc+5){
						if(paginaAc==j){
							$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" style="background: #ffc187;">'+j+'</a></li>');
						}else{
							$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute">'+j+'</a></li>');
						}
						con=j;
					}
				}
			}else if(valor==3){//que sea ultimo,penultio o antepenultimo
				con=totalPaginas;
				for (var j = totalPaginas-4; j <= totalPaginas; j++) {
					if(paginaAc==j){
						$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" style="background: #ffc187;">'+j+'</a></li>');
					}else{
						$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute">'+j+'</a></li>');
					}
				}
			}else if(valor==4){//si es de las primeras 4
				for (var j = 1; j <= data; j++) {
					if(j<=5){
						if(paginaAc==j){
							$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" style="background: #ffc187;">'+j+'</a></li>');
						}else{
							$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute">'+j+'</a></li>');
						}
						con=j;
					}
				}
			}else if(valor==5){//dubujar para atras(click en primera pg)
				for (var j = paginaAc-4; j <= data; j++) {
					if(j<=paginaAc){
						if(paginaAc==j){
							$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" style="background: #ffc187;">'+j+'</a></li>');
						}else{
							$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute">'+j+'</a></li>');
						}
						con=j;
					}
				}
			}
		if(paginaAc<totalPaginas-3 && totalPaginas>5){
			$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute">...</a></li>');		
			$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute">'+totalPaginas+'</a></li>');		
		}
		$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" id="sig">&nbsp;<i class="far fa-angle-double-right"></i></a></li>');				
		
		primerapg = con-4;
		cambiarPagina();
		cambiarPaginaSig();
		cambiarPaginaAnt();
	});
}
// ------------------------------------------------------------
// ------------------------------------------------------------

//------------------- mostrar mensaje-------------------------
let sweetalert=(titulo,texto,icono,ocultar)=>{
	swal({
		title: titulo,
		text: texto,
		icon: icono,
		timer: 10000,
		confirmButtonColor:	"#FF6B5C",
	    showConfirmButton: true,
		}).then((value) => {
			if(ocultar){
				$(".modal").modal('toggle');
			}else if(ocultar==null){
				$.ajax({
					url: '../controllers/logear/cargarUsuario.php',
					type: 'post',
					dataType: 'json',
				})
				.done(function(data) {
					$("#nombre", window.parent.document).html(data.nombre);
					$("#apellido", window.parent.document).html(data.apellido);
					$("#img_us", window.parent.document).attr('src','../../images/usuario.png');
					$("#img_us", window.parent.document).attr('src','../../images/'+data.img);
				});
				$(".modal").modal('toggle');
			}
	});
}
// -----------------------------------------
// ------------------ guion automatico en dui-------------------
 let guion=(id)=>{
 	$("#"+id).on('keyup',function(e){
 		let cadena = $(this).val();
 		let imprimir = cadena;
 		if(cadena.length== 9 && cadena.substring(9,8)!='-' && e.which!=189){
 			imprimir = cadena.substring(8,0)+'-'+cadena.substring(9,8);			
 		}else if(cadena.length == 9 && cadena.substring(9,8) == '-' && e.which!=189){
 			imprimir = cadena.substring(8,0);		
 		}else if(cadena.length> 10){
 			 imprimir = cadena.substring(10,0);
 		} 
 		$(this).val(imprimir);
 	});
 }

// -------------------------------------------------------------
// -------------------------------------------------------------
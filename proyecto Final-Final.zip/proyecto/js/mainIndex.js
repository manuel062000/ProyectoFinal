
$(document).ready(function() {
	$("#visualizarContra").click(function() {
		if($(this).attr('class')=='far fa-eye-slash'){
			$(this).attr('class','far fa-eye');
			$("#Contra").attr('type','password');
		}else{
			$(this).attr('class','far fa-eye-slash');
			$("#Contra").attr('type','text');
		}
	});
	logiar();	
});

let logiar=()=>{
	$("#logiarse").on('click',function(){
		let correo=$("#correo").val();
		let contra=$("#Contra").val();
		$.ajax({
			url: 'php/controllers/logear/login.php',
			type: 'POST',
			data: {
				correo: correo,
				contra: contra
			}
		}).done(function(data) {
			if(data=='BIEN'){
				location.href="php/view/dashboard.php";
			}else if(data=='NO'){
				$("#validar").html('<i class="far fa-exclamation-circle"></i>&nbsp;&nbsp;¡ERROR! CORREO O CONTRASEÑA INCORRECTOS...').css({
					display: 'block',
				}).animate({height:'20px'}).delay(3000).animate({height:'0px'},function(){
					$(this).css({display: 'none',});
				});
			}else if(data=='DESACTIVADO'){
				$("#validar").html('<i class="far fa-exclamation-circle"></i>&nbsp;&nbsp;¡ERROR! NECESITA ACTIVAR EL CORREO...').css({
					display: 'block',
				}).animate({height:'20px'}).delay(3000).animate({height:'0px'},function(){
					$(this).css({display: 'none',});
				});
			}
		});		
	});	
}
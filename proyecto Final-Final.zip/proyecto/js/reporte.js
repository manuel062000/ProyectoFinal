$(document).ready(function() {
	setInterval('Actualizar()',5000);
	$.ajax({
		url: '../controllers/graficos/globales.php',
		type: 'post',
		dataType: 'json',
		success:function(data){
			var nombre=new Array(data.length);
			var total=new Array(data.length);
			for (var i = 0; i < data.length; i++) {
				nombre[i]=data[i]['nombre'];
				total[i]=parseFloat(data[i]['total']);
			}
			dibujarChar('Total votos','VOTOS EN EL SALVADOR','',nombre,total);
			activarSlider();
			showValues();
		},
	});

});
let dibujarChar=(tituloY,titulo,subtitulo,categorias,data)=>{
	// Set up the chart
	chart = new Highcharts.Chart({
	    chart: {
	        renderTo: 'container',
	        type: 'column',
	        options3d: {
	            enabled: true,
	            alpha: 15,
	            beta: 15,
	            depth: 50,
	            viewDistance: 25
	        },
	        borderWidth:1,
	        /*backgroundColor: '#FF5454',*/ //color de fondo
	    },
	    title: {
	        text: titulo
	    },
	    subtitle: {
	        text: subtitulo
	    },
	    plotOptions: {
	        column: {
	            depth: 25
	        }
	    },
	    yAxis: [{
	        title: {
	            text: '',
	            margin: 30,
	        },
	    }], 
	    xAxis: {
	    	title: {
	            text: 'PARTIDOS POLITICOS',
	             margin: 30,
	        },
	        categories: categorias,//titulos del eje x
	    },
	    series: [{
	    	name: "VOTOS",
	        data: data,
	    }]
	});
}

let showValues=()=> {
    $('#alpha-value').html(chart.options.chart.options3d.alpha);
    $('#beta-value').html(chart.options.chart.options3d.beta);
    $('#depth-value').html(chart.options.chart.options3d.depth);
}

let activarSlider=()=>{
	// Activate the sliders
	$('#sliders input').on('input change', function () {
	    chart.options.chart.options3d[this.id] = parseFloat(this.value);
	    showValues();
	    chart.redraw(false);
	});
}

let Actualizar=()=>{
	$.ajax({
		url: '../controllers/graficos/globales.php',
		type: 'post',
		dataType: 'json',
		success:function(data){
			var nombre=new Array(data.length);
			var total=new Array(data.length);
			for (var i = 0; i < data.length; i++) {
				nombre[i]=data[i]['nombre'];
				total[i]=parseFloat(data[i]['total']);
			}
			var charts= $("#container").highcharts();
			charts.xAxis[0].setCategories(nombre);
			charts.series[0].setData(total).reverse();
		},
	});
}

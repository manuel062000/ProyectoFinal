var urlLista='../controllers/Usuario/ListaUsuario.php';
var urlPaginacion='../controllers/Usuario/paginacionUsuario.php';
$(document).ready(function(){	
	guion('txt_DUI');//guin automatico al campo dui
	$("#txt_busqueda").val('');/*limpia el campo busqueda para que siempre salga vacio al iniciar*/
	let input_busqueda=$("#txt_busqueda");
	let campoImagen=$("#Mostrar_img");
	listar('');
	tipoListado(input_busqueda);
	crearPaginacion(2);
	ejecutarAccion();
	botonLimpiarBusqueda();
	ocultarCamposValidacion();
	duiUsuario();
	
});
let duiUsuario=()=>{
	$("#txt_DUI").on('keyup', function() {
		var Exp_dui=/^\d{8}-[0-9]$/;
		if(Exp_dui.test($(this).val())){
			llenarCampoDui();
		}else if($(this).val().length==0){
			$("#idpersona").val('');
			$("#validacion_dui").hide();
			$("#validacion_existe").hide();	
			$("#img_usuario").attr('src','../../images/usuario.png');
			$("#nombre_usuario").hide();
			$("#validacion_dui").hide();
			$(this).removeClass("is-invalid");
			$(this).removeClass("is-valid");
		}else if($(this).val().length>0){
			$(this).addClass("is-invalid");
			$(this).removeClass("is-valid");
			$("#idpersona").val('');
			$("#validacion_dui").hide();
			$("#validacion_existe").hide();	
			$("#img_usuario").attr('src','../../images/usuario.png');
			$("#nombre_usuario").hide();
			$("#validacion_dui").show();
		}				
	});
}
let llenarCampoDui=()=>{
	let dui=$("#txt_DUI").val();
	let idPartido=$("#id").val();
	$.ajax({
		url: '../controllers/Usuario/llenarIdPersona.php',
		type: 'post',
		dataType: 'json',
		data: {dui: dui,id: idPartido},
	}).done(function(data) {
		if(data.res=='EXISTE'){
			$("#idpersona").val('');
			$("#nombre_usuario").show();
			$("#txt_nombre_usuario").html(data.nombre);
			$("#validacion_existe").html('La persona ya es '+data.rol).fadeIn();
			$("#img_usuario").attr('src','../../images/'+data.img);
			$("#validacion_dui").hide();

			$("#txt_DUI").addClass("is-invalid");
			$("#txt_DUI").removeClass("is-valid");
		}else if(data.res=='DUI'){
			$("#idpersona").val('');
			$("#nombre_usuario").hide();
			$("#img_usuario").attr('src','../../images/usuario.png');
			$("#validacion_dui").show();
			$("#validacion_existe").hide();
			
			$("#txt_DUI").addClass("is-invalid");
			$("#txt_DUI").removeClass("is-valid");	
		}else if(data.res=='BIEN'){
			$("#idpersona").val(data.id);
			$("#txt_nombre_usuario").html(data.nombre);
			$("#nombre_usuario").show();
			$("#img_usuario").attr('src','../../images/'+data.img);
			$("#validacion_dui").hide();
			$("#validacion_existe").hide();
			
			$("#txt_DUI").addClass("is-valid");
			$("#txt_DUI").removeClass("is-invalid");
		}
	});
	
}
let ocultarCamposValidacion=()=>{/*oculta los div de validacion*/
	$("#validacion_dui").hide();
	$("#nombre_usuario").hide();
	$("#validacion_img").hide();
	$("#validacion_correo").hide();
	$("#validacion_nombre").hide();
}
/*------------CRUD----------*/
let quitarAlerta=()=>{/*quitara el mensaje de alerta al intentar crud de nuevo*/
	$("#alerta").html("");
}
let botonLimpiarBusqueda=()=>{/*limpia la busqueda al cliquiar el boton con la X*/
	$("#btn_borrar_busqueda").on("click",function(){
		if($("#txt_busqueda").val()!=''){
			listar('');
			$("#txt_busqueda").val('');
		}
	});
}
let desbloquearBoton=()=>{/*habilita el boton de guardar cambios por si se elimino y luego se quiere agregar o modificar*/
	$("#btn_guardar_cambios").removeAttr('disabled');
}
let alerta=(opcion,respuesta)=>{/*prepara el mensaje a mostrar en el header del modal*/
	let mensaje="";
	let cerrar=false;
	switch(opcion) {
		case 'editar':
			mensaje="Informacion de Usuario Modificado con Exito";
			cerrar=true;
			break;
		case 'agregar':
			mensaje="Usuario Agregado Correctamente";
			break;
		case 'eliminar':
			mensaje="Usuario Eliminado Exitosamente";
			cerrar=true;
			break;
	}
	switch(respuesta) {/*evalua distintas validaciones retornadas desde php para mostrar un mensaje en el div alerta en el  modal*/
		case 'BIEN':
			sweetalert('¡EXCELENTE!',mensaje,'success',cerrar);
			break;
		case 'ERROR':
			sweetalert('¡ERROR!','Solicitud no procesada','error',false);
			break;
		case 'IGUAL':
			sweetalert('¡ADVERTENCIA!','Ha enviado los mismos datos','warning',false);
			break;
		case 'VACIO':
			sweetalert('¡ERROR!','No puede enviar datos vacios','info',false);
			break;
		case 'DUI':
			sweetalert('¡ERROR!','El DUI ingresado ya existe en otro usuario','info',false);
			break;
		case 'USUARIOS':
			sweetalert('¡ERROR!','Solo existe un Administrador','info',false);
			break;
		case 'FECHAS':
			sweetalert('¡ERROR!','Ya no puedes alterar los dato porque faltan 3 o menos meses para las votaciones...','error',false);
			break;
	}
}
let ejecutarAccion=()=>{/*metodo que me modifica,agrega y elimina*/
	$("#btn_guardar_cambios").on("click",function(){
		/*validaciones de campos--------*/
		
		//var Exp_correo=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})+$/;
		var Exp_correo=/^\w+([\.\+\-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})+$/;
		var bandera=true;/*bandera para saber si los campos son validos TRUE=campos validos,FALSE=campos no validos*/
		if($("#txt_correo").val() == '' || !Exp_correo.test($("#txt_correo").val())
			|| $("#txt_correo").val().length>100){
			bandera=false;
			$("#validacion_correo").fadeIn();
		}else{
			$("#validacion_correo").fadeOut();
		}
		/*fin validacion de campos--------*/


		if(bandera){/*verifica que la validacion de campos este correcta*/
			let opcion=$("#opcion").val();
			let parametros=new FormData($("form")[0]);
			$.ajax({
				beforeSend: function(){
					$("#git").toggleClass('d-none');
				},
				data:parametros,
				url: '../controllers/Usuario/crudUsuario.php',
				method: 'POST',
				contentType:false,
				processData:false,
			}).done(function(data) {
				$("#git").toggleClass('d-none');
				alerta(opcion,data);
				listar($("#txt_busqueda").val());
				crearPaginacion(2);
				if(opcion=='agregar' && data=='BIEN'){
					$("#id").val("");
					$("#txt_DUI").val('');
					$("#txt_correo").val('');
					$("#idpersona").val('');
					$("#img_usuario").attr('src','../../images/usuario.png');
					$("#validacion_dui").hide();
					$("#validacion_existe").hide();
					$("#txt_DUI").removeClass("is-valid");
					$("#txt_DUI").removeClass("is-invalid");
				}else if(opcion=='eliminar' && data=='BIEN'){
					$("#btn_guardar_cambios").attr("disabled",true);
				}
			});
		}
	});	
}
/*-------------------------------------------------*/
/*-------------------------------------------------*/

/*-------------agrega los datos a los campos automaticamente------------*/
let prepararDatos=()=>{/*prepara los datos llevandolos de la tabla a los campos del modal*/
	let values=[];
	/*-- Evento boton editar --*/
	$("#table .editar").on("click",function(){
		ocultarCamposValidacion();
		values=ciclo($(this));
		$("#opcion").val("editar");
		$("#id").val(values[0]);
		$("#idpersona").val(values[1]);
		$("#img_usuario").attr('src','../../images/'+values[2]);
		$("#txt_DUI").val(values[3]).removeAttr('disabled');
		$("#txt_correo").val(values[4]).removeAttr('disabled');
		$("#txt_nombre_usuario").html(values[5]).attr("disabled",true);
		$("#txt_rol").val(values[6]).removeAttr('disabled');
		$("#nombre_usuario").show();
		$("#btn_buscar_persona").removeAttr('disabled');
		$("#validacion_dui").hide();
		$("#validacion_existe").hide();
		$("#txt_DUI").removeClass("is-valid");
		$("#txt_DUI").removeClass("is-invalid");
		$("#txt_contra").val('').removeAttr('disabled');
		cambiarTitulo("Editar Usuario");
		quitarAlerta();
		desbloquearBoton();
		$("#btn_guardar_cambios").show();
		$("#btn_guardar_cambios").html('Guardar Cambios');
	});
	/*-- Evento boton eliminar --*/
	$("#table .eliminar").on("click",function(){
		ocultarCamposValidacion();
		values=ciclo($(this));
		$("#opcion").val("eliminar");
		$("#id").val(values[0]);
		$("#idpersona").val(values[1]);
		$("#img_usuario").attr('src','../../images/'+values[2]);
		$("#txt_DUI").val(values[3]).attr("disabled",true);
		$("#txt_correo").val(values[4]).attr("disabled",true);
		$("#txt_nombre_usuario").html(values[5]).attr("disabled",true);
		$("#nombre_usuario").show();
		$("#txt_rol").val(values[6]).attr("disabled",true);
		$("#btn_buscar_persona").attr("disabled",true);
		$("#txt_img").attr("disabled",true);
		$("#validacion_dui").hide();
		$("#validacion_existe").hide();
		$("#txt_DUI").removeClass("is-valid");
		$("#txt_DUI").removeClass("is-invalid");
		$("#txt_contra").val('').attr("disabled",true);
		//-------------------		
		cambiarTitulo("Eliminar Usuario");
		quitarAlerta();
		desbloquearBoton();
		$("#btn_guardar_cambios").show();
		$("#btn_guardar_cambios").html('Eliminar');
	});
	/*-- Evento boton ver --*/
	$("#table .ver").on("click",function(){
		ocultarCamposValidacion();
		values=ciclo($(this));
		$("#opcion").val("ver");
		$("#id").val(values[0]);
		$("#idpersona").val(values[1]);
		$("#img_usuario").attr('src','../../images/'+values[2]);
		$("#txt_DUI").val(values[3]).attr("disabled",true);
		$("#txt_correo").val(values[4]).attr("disabled",true);
		$("#txt_nombre_usuario").html(values[5]).attr("disabled",true);
		$("#nombre_usuario").show();
		$("#txt_rol").val(values[6]).attr("disabled",true);
		$("#btn_buscar_persona").attr("disabled",true);
		$("#txt_img").attr("disabled",true);
		$("#validacion_dui").hide();
		$("#validacion_existe").hide();
		$("#txt_DUI").removeClass("is-valid");
		$("#txt_DUI").removeClass("is-invalid");
		$("#txt_contra").val('').attr("disabled",true);
		//-------------------		
		cambiarTitulo("Ver Usuario");
		quitarAlerta();
		desbloquearBoton();
		$("#btn_guardar_cambios").hide();
	});
	/*-- Evento boton agregar --*/
	$("#btn_insertar").on("click",function(){
		ocultarCamposValidacion();
		$("#opcion").val("agregar");
		$("#id").val('');
		$("#idpersona").val('');
		$("#txt_DUI").val('').removeAttr('disabled');
		$("#btn_buscar_persona").removeAttr('disabled');
		$("#txt_nombre").val('').removeAttr('disabled');
		$("#txt_img").val('').removeAttr('disabled');
		$("#txt_rol").removeAttr('disabled');
		$("#txt_correo").val('').removeAttr('disabled');
		$("#img_usuario").attr('src','../../images/usuario.png');
		$("#validacion_dui").hide();
		$("#validacion_existe").hide();
		$("#txt_DUI").removeClass("is-valid");
		$("#txt_DUI").removeClass("is-invalid");
		$("#txt_contra").val('').removeAttr('disabled');
		cambiarTitulo("Crear Nuevo Usuario");
		quitarAlerta();
		desbloquearBoton();
		$("#btn_guardar_cambios").show();
		$("#btn_guardar_cambios").html('Agregar');
	});
}

let cambiarTitulo=(titulo)=>{/*cambia el titulo del cuadro modal dependiendo la accion*/
	$(".modal-header .modal-title").text(titulo)
}
let ciclo=(selector)=>{/*recorre la fila de los datos que se desean hacerle crud*/
	let datos=[];
	$(selector).parents('tr').find('td').each(function(i) {
		if(i<7){/*8 significa total columnas existentes*/
			datos[i]=$(this).text();
		}else{
			return false;
		}
	});
	return datos;
}
/*-------------------------------------------------------------*/
/*-------------------------------------------------------------*/

/*------------------Listar Las Partido Politico------------------------*/

let listar=(param)=>{/*muestra los registros solicitados*/
	$.ajax({
		url: '../controllers/Usuario/ListaUsuario.php',
		method:'POST',
		data:{
			termino:param
		}
	})
	.done(function(data) {
		$("#div_tabla").html(data);
		prepararDatos();
	});	
}
let tipoListado=(input)=>{/*comprueba que registros se solicitan*/
	$(input).on("keyup",function(){
		let termino='';
		if($(this).val()!=''){
			termino=$(this).val();
		}
		listar(termino);
	});
}
/*-----------------------------------------------------------------*/
/*-----------------------------------------------------------------*/
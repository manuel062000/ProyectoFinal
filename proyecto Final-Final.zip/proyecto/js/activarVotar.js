var paginaAc=1;
var totalPaginas=0;
var primerapg=1;
var idMunicipio=1;
$(document).ready(function() {
	llenarSelect('','');
	llenarSelect('1','1');
	listar();
	crearPaginacion(2);
	$("#txt_Departamento").change(function() {/*llena el select municipio al cambiar de departamento*/
		let idDepa=$(this).val();
		llenarSelect(idDepa,'');
	});
	$("#AcVotar").on('click',function(){
		window.parent.document.location.href = "../controllers/votar/activarVotar.php";
	});
	$("#aplicar").on('click',function(){
		idMunicipio= $("#txt_municipio").val();
		paginaAc=1;
		listar();
		crearPaginacion(4);
		$("#titulo").html('LISTADO DE PERSONAS DEL MUNICIPIO DE '+$("#txt_municipio option[value="+$("#txt_municipio").val()+"]").text());
	});
});


let llenarSelect=(idDepartamento,idSeleccion)=>{/*llena el select de departamento y municipio*/
	if(idDepartamento!=''){/*llenado del municipio*/
		$.ajax({
			url: '../controllers/Persona/llenarSelect.php',
			type: 'POST',
			data:{
				idDepartamento:idDepartamento,
				idSeleccion:idSeleccion
			}
		})
		.done(function(data) {
			if(data=='ERROR'){
				$("#txt_municipio").html('');
				alert('No se encontraron municipios en el departamento selecciono');
			}
			else{
				$("#txt_municipio").html(data);
			}
		});	
	}else{/*llenado del departamento*/
		$.ajax({
			url: '../controllers/Persona/llenarSelect.php',
			type: 'POST',
			data:{
				idDepartamento:idDepartamento
			}
		})
		.done(function(data) {
			$("#txt_Departamento").html(data);
		});	
	}
}
/*------------------Listar Las Personas------------------------*/
var cambiarPagina = () => {/*cambia la paginacion de los registros*/
    $('.page-item>.page-link').stop().on('click', function(e) {
    	let pg= parseInt($(this).text());
    	if($(this).attr('id')!='Ant' && $(this).attr('id')!='sig' && $(this).text()!='...'){
	        paginaAc=pg;
			$.ajax({
	            url: '../controllers/votar/ListaPersona.php',
	            method: 'POST',
	            data: {
	                pagina: paginaAc,
	                idMunicipio:idMunicipio
	            },
	            success:function(data){
		            $('#div_tabla').html(data);
		            verificarPg(pg);
	            },
	        });
    	}
    });
}
var cambiarPaginaSig = () => {/*cambia la paginacion de los registros*/
    $('#sig').stop().click(function() {
    	let pg=paginaAc+1;
    	if(pg<=totalPaginas){
    		paginaAc=pg;
		    $.ajax({
		        url: '../controllers/votar/ListaPersona.php',
		        method: 'POST',
		        data: {
		            pagina: pg,
		            idMunicipio:idMunicipio
		        },
		        success: function(data){
			        $('#div_tabla').html(data);
			        verificarPg(pg);
		        },
		    });
    	}
    	
    });
}
let verificarPg=(pg)=>{
	if(pg==primerapg+4 && pg<totalPaginas-3){//si el ultimo
	    crearPaginacion(2); 
	}
	else if(pg==primerapg && pg>4){//dubujar para atras(click en primera pg)
		crearPaginacion(5);
	}
	else if(pg==1 || pg==2 || pg==3 || pg==4){//si es de las primeras 4
		crearPaginacion(4);
	}
	else if(pg>=totalPaginas-3){//si es de los ultimos 4
		crearPaginacion(3);
	}
	else if(pg >primerapg && pg<primerapg+4){//si es de los de enmedio
		crearPaginacion(1);
	}else{
		primerapg=paginaAc-4;
		verificarPg(parseInt(pg));
	}
}
var cambiarPaginaAnt = () => {/*cambia la paginacion de los registros*/
    $('#Ant').stop().on('click', function() {
    	let pg=paginaAc-1;
    	if(paginaAc>1){
    		paginaAc=pg;
	        $.ajax({
	            url: '../controllers/votar/ListaPersona.php',
	            method: 'POST',
	            data: {
	                pagina: pg,
	                idMunicipio:idMunicipio
	            },
	            success:function(data){
		            $('#div_tabla').html(data);
		            verificarPg(pg);
	            },
	        });
    	}
    });
}
let crearPaginacion=(valor)=>{/*creacion de los botones de paginacion*/

	$.ajax({
		url: '../controllers/votar/paginacionPersona.php',
		method: 'POST',
		data:{
			idMunicipio:idMunicipio,
		}
	})
	.done(function(data) {
		$("#pagination li").remove();
		$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" id="Ant"><i class="far fa-angle-double-left"></i>&nbsp;</a></li>');				
		if(paginaAc>=5){
			$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" >1</a></li>');				
			$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" >...</a></li>');				
		}
		let con;
		totalPaginas=parseInt(data);
			if(valor == 1){//si es de los de enmedio
				con=primerapg+4;
				for (var j = primerapg; j <= totalPaginas; j++) {
					if(j<=primerapg+4){
						if(paginaAc==j){
							$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" style="background: #ffc187;">'+j+'</a></li>');
						}else{
							$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute">'+j+'</a></li>');
						}
					}
				}
			}else if(valor==2){//cuando es el ultimo
				for(var j = paginaAc; j <= data; j++) {
					if(j<paginaAc+5){
						if(paginaAc==j){
							$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" style="background: #ffc187;">'+j+'</a></li>');
						}else{
							$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute">'+j+'</a></li>');
						}
						con=j;
					}
				}
			}else if(valor==3){//que sea ultimo,penultio o antepenultimo
				con=totalPaginas;
				for (var j = totalPaginas-4; j <= totalPaginas; j++) {
					if(paginaAc==j){
						$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" style="background: #ffc187;">'+j+'</a></li>');
					}else{
						$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute">'+j+'</a></li>');
					}
				}
			}else if(valor==4){//si es de las primeras 4
				for (var j = 1; j <= data; j++) {
					if(j<=5){
						if(paginaAc==j){
							$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" style="background: #ffc187;">'+j+'</a></li>');
						}else{
							$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute">'+j+'</a></li>');
						}
						con=j;
					}
				}
			}else if(valor==5){//dubujar para atras(click en primera pg)
				for (var j = paginaAc-4; j <= data; j++) {
					if(j<=paginaAc){
						if(paginaAc==j){
							$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" style="background: #ffc187;">'+j+'</a></li>');
						}else{
							$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute">'+j+'</a></li>');
						}
						con=j;
					}
				}
			}
		if(paginaAc<totalPaginas-3){
			$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" >...</a></li>');		
			$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" >'+totalPaginas+'</a></li>');		
		}
		$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" id="sig">&nbsp;<i class="far fa-angle-double-right"></i></a></li>');				
		
		primerapg = con-4;
		cambiarPagina();
		cambiarPaginaSig();
		cambiarPaginaAnt();
	});
}
let listar=()=>{/*muestra los registros solicitados*/
	$.ajax({
		url: '../controllers/votar/ListaPersona.php',
		method:'POST',
		data:{
			idMunicipio:idMunicipio,
			pagina: paginaAc,
		},
	})
	.done(function(data) {
		$("#div_tabla").html(data);		
	});	
}
/*-----------------------------------------------------------------*/
/*-----------------------------------------------------------------*/
var contador=0;
$(document).ready(function() {
	$.ajax({
		url: '../controllers/votar/mostrarCandidatos.php',
		type: 'post',
	})
	.done(function(data) {
		$("#candidatos").html(data);
		seleccionar();
		votar();
	});

	$("#salir").on('click',function(){
		$.ajax({
			url: '../controllers/votar/cerrarSecion.php',
			type: 'post',
		})
		.done(function(data) {
			if(data=='BIEN'){
				location.href='../controllers/votar/activarVotar.php';
			}
		});
		
	});
	llenarDatos();
});

let llenarDatos=()=>{
	$.ajax({
		url: '../controllers/votar/llenarDatos.php',
		type: 'post',
		dataType: 'json',
	})
	.done(function(data) {
		if(data.fail=='fail'){
			location.href = '../controllers/votar/activarVotar.php';
		}else{
			$("#nombre").html(data.nombre);
			$("#apellido").html(data.apellido);
			$("#dui").html(data.dui);
			$("#edad").html(CalcuEdad(data.fechaNac,data.fechaAc));
			$("#jr").html(data.jr);
			$("#imagen").attr('src','../../images/'+data.img);
			$("#jrID").val(data.jrId);
			inicializar(data.nombre,data.apellido,data.genero);
			

		}
	});
	
}

let indicaciones=()=>{
	let pantalla = $(window).width();
	if(contador==0){
		var texto='';
		if(pantalla < 992){
			texto='Paso 1. En la parte inferior de la pantalla despues de tú información, tienes todas las banderas de los partidos políticos, posiciona el mouse sobre ellas y podrás ver la información de cada una, cuando sepas por cual votar solo dale click encima de la bandera'
		}else{
			 texto='Paso 1. En la parte derecha de la pantalla tienes todas las banderas de los partidos políticos, posiciona el mouse sobre ellas y podrás ver la información de cada una, cuando sepas por cual votar solo dale click encima de la bandera'
		}
			indicaciones1 = new SpeechSynthesisUtterance(texto);
			window.speechSynthesis.speak(indicaciones1);	
	}else if(contador==1){
		
		var texto2='Paso 2. Ya que has elegido el partido político, por el que votarás, dale click al botón verde que se encuentra abajo de las banderas, para realizar tu voto';
		
			indicaciones2 = new SpeechSynthesisUtterance(texto2);
			window.speechSynthesis.speak(indicaciones2);	
	}
}
let votar=()=>{
	$("#btn_votar").on('click',function(){
		let idPP=$('.info2').parents('.product-image').find('input').val();
		let idJr=$("#jrID").val();
		let dui=$("#dui").text();
		$.ajax({
			url: '../controllers/votar/ejercerVoto.php',
			type: 'post',
			data: {
				idPP: idPP,
				idJr: idJr,
				dui: dui,
			},
		})
		.done(function(data) {
			if(data=='BIEN'){
				let nombre=$("#nombre").html();
				let apellido=$("#apellido").html();
					
					swal({
					  	title: nombre+" "+apellido,
						text: "Realizo su voto con exito..",
						icon: "success",
						timer: 10000,
						confirmButtonColor:	"#FF6B5C",
             			showConfirmButton: true,
					}).then((value) => {
					  location.href = '../controllers/votar/activarVotar.php';
					});
					contador=2;
					var texto3='¡Excelente!. '+nombre+' '+apellido+', has realizado tú voto con éxito';
					speechSynthesis.cancel();
					indicaciones4 = new SpeechSynthesisUtterance(texto3);
					window.speechSynthesis.speak(indicaciones4);
			}else{
				location.href = '../controllers/votar/activarVotar.php';
			}
		});
		
	});
}
let seleccionar=()=>{
	$(".info").each(function(){
		$(this).parents('.product-image').find('.equisVotar').hide();
		$(this).on('click',function(){
			$(this).parents('.product-image').find('.equisVotar').stop().fadeIn(2000);
			$(".info2").each(function(){
				$(this).removeClass('info2');	
				$(this).parents('.product-image').find('.equisVotar').stop().fadeOut(2000);
			})
			$(this).addClass('info2');
			$("#btn_votar").attr('disabled',false);
			$("#btn_votar").attr('title','Click para votar por el partido seleccionado');
			if(contador!=1){
				var texto3='Paso 2. Ya que has elegido el partido político, por el que votarás, dale click al botón verde que se encuentra abajo de las banderas, para realizar tu voto';
				speechSynthesis.cancel();
				indicaciones3 = new SpeechSynthesisUtterance(texto3);
				window.speechSynthesis.speak(indicaciones3);
			}
			contador=1;
		});		
	});

}
let CalcuEdad=(fecha,fechaA)=>{
	let anioA=fechaA.substring(0, 4);
	let mesA=fechaA.substring(5, 7);
	let diaA=fechaA.substring(8, 10);
	let anio=fecha.substring(0, 4);
	let mes=fecha.substring(5, 7);
	let dia=fecha.substring(8, 10);
	let edad=parseInt(anioA)-parseInt(anio);
	if(parseInt(mes)>parseInt(mesA)){
		edad--;
	}else if(parseInt(mes)==parseInt(mesA) && parseInt(dia)>parseInt(diaA)){
		edad--;
	}
	return edad;
}


var urlLista='../controllers/CentroDeVotacion/ListaCentroVotacion.php';
var urlPaginacion='../controllers/CentroDeVotacion/paginacionCentroVotacion.php';
$(document).ready(function(){
	let input_busqueda=$("#txt_busqueda");
	listar('');
	tipoListado(input_busqueda);
	crearPaginacion(2);
	llenarSelect();
	ejecutarAccion();
	limpiarBusqueda();
	botonLimpiarBusqueda();
	ocultarCamposValidacion();
});

let ocultarCamposValidacion=()=>{/*oculta los div de validacion*/
	$("#validacion").hide();
}
/*------------CRUD----------*/
let quitarAlerta=()=>{/*quitara el mensaje de alerta al intentar crud de nuevo*/
	$("#alerta").html("");
}
let botonLimpiarBusqueda=()=>{/*limpia la busqueda al cliquiar el boton con la X*/
	$("#btn_borrar_busqueda").on("click",function(){
		if($("#txt_busqueda").val()!=''){
			limpiarBusqueda();
			$("#txt_busqueda").val('');
		}
	});
}
let limpiarBusqueda=()=>{/*linpiar al hacer una busqueda---agregar luego*/
	listar('');
}
let desbloquearBoton=()=>{
	$("#btn_guardar_cambios").removeAttr('disabled');
}
let alerta=(opcion,respuesta)=>{/*prepara el mensaje a mostrar*/
	let mensaje="";
	let cerrar=false;
	switch(opcion) {
		case 'editar':
			mensaje="Informacion de Centro de Votación Modificada con Exito";
			cerrar=true;
			break;
		case 'agregar':
			mensaje="Centro de Votación Agregado Correctamente";
			break;
		case 'eliminar':
			mensaje="Centro de Votación Eliminado Exitosamente";
			cerrar=true;
			break;
	}
	switch(respuesta) {
		case 'BIEN':
			sweetalert('¡EXCELENTE!',mensaje,'success',cerrar);
			break;
		case 'ERROR':
			sweetalert('¡ERROR!','Solicitud no procesada','error',false);
			break;
		case 'IGUAL':
			sweetalert('¡ADVERTENCIA!','Ha enviado los mismos datos','warning',false);
			break;
		case 'VACIO':
			sweetalert('¡ERROR!','No puede enviar datos vacios','info',false);
			break;
		case 'FECHAS':
			sweetalert('¡ERROR!','Ya no puedes alterar los dato porque faltan 3 o menos meses para las votaciones...','error',false);
			break;
	}
}

let ejecutarAccion=()=>{/*metodo que me modifica,agrega y elimina*/
	$("#btn_guardar_cambios").on("click",function(){
		let nombre=$("#txt_nombre").val();
		let opcion=$("#opcion").val();
		let idMunicipio=$("#id").val();
		let idDepartamento=$("#txt_Departamento").val();
		var exprecion=/^[A-Za-z\s]+$/;
		if(nombre == '' || !exprecion.test(nombre)){
			$("#validacion").fadeIn();
			return false;
		}else{
			$("#validacion").fadeOut();
			$.ajax({
			beforeSend: function(){
				$("#git").toggleClass('d-none');
			},
			url: '../controllers/CentroDeVotacion/crudCentroVotacion.php',
			method: 'POST',
			data:{
				opcion:opcion,
				idMunicipio:idMunicipio,
				nombre:nombre,
				idDepartamento:idDepartamento
			}
		}).done(function(data) {
			$("#git").toggleClass('d-none');
			alerta(opcion,data);
			listar($("#txt_busqueda").val());
			crearPaginacion(2);
			limpiarBusqueda();
			if(opcion=='agregar' && data=='BIEN'){
				$("#id").val("");
				$("#txt_nombre").val("");
			}else if(opcion=='eliminar' && data=='BIEN'){
				$("#btn_guardar_cambios").attr("disabled",true);				
			}
		});
		}
	});	
}
/*-------------------------------------------------*/
/*-------------------------------------------------*/

/*-------------agrega los datos a los campos automaticamente------------*/
let prepararDatos=()=>{
	let values=[];
	/*-- Evento boton editar --*/
	$("#table .editar").on("click",function(){
		ocultarCamposValidacion();
		values=ciclo($(this));
		$("#opcion").val("editar");
		$("#id").val(values[0]);
		$("#txt_nombre").val(values[3]).removeAttr('disabled');
		$("#txt_Departamento").removeAttr('disabled');
		$('select option[value="'+values[1]+'"]').attr("selected", true);	
			
		cambiarTitulo("Editar Centro De Votacion");
		quitarAlerta();
		desbloquearBoton();
		$("#btn_guardar_cambios").show();
		$("#btn_guardar_cambios").html('Guardar Cambios');
	});
	/*-- Evento boton eliminar --*/
	$("#table .eliminar").on("click",function(){
		ocultarCamposValidacion();
		values=ciclo($(this));
		$("#opcion").val("eliminar");
		$("#id").val(values[0]);
		$("#txt_nombre").val(values[3]).attr("disabled",true);
		$("#txt_Departamento").attr("disabled",true);
		$('select option[value="'+values[1]+'"]').attr("selected", true);	
			
		cambiarTitulo("Eliminar Centro De Votacion");
		quitarAlerta();
		desbloquearBoton();
		$("#btn_guardar_cambios").show();
		$("#btn_guardar_cambios").html('Eliminar');
	});
	/*-- Evento boton ver --*/
	$("#table .ver").on("click",function(){
		ocultarCamposValidacion();
		values=ciclo($(this));
		$("#opcion").val("ver");
		$("#id").val(values[0]);
		$("#txt_nombre").val(values[3]).attr("disabled",true);
		$("#txt_Departamento").attr("disabled",true);
		$('select option[value="'+values[1]+'"]').attr("selected", true);	
			
		cambiarTitulo("Ver Centro De Votacion");
		quitarAlerta();
		desbloquearBoton();
		$("#btn_guardar_cambios").hide();
	});
	/*-- Evento boton agregar --*/
	$("#btn_insertar").on("click",function(){
		ocultarCamposValidacion();
		$("#opcion").val("agregar");
		$("#id").val("");
		$("#txt_nombre").val("").removeAttr('disabled');
		$("#txt_Departamento").removeAttr('disabled');
		cambiarTitulo("Agregar Centro De Votacion");
		quitarAlerta();
		desbloquearBoton();
		$("#btn_guardar_cambios").show();
		$("#btn_guardar_cambios").html('Agregar');
	});
}
let cambiarTitulo=(titulo)=>{/*cambia el titulo del cuadro modal dependiendo la accion*/
	$(".modal-header .modal-title").text(titulo)
}
let ciclo=(selector)=>{/*recorre la fila de los datos que se desean hacerle crud*/
	let datos=[];
	$(selector).parents('tr').find('td').each(function(i) {
		if(i<5){/*6 significa total columnas existentes*/
			datos[i]=$(this).text();
		}else{
			return false;
		}
	});
	return datos;
}
let llenarSelect=()=>{/*llena el select de departamentos*/
	$.ajax({
		url: '../controllers/CentroDeVotacion/llenarSelect.php',
		type: 'POST'
	})
	.done(function(data) {
		$("#txt_Departamento").html(data);
	});	
}
/*-------------------------------------------------------------*/
/*-------------------------------------------------------------*/
 
let listar=(param)=>{/*muestra los registros solicitados*/
	$.ajax({
		url: '../controllers/CentroDeVotacion/ListaCentroVotacion.php',
		method:'POST',
		data:{
			termino:param
		}
	})
	.done(function(data) {
		$("#div_tabla").html(data);
		prepararDatos();
	});	
}
let tipoListado=(input)=>{/*comprueba que registros se solicitan*/
	$(input).on("keyup",function(){
		let termino='';
		if($(this).val()!=''){
			termino=$(this).val();
		}
		listar(termino);
	});
}
/*-----------------------------------------------------------------*/
/*-----------------------------------------------------------------*/
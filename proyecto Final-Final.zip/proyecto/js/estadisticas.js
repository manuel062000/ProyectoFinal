var idPartido = '';
var idMunicipio = '';
var idDepartamento = '';
let borrarTabla=()=>{
	$(".highcharts-data-table").remove();
}
$(document).ready(function() {
	$("label").each(function(i) {
		$(this).on('click',function(){
			$(this).parents('.form-group').find('input[type="radio"]').prop('checked',true).click();
		});
	});
	$("#p_Dep").hide();
	$("#p_Mun").hide();
	$("#p_PP").hide();
	$("#h_PP").hide();
	$("#rbn_total_per").prop('checked',true);
	// -----------------------
	$("#rbn_Mun").on('click',function(){//radio de municipio
		$("#p_Dep").stop().fadeIn(2000);
		$("#p_Mun").stop().fadeIn(2000);
		$("#p_PP").stop().fadeOut(2000);
		$("#h_PP").stop().fadeOut(2000);
	});
	$("#rbn_Dep").on('click',function(){//radio de departamento
		$("#p_Dep").stop().fadeIn(2000);
		$("#p_Mun").stop().fadeOut(2000);
		$("#p_PP").stop().fadeOut(2000);
		$("#h_PP").stop().fadeOut(2000);
	});
	$("#rbn_PP").on('click',function(){//radio de Partido Politico
		$("#p_Dep").stop().fadeOut(2000);
		$("#p_Mun").stop().fadeOut(2000);
		$("#p_PP").stop().fadeIn(2000);
		$("#h_PP").stop().fadeIn(2000);
		$("#rbn_todos").prop('checked',true);
	});
	$("#rbn_total_per").on('click',function(){//total Personas
		$("#p_Dep").stop().fadeOut(2000);
		$("#p_Mun").stop().fadeOut(2000);
		$("#p_PP").stop().fadeOut(2000);
		$("#h_PP").stop().fadeOut(2000);
	});

	$("#rbn_todos").on('click',function(){//total Personas
		$("#p_Dep").stop().fadeOut(2000);
		$("#p_Mun").stop().fadeOut(2000);
		$("#p_PP").stop().fadeIn(2000);
		$("#h_PP").stop().fadeIn(2000);
	});
	$("#rbn_Municipio").on('click',function(){//total Personas
		$("#p_Dep").stop().fadeIn(2000);
		$("#p_Mun").stop().fadeIn(2000);
		$("#p_PP").stop().fadeIn(2000);
		$("#h_PP").stop().fadeIn(2000);
	});
	$("#rbn_Departamento").on('click',function(){//total Personas
		$("#p_Dep").stop().fadeIn(2000);
		$("#p_Mun").stop().fadeOut(2000);
		$("#p_PP").stop().fadeIn(2000);
		$("#h_PP").stop().fadeIn(2000);
	});
	// -----------------------
	llenarSelect('','');
	llenarSelect('1','1');
	llenar();
	$("#txt_Departamento").change(function() {/*llena el select municipio al cambiar de departamento*/
		let idDepa=$(this).val();
		llenarSelect(idDepa,'');
	});




	crearGrafica('PERSONAS QUE HAN EJERCIDO SUFRAGIO','NIVEL NACIONAL');
	
	setInterval('Actualizar()',5000);

	$("#aplicar").on('click',function(){
		borrarTabla();
		let titulo='';
		let sub_titulo='';
		if($("#rbn_Mun").prop('checked')){
			idPartido = '';
			idMunicipio = $("#txt_Municipio").val();
			idDepartamento = '';
			titulo='VOTOS POR MUNICIPIO';
			sub_titulo='MUNICIPIO: '+$("#txt_Municipio option[value="+ $("#txt_Municipio").val()+"]").text();
		}else if($("#rbn_Dep").prop('checked')){
			idPartido = '';
			idMunicipio = '';
			idDepartamento = $("#txt_Departamento").val();
			titulo='VOTOS POR DEPARTAMENTO';
			sub_titulo='DEPARTAMENTO: '+$("#txt_Departamento option[value="+ $("#txt_Departamento").val()+"]").text();
		}else if($("#rbn_PP").prop('checked')){
			if($("#rbn_todos").prop('checked')){
				idPartido = $("#txt_PP").val();
				idMunicipio = '';
				idDepartamento = '';
				titulo='VOTOS AL PARTIDO POLITICO '+$("#txt_PP option[value = "+$("#txt_PP").val()+"]").text();
				sub_titulo='NIVEL NACIONAL';
			}else if($("#rbn_Municipio").prop('checked')){
				idPartido = $("#txt_PP").val();
				idMunicipio = $("#txt_Municipio").val();
				idDepartamento = '';
				titulo='VOTOS AL PARTIDO POLITICO '+$("#txt_PP option[value = "+$("#txt_PP").val()+"]").text();
				sub_titulo='MUNICIPIO: '+$("#txt_Municipio option[value="+ $("#txt_Municipio").val()+"]").text();
			}else if($("#rbn_Departamento").prop('checked')){
				idPartido = $("#txt_PP").val();
				idMunicipio = '';
				idDepartamento = $("#txt_Departamento").val();
				titulo='VOTOS AL PARTIDO POLITICO '+$("#txt_PP option[value = "+$("#txt_PP").val()+"]").text();
				sub_titulo='DEPARTAMENTO: '+$("#txt_Departamento option[value="+ $("#txt_Departamento").val()+"]").text();
			}
		}else if($("#rbn_total_per").prop('checked')){
			idPartido = '';
			idMunicipio = '';
			idDepartamento = '';
			titulo='PERSONAS QUE HAN EJERCIDO SUFRAGIO';
			sub_titulo='NIVEL NACIONAL';
		}

		crearGrafica(titulo,sub_titulo);
		// alert('idPartido: '+idPartido+'\nidMunicipio:'+idMunicipio+'\nidDepartamento:'+idDepartamento);
	});
});
let crearGrafica=(titulo,sub_titulo)=>{

	$.ajax({
		url: '../controllers/graficos/estadisticas.php',
		type: 'post',
		dataType: 'json',
		data: {
			idPartido: idPartido,
			idDepartamento: idDepartamento,
			idMunicipio: idMunicipio,
		},
		success:function(data){
			// let vector=new Array(2);
			let matriz=new Array(data.length);
			// alert( parseFloat(data[0]['Total']) *100/ parseFloat(data[data.length-1]['Total']) )
			for (var i = 0; i < data.length-1; i++) {
				// vector[0]=data[i]['nombre'];
				// vector[1]=( parseFloat(data[i]['Total']) *100/ parseFloat(data[data.length-1]['Total']) );
				matriz[i]=
				[
				data[i]['nombre'],
				parseFloat(truncarResultado( parseFloat(data[i]['Total']) *100/ parseFloat(data[data.length-1]['Total']) ))
				];
				// alert(vector[0])
				// alert(vector[1])
				// alert(matriz[0][0]+'   '+matriz[0][1])
			}
			// matriz[1]=['no an votado',100-matriz[0][1]];
			graficar(matriz,titulo,sub_titulo);
		}
	});
}
let graficar=(matriz,titulo,sub_titulo)=>{
	Highcharts.chart('container', {
	    chart: {
	        type: 'pie',
	        options3d: {
	            enabled: true,
	            alpha: 45,
	            beta: 0
	        },
	        borderWidth:1,
	    },
	    title: {
	        text: titulo
	    },
	    subtitle: {
	        text: 	sub_titulo,
	    },
	    tooltip: {
	        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
	    },
	    plotOptions: {
	        pie: {
	            allowPointSelect: true,
	            cursor: 'pointer',
	            depth: 35,
	            dataLabels: {
	                enabled: true,
	                format: '<b>{point.name}</b>: {point.percentage:.1f} %',
	                style: {
	                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
	                },
	                connectorColor: 'silver'
	            },
	        }
	    },
	    series: [{
	    	type: 'pie',
	        name: 'Porcentage',
	        data: matriz,
	    }]
	});
}

let Actualizar=()=>{
	$.ajax({
		url: '../controllers/graficos/estadisticas.php',
		type: 'post',
		dataType: 'json',
		data: {
			idPartido: idPartido,
			idDepartamento: idDepartamento,
			idMunicipio: idMunicipio,
		},
		success:function(data){
			let matriz=new Array(data.length);
			for (var i = 0; i < data.length-1; i++) {
				matriz[i] =
				[
				data[i]['nombre'],
				parseFloat(truncarResultado( parseFloat(data[i]['Total']) *100/ parseFloat(data[data.length-1]['Total']) ))
				];
			}
			var charts= $("#container").highcharts();
			charts.series[0].setData(matriz).reverse();
			
		},
	});
}

let llenar=()=>{
	$.ajax({
		url: '../controllers/graficos/llenarSelectPP.php',
		type: 'post',
	})
	.done(function(data) {
		if(data!='ERROR'){
			$("#txt_PP").html(data);
		}else{
			alert('error');
		}
		
	});
	
}
let llenarSelect=(idDepartamento,idSeleccion)=>{/*llena el select de departamento y municipio*/
	if(idDepartamento!=''){/*llenado del municipio*/
		$.ajax({
			url: '../controllers/Persona/llenarSelect.php',
			type: 'POST',
			data:{
				idDepartamento:idDepartamento,
				idSeleccion:idSeleccion
			}
		})
		.done(function(data) {
			if(data=='ERROR'){
				$("#txt_municipio").html('');
				$("#alerta").html
				('<div class="alert alert-danger text-center"><strong>¡ERROR!&nbsp;</strong>No existen municipios en el departamento seleccionado</div>');
			}
			else{
				$("#alerta").html('');
				$("#txt_Municipio").html(data);
			}
		});	
	}else{/*llenado del departamento*/
		$.ajax({
			url: '../controllers/Persona/llenarSelect.php',
			type: 'POST',
			data:{
				idDepartamento:idDepartamento
			}
		})
		.done(function(data) {
			$("#txt_Departamento").html(data);
		});	
	}
}

let contarDecimales=(numero)=>{
	try {
		var string= numero.toString();
		var indice = string.indexOf('.');
		return string.substring(indice+1, numero.length);
	} catch(e) {
		alert('error 6: '+ e.message);
	}
}
let truncarResultado=(resultado)=>{
	try {
		let respuesta = resultado.toString();
		let decimales = contarDecimales(resultado);
		if(decimales.length > 5 && parseFloat(decimales.substring(0, 5))==0){
			respuesta = respuesta.substring(0, respuesta.indexOf('.'));
		}else{
			respuesta = respuesta.substring(0, respuesta.indexOf('.')+4);
		}
		return respuesta;
	} catch(e) {
		alert('error 1: '+e.message);
	}
}



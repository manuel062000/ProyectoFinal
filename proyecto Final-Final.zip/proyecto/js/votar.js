
var speechSynthesisUtterance;
$(document).ready(function() {
	guion('dui');
	$("#validar").hide();
	$("#dui").on('keyup',function(){
		let exp=/^\d{8}-[0-9]$/;
		if(exp.test($(this).val())){
			$("#validar").fadeOut(1000);
			$("#logiarse").attr('disabled',false);
		}else {
			$("#validar").fadeIn(1000);
			$("#logiarse").attr('disabled',true);
		}
	});

	$("#logiarse").on('click',function(){
		let dui=$("#dui").val();
		$.ajax({
			url: '../controllers/votar/entrarVotar.php',
			type: 'post',
			data: {dui: dui},
		})
		.done(function(data) {
			if(data==1){
				$("#validarArriba").html('<i class="far fa-exclamation-circle"></i>&nbsp;&nbsp;¡ERROR! NO PUEDE VOTAR, TIENE SU DUI VENCIDO...').css({
					display: 'block',
				}).animate({height:'30px'}).delay(4000).animate({height:'0px'},function(){
					$(this).css({display: 'none',});
				});

					var texto3='¡ERROR! usted no puede votar, tiene su dúi vencido';
					speechSynthesis.cancel();
					leer3 = new SpeechSynthesisUtterance(texto3);
					window.speechSynthesis.speak(leer3);

			}else if(data==3){
				$("#validarArriba").html('<i class="far fa-exclamation-circle"></i>&nbsp;&nbsp;¡ERROR! YA EJERCIO SU VOTO...').css({
					display: 'block',
				}).animate({height:'30px'}).delay(4000).animate({height:'0px'},function(){
					$(this).css({display: 'none',});
				});
				
					var texto3='¡ERROR! usted, ya ejercío su voto';
					speechSynthesis.cancel();
					leer3 = new SpeechSynthesisUtterance(texto3);
					window.speechSynthesis.speak(leer3);
			}else if(data==2){
				location.href='ejercerVoto.php';
			}else{
				$("#validar").fadeIn(1000);
			}
		});
		
	});
	
});

let indicaciones=()=>{
		var texto='Para votar ingresa tú dúi, en la caja blanca, y luego dale click al botón rojo';
		speechSynthesisUtterance = new SpeechSynthesisUtterance(texto);
		window.speechSynthesis.speak(speechSynthesisUtterance);
		
	
}

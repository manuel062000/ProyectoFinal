var urlLista='../controllers/Persona/ListaPersona.php';
var urlPaginacion='../controllers/Persona/paginacionPersona.php';
$(document).ready(function(){
	guion('txt_DUI');//guin automatico al campo dui
	$("#txt_busqueda").val('');/*limpia el campo busqueda para que siempre salga vacio al iniciar*/
	let input_busqueda=$("#txt_busqueda");
	let campoImagen=$("#Mostrar_img");
	listar('');
	tipoListado(input_busqueda);
	crearPaginacion(2);
	llenarSelect('','');
	llenarSelect('1','1');
	ejecutarAccion();
	botonLimpiarBusqueda();
	ocultarCamposValidacion();
	$("#txt_Departamento").change(function() {/*llena el select municipio al cambiar de departamento*/
		let idDepa=$(this).val();
		llenarSelect(idDepa,'');
	});
	$("#txt_img").on('change',function(){/*preparar la vista previa de las imagenes a subir*/
		var archivos=document.getElementById("txt_img").files;
		var navegador= window.URL || window.webkitURL;

		var type=archivos[0].type;
		var name=archivos[0].name;

		if(type!='image/jpg' && type!='image/jpeg'){
			$("#validacion_img").html("Formato de imagen no valido seleccione una imagen <strong>jpg o jpeg...</strong>");
			$("#validacion_img").fadeIn();
		}else if(archivos.length > 1){
			$("#validacion_img").html("No se puede seleccionar mas de una imagen...");
			$("#validacion_img").fadeIn();
		}
		else{
			var objeto_url=navegador.createObjectURL(archivos[0]);
			$("#Mostrar_img").attr("src",objeto_url);
			$("#validacion_img").fadeOut();
		}
	});
	// cargar fecha de votacion y actual
	$.ajax({
		url: '../controllers/votar/fechaVotacion_y_Actual.php',
		type: 'post',
		dataType: 'json',
		success:function(data){
			fechaA= data.fecActual;
			fecha= data.fecVotacion;
		},
	});
});

let ocultarCamposValidacion=()=>{/*oculta los div de validacion*/
	$("#validacion_dui").hide();
	$("#validacion_img").hide();
	$("#validacion_nombre").hide();
	$("#validacion_apellido").hide();
	$("#validacion_fNac").hide();
}
/*------------CRUD----------*/
let quitarAlerta=()=>{/*quitara el mensaje de alerta al intentar crud de nuevo*/
	$("#alerta").html("");
}
let botonLimpiarBusqueda=()=>{/*limpia la busqueda al cliquiar el boton con la X*/
	$("#btn_borrar_busqueda").on("click",function(){
		if($("#txt_busqueda").val()!=''){
			listar('');
			$("#txt_busqueda").val('');
		}
	});
}
let desbloquearBoton=()=>{/*habilita el boton de guardar cambios por si se elimino y luego se quiere agregar o modificar*/
	$("#btn_guardar_cambios").removeAttr('disabled');
}
let alerta=(opcion,respuesta)=>{/*prepara el mensaje a mostrar en el header del modal*/
	let mensaje="";
	let cerrar=false;
	switch(opcion) {
		case 'editar':
			mensaje="Informacion de Persona Modificada con Exito";
			cerrar=true;
			break;
		case 'agregar':
			mensaje="Persona Agregada Correctamente";
			break;
		case 'eliminar':
			mensaje="Persona Eliminada Exitosamente";
			cerrar=true;
			break;
	}
	switch(respuesta) {/*evalua distintas validaciones retornadas desde php para mostrar un mensaje en el div alerta en el  modal*/
		case 'BIEN':
			sweetalert('¡EXCELENTE!',mensaje,'success',cerrar);
			break;
		case 'ERROR':
			sweetalert('¡ERROR!','Solicitud no procesada','error',false);
			break;
		case 'IGUAL':
			sweetalert('¡ADVERTENCIA!','Ha enviado los mismos datos','warning',false);
			break;
		case 'VACIO':
			sweetalert('¡ERROR!','No puede enviar datos vacios','info',false);
			break;
		case 'FORMATO':
			sweetalert('¡ERROR!','Formato de imagen no valido seleccionar imagen formato "jpg o jpeg"','error',false);
			break;
		case 'DUI':
			sweetalert('¡ERROR!','El DUI ingresado ya existe','error',false);
			break;
		case 'PARTIDO':
			sweetalert('¡ERROR!','La persona es candidata/o a presidente/a primero borre el partido politico','error',false);
			break;
		case 'USUARIO':
			sweetalert('¡ERROR!','La persona es un USUARIO primero eliminelo como USUARIO','error',false);
			break;
		case 'FECHAS':
			sweetalert('¡ERROR!','Ya no puedes alterar los dato porque faltan 3 o menos meses para las votaciones...','error',false);
			break;
		case 'MISMO':
			sweetalert('¡EXCELENTE!',mensaje,'success',null);
			break;
	}
}
let ejecutarAccion=()=>{/*metodo que me modifica,agrega y elimina*/
	$("#btn_guardar_cambios").on("click",function(){
		/*validaciones de campos--------*/
		
		var Exp_dui=/^\d{8}-[0-9]$/;
		var Exp_nombre=/^[A-Za-z\sñÑáéíóúÁÉÍÓÚ]+$/g;
		var Exp_apellido=/^[A-Za-z\sñÑáéíóúÁÉÍÓÚ]+$/g;
		var bandera=true;/*bandera para saber si los campos son validos TRUE=campos validos,FALSE=campos no validos*/
		if($("#txt_DUI").val() == '' || !Exp_dui.test($("#txt_DUI").val())){
			$("#validacion_dui").fadeIn();
			bandera=false;
		}else {
			$("#validacion_dui").fadeOut();
		}
		if($("#txt_nombre").val() == '' || !Exp_nombre.test($("#txt_nombre").val())){
			bandera=false;
			$("#validacion_nombre").fadeIn();
		}else{
			$("#validacion_nombre").fadeOut();
		}
		if($("#txt_apellido").val() == '' || !Exp_apellido.test($("#txt_apellido").val())){
			bandera=false;
			$("#validacion_apellido").fadeIn();
		}else{
			$("#validacion_apellido").fadeOut();
		}
		// validacion fecha nac
		
		 
		if(!fechaNacVali($("#txt_fecha_Nac").val(),fecha)){
			bandera=false;
			$("#validacion_fNac").fadeIn();
		}else{
			$("#validacion_fNac").fadeOut();
		}
		/*fin validacion de campos--------*/
		if(bandera){/*verifica que la validacion de campos este correcta*/
			let opcion=$("#opcion").val();
			let parametros=new FormData($("form")[0]);
			$.ajax({
				beforeSend: function(){
					$("#git").toggleClass('d-none');
				},
				data:parametros,
				url: '../controllers/Persona/crudPersona.php',
				method: 'POST',
				contentType:false,
				processData:false
			}).done(function(data) {
				$("#git").toggleClass('d-none');
				alerta(opcion,data);
				listar($("#txt_busqueda").val());
				crearPaginacion(2);
				if(opcion=='agregar' && data=='BIEN'){
					$("#id").val("");
					$("#txt_DUI").val('');
					$("#txt_Direccion").val('');
					$("#txt_nombre").val('');
					$("#txt_apellido").val('');
					$("#txt_fecha_Nac").val('');
					$("#txt_fecha_Exp_dui").val('');
					$("#femenino").attr("checked",false);
					$("#masculino").attr("checked",false);
					$("#Mostrar_img").attr('src','../../images/usuario.png');
					$("#txt_img").val('');
				}else if(opcion=='eliminar' && data=='BIEN'){
					$("#btn_guardar_cambios").attr("disabled",true);				
				}
			});
		}
	});	
}
/*-------------------------------------------------*/
/*-------------------------------------------------*/
let fechaNacVali=(fechaA,fecha)=>{
	anioA=fechaA.substring(0, 4);
	mesA=fechaA.substring(5, 7);
	diaA=fechaA.substring(8, 10);
	anio=fecha.substring(0, 4);
	mes=fecha.substring(5, 7);
	dia=fecha.substring(8, 10);
	if(parseInt(anioA)<parseInt(anio)-18){
		return true;
	}else{
		if(parseInt(mesA)<parseInt(mes) && parseInt(anioA)==parseInt(anio)-18){
			return true;
		}else{
			if(parseInt(diaA)<=parseInt(dia) && parseInt(anioA)==parseInt(anio)-18 && parseInt(mesA)==parseInt(mes)){
				return true;
			}else{
				return false;
			}
		}
	}
}
/*-------------agrega los datos a los campos automaticamente------------*/
let limpiarInputFile=()=>{/*borra el valor del input file*/
	var control=$("input:file");
	control.replaceWith( control = control.val('').clone( true ) );
}
let prepararDatos=()=>{/*prepara los datos llevandolos de la tabla a los campos del modal*/
	let values=[];
	/*-- Evento boton editar --*/
	$("#table .editar").on("click",function(){
		ocultarCamposValidacion();
		values=ciclo($(this));
		$("#opcion").val("editar");
		$("#id").val(values[0]);
		$("#txt_DUI").val(values[4]).removeAttr('disabled');
		$("#txt_Direccion").val(values[12]).removeAttr('disabled');
		$("#txt_nombre").val(values[5]).removeAttr('disabled');
		$("#txt_apellido").val(values[6]).removeAttr('disabled');
		$("#txt_fecha_Nac").val(values[10]).removeAttr('disabled');
		$("#txt_fecha_Exp_dui").val(values[11]).removeAttr('disabled');
		$("#txt_Departamento").removeAttr('disabled');
		$("#txt_municipio").removeAttr('disabled');
		$("#txt_nacionalidad").removeAttr('disabled');
		$("#txt_estadoCivil").removeAttr('disabled');
		$("#txt_img").val('').removeAttr('disabled');
		$("#Mostrar_img").attr('src','../../images/'+values[3]);
		//select departamento
		$('#txt_Departamento option[value="'+values[1]+'"]').attr("selected", true);			
		//select municipio
		llenarSelect($("#txt_Departamento").val(),values[2]);	
		//salvadoreño por
		if(values[14]=="NATURALIZACION"){
			$('select option[value="NATURALIZACION"]').attr("selected", true);
		}else{	
			$('select option[value="NACIMIENTO"]').attr("selected", true);
		}
		//genero
		if(values[9]=='M'){
			$("#femenino").attr("checked",false).removeAttr('disabled');
			$("#masculino").attr("checked",true).removeAttr('disabled');
		}else{
			$("#masculino").attr("checked",false).removeAttr('disabled');
			$("#femenino").attr("checked",true).removeAttr('disabled');
		}
		switch(values[13]) {
			case 'CASADO(A)':
				$('select option[value="CASADO(A)"]').attr("selected", true);
			break;
			case 'DIVORCIADO(A)':
				$('select option[value="DIVORCIADO(A)"]').attr("selected", true);
			break;
			case 'SOLTERO(A)':
				$('select option[value="SOLTERO(A)"]').attr("selected", true);
			break;
			case 'VIUDO(A)':
				$('select option[value="VIUDO(A)"]').attr("selected", true);
			break;
			case 'COMPROMETIDO(A)':
				$('select option[value="COMPROMETIDO(A)"]').attr("selected", true);
			break;
		}

		limpiarInputFile();
		cambiarTitulo("Editar Persona");
		quitarAlerta();
		desbloquearBoton();
		$("#btn_guardar_cambios").show();
		$("#btn_guardar_cambios").html('Guardar Cambios');
	});
	/*-- Evento boton eliminar --*/
	$("#table .eliminar").on("click",function(){
		ocultarCamposValidacion();
		values=ciclo($(this));
		$("#opcion").val("eliminar");
		//-------------------
		$("#id").val(values[0]);
		$("#txt_DUI").val(values[4]).attr("disabled",true);
		$("#txt_Direccion").val(values[12]).attr("disabled",true);
		$("#txt_nombre").val(values[5]).attr("disabled",true);
		$("#txt_apellido").val(values[6]).attr("disabled",true);
		$("#txt_fecha_Nac").val(values[10]).attr("disabled",true);
		$("#txt_fecha_Exp_dui").val(values[11]).attr("disabled",true);
		$("#txt_Departamento").attr("disabled",true);
		$("#txt_municipio").attr("disabled",true);
		$("#txt_nacionalidad").attr("disabled",true);
		$("#txt_estadoCivil").attr("disabled",true);
		$("#txt_img").attr("disabled",true);
		$("#Mostrar_img").attr('src','../../images/'+values[3]);
		//select departamento
		$('#txt_Departamento option[value="'+values[1]+'"]').attr("selected", true);		
		//select municipio
		llenarSelect($("#txt_Departamento").val(),values[2]);
		//salvadoreño por
		if(values[14]=="NATURALIZACION"){
			$('select option[value="NATURALIZACION"]').attr("selected", true);
		}else{	
			$('select option[value="NACIMIENTO"]').attr("selected", true);
		}
		//genero
		if(values[9]=='M'){
			$("#femenino").attr("checked",false).attr("disabled",true);
			$("#masculino").attr("checked",true).attr("disabled",true);
		}else{
			$("#masculino").attr("checked",false).attr("disabled",true);
			$("#femenino").attr("checked",true).attr("disabled",true);
		}
		switch(values[13]) {
			case 'CASADO(A)':
				$('select option[value="CASADO(A)"]').attr("selected", true);
			break;
			case 'DIVORCIADO(A)':
				$('select option[value="DIVORCIADO(A)"]').attr("selected", true);
			break;
			case 'SOLTERO(A)':
				$('select option[value="SOLTERO(A)"]').attr("selected", true);
			break;
			case 'VIUDO(A)':
				$('select option[value="VIUDO(A)"]').attr("selected", true);
			break;
			case 'COMPROMETIDO(A)':
				$('select option[value="COMPROMETIDO(A)"]').attr("selected", true);
			break;
		}
		//-------------------
		
		cambiarTitulo("Eliminar Persona");
		quitarAlerta();
		desbloquearBoton();
		$("#btn_guardar_cambios").show();
		$("#btn_guardar_cambios").html('Eliminar');
	});
	/*-- Evento boton agregar --*/
	$("#btn_insertar").on("click",function(){
		ocultarCamposValidacion();
		$("#opcion").val("agregar");
		$("#id").val("");
		$("#txt_DUI").val('').removeAttr('disabled');
		$("#txt_Direccion").val('').removeAttr('disabled');
		$("#txt_nombre").val('').removeAttr('disabled');
		$("#txt_apellido").val('').removeAttr('disabled');
		$("#txt_fecha_Nac").val('').removeAttr('disabled');
		$("#txt_fecha_Exp_dui").val('').removeAttr('disabled');
		$("#txt_Departamento").removeAttr('disabled');
		$("#txt_municipio").removeAttr('disabled');
		$("#txt_nacionalidad").removeAttr('disabled');
		$("#txt_estadoCivil").removeAttr('disabled');
		$("#txt_img").val('').removeAttr('disabled');
		$("#femenino").attr("checked",false).removeAttr('disabled');
		$("#masculino").attr("checked",false).removeAttr('disabled');
		$("#Mostrar_img").attr("src","../../images/usuario.png");
		cambiarTitulo("Crear Nueva Persona");
		quitarAlerta();
		desbloquearBoton();
		$("#btn_guardar_cambios").show();
		$("#btn_guardar_cambios").html('Agregar');
	});
	/*-- Evento boton ver --*/
	$("#table .ver").on("click",function(){
		ocultarCamposValidacion();
		values=ciclo($(this));
		$("#opcion").val("ver");
		//-------------------
		$("#id").val(values[0]);
		$("#txt_DUI").val(values[4]).attr("disabled",true);
		$("#txt_Direccion").val(values[12]).attr("disabled",true);
		$("#txt_nombre").val(values[5]).attr("disabled",true);
		$("#txt_apellido").val(values[6]).attr("disabled",true);
		$("#txt_fecha_Nac").val(values[10]).attr("disabled",true);
		$("#txt_fecha_Exp_dui").val(values[11]).attr("disabled",true);
		$("#txt_Departamento").attr("disabled",true);
		$("#txt_municipio").attr("disabled",true);
		$("#txt_nacionalidad").attr("disabled",true);
		$("#txt_estadoCivil").attr("disabled",true);
		$("#txt_img").attr("disabled",true);
		$("#Mostrar_img").attr('src','../../images/'+values[3]);
		//select departamento
		$('#txt_Departamento option[value="'+values[1]+'"]').attr("selected", true);		
		//select municipio
		llenarSelect($("#txt_Departamento").val(),values[2]);
		//salvadoreño por
		if(values[14]=="NATURALIZACION"){
			$('select option[value="NATURALIZACION"]').attr("selected", true);
		}else{	
			$('select option[value="NACIMIENTO"]').attr("selected", true);
		}
		//genero
		if(values[9]=='M'){
			$("#femenino").attr("checked",false).attr("disabled",true);
			$("#masculino").attr("checked",true).attr("disabled",true);
		}else{
			$("#masculino").attr("checked",false).attr("disabled",true);
			$("#femenino").attr("checked",true).attr("disabled",true);
		}
		switch(values[13]) {
			case 'CASADO(A)':
				$('select option[value="CASADO(A)"]').attr("selected", true);
			break;
			case 'DIVORCIADO(A)':
				$('select option[value="DIVORCIADO(A)"]').attr("selected", true);
			break;
			case 'SOLTERO(A)':
				$('select option[value="SOLTERO(A)"]').attr("selected", true);
			break;
			case 'VIUDO(A)':
				$('select option[value="VIUDO(A)"]').attr("selected", true);
			break;
			case 'COMPROMETIDO(A)':
				$('select option[value="COMPROMETIDO(A)"]').attr("selected", true);
			break;
		}
		//-------------------
		
		cambiarTitulo("Ver Persona");
		quitarAlerta();
		desbloquearBoton();
		$("#btn_guardar_cambios").hide();		
	});
}

let cambiarTitulo=(titulo)=>{/*cambia el titulo del cuadro modal dependiendo la accion*/
	$(".modal-header .modal-title").text(titulo)
}
let ciclo=(selector)=>{/*recorre la fila de los datos que se desean hacerle crud*/
	let datos=[];
	$(selector).parents('tr').find('td').each(function(i) {
		if(i<15){/*15 significa total columnas existentes*/
			datos[i]=$(this).text();
		}else{
			return false;
		}
	});
	return datos;
}
let llenarSelect=(idDepartamento,idSeleccion)=>{/*llena el select de departamento y municipio*/
	if(idDepartamento!=''){/*llenado del municipio*/
		$.ajax({
			url: '../controllers/Persona/llenarSelect.php',
			type: 'POST',
			data:{
				idDepartamento:idDepartamento,
				idSeleccion:idSeleccion
			}
		})
		.done(function(data) {
			if(data=='ERROR'){
				$("#txt_municipio").html('');
				$("#alerta").html
				('<div class="alert alert-danger text-center"><strong>¡ERROR!&nbsp;</strong>No existen municipios en el departamento seleccionado</div>');
			}
			else{
				$("#alerta").html('');
				$("#txt_municipio").html(data);
			}
		});	
	}else{/*llenado del departamento*/
		$.ajax({
			url: '../controllers/Persona/llenarSelect.php',
			type: 'POST',
			data:{
				idDepartamento:idDepartamento
			}
		})
		.done(function(data) {
			$("#txt_Departamento").html(data);
		});	
	}
}
/*-------------------------------------------------------------*/
/*-------------------------------------------------------------*/

/*------------------Listar Las Personas------------------------*/

let listar=(param)=>{/*muestra los registros solicitados*/
	$.ajax({
		url: '../controllers/Persona/ListaPersona.php',
		method:'POST',
		data:{
			termino:param
		}
	})
	.done(function(data) {
		$("#div_tabla").html(data);
		prepararDatos();
	});	
}
let tipoListado=(input)=>{/*comprueba que registros se solicitan*/
	$(input).on("keyup",function(){
		let termino='';
		if($(this).val()!=''){
			termino=$(this).val();
		}
		listar(termino);
	});
}
/*-----------------------------------------------------------------*/
/*-----------------------------------------------------------------*/
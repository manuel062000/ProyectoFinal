var urlLista='../controllers/historial/Lista.php';
var urlPaginacion='../controllers/historial/paginacion.php';
var tabla=1;
var paginaAc=1;
var totalPaginas=0;
var primerapg=1;
$(document).ready(function() {
	listar('');

	tipoListado($("#txt_busqueda"));
	crearPaginacion(2);
	$("#aplicar").on('click',function(){
		tabla= $("#txt_tabla").val();
		paginaAc=1;
		listar();
		crearPaginacion(4);
		
	});

	$("label").each(function(i) {
		$(this).on('click',function(){
			$(this).parents('.form-group').find('input[type="radio"]').prop('checked',true).click();			
		});
	});
	$("#rbn_CV").on('click',function(){//radio de Partido Politico
		$("#txt_tabla").val('1');
	});
	$("#rbn_JRr").on('click',function(){//total Personas
		$("#txt_tabla").val('2');
	});
	$("#rbn_Per").on('click',function(){//total Personas
		$("#txt_tabla").val('3');
	});

	$("#rbn_PP").on('click',function(){//total Personas
		$("#txt_tabla").val('4');
	});
	$("#rbn_Us").on('click',function(){//total Personas
		$("#txt_tabla").val('5');
	});
	botonLimpiarBusqueda();
});

let botonLimpiarBusqueda=()=>{/*limpia la busqueda al cliquiar el boton con la X*/
	$("#btn_borrar_busqueda").on("click",function(){
		if($("#txt_busqueda").val()!=''){
			listar('');
			$("#txt_busqueda").val('');
		}
	});
}

/*------------------Listar Las Personas------------------------*/
var cambiarPagina = () => {/*cambia la paginacion de los registros*/
    $('.page-item>.page-link').stop().on('click', function(e) {
    	let pg= parseInt($(this).text());
    	if($(this).attr('id')!='Ant' && $(this).attr('id')!='sig' && $(this).text()!='...'){
	        paginaAc=pg;
			$.ajax({
	            url: urlLista,
	            method: 'POST',
	            data: {
	                pagina: paginaAc,
	                tabla:tabla
	            },
	            success:function(data){
		            $('#div_tabla').html(data);
		            verificarPg(pg);
	            },
	        });
    	}
    });
}
var cambiarPaginaSig = () => {/*cambia la paginacion de los registros*/
    $('#sig').stop().click(function() {
    	let pg=paginaAc+1;
    	if(pg<=totalPaginas){
    		paginaAc=pg;
		    $.ajax({
		        url: urlLista,
		        method: 'POST',
		        data: {
		            pagina: pg,
		            tabla:tabla
		        },
		        success: function(data){
			        $('#div_tabla').html(data);
			        verificarPg(pg);
		        },
		    });
    	}
    	
    });
}
let verificarPg=(pg)=>{
	if(pg==primerapg+4 && pg<totalPaginas-3){//si el ultimo
	    crearPaginacion(2); 
	}
	else if(pg==primerapg && pg>4){//dubujar para atras(click en primera pg)
		crearPaginacion(5);
	}
	else if(pg==1 || pg==2 || pg==3 || pg==4){//si es de las primeras 4
		crearPaginacion(4);
	}
	else if(pg>=totalPaginas-3){//si es de los ultimos 4
		crearPaginacion(3);
	}
	else if(pg >primerapg && pg<primerapg+4){//si es de los de enmedio
		crearPaginacion(1);
	}else{
		primerapg=paginaAc-4;
		verificarPg(parseInt(pg));
	}
}
var cambiarPaginaAnt = () => {/*cambia la paginacion de los registros*/
    $('#Ant').stop().on('click', function() {
    	let pg=paginaAc-1;
    	if(paginaAc>1){
    		paginaAc=pg;
	        $.ajax({
	            url: urlLista,
	            method: 'POST',
	            data: {
	                pagina: pg,
	                tabla:tabla
	            },
	            success:function(data){
		            $('#div_tabla').html(data);
		            verificarPg(pg);
	            },
	        });
    	}
    });
}
let crearPaginacion=(valor)=>{/*creacion de los botones de paginacion*/

	$.ajax({
		url: urlPaginacion,
		method: 'POST',
		data:{
			parametro:tabla,
		}
	})
	.done(function(data) {
		$("#pagination li").remove();
		$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" id="Ant"><i class="far fa-angle-double-left"></i>&nbsp;</a></li>');				
		if(paginaAc>=5){
			$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" >1</a></li>');				
			$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" >...</a></li>');				
		}
		let con;
		totalPaginas=parseInt(data);
			if(valor == 1){//si es de los de enmedio
				con=primerapg+4;
				for (var j = primerapg; j <= totalPaginas; j++) {
					if(j<=primerapg+4){
						if(paginaAc==j){
							$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" style="background: #ffc187;">'+j+'</a></li>');
						}else{
							$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute">'+j+'</a></li>');
						}
					}
				}
			}else if(valor==2){//cuando es el ultimo
				for(var j = paginaAc; j <= data; j++) {
					if(j<paginaAc+5){
						if(paginaAc==j){
							$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" style="background: #ffc187;">'+j+'</a></li>');
						}else{
							$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute">'+j+'</a></li>');
						}
						con=j;
					}
				}
			}else if(valor==3){//que sea ultimo,penultio o antepenultimo
				con=totalPaginas;
				for (var j = totalPaginas-4; j <= totalPaginas; j++) {
					if(paginaAc==j){
						$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" style="background: #ffc187;">'+j+'</a></li>');
					}else{
						$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute">'+j+'</a></li>');
					}
				}
			}else if(valor==4){//si es de las primeras 4
				for (var j = 1; j <= data; j++) {
					if(j<=5){
						if(paginaAc==j){
							$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" style="background: #ffc187;">'+j+'</a></li>');
						}else{
							$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute">'+j+'</a></li>');
						}
						con=j;
					}
				}
			}else if(valor==5){//dubujar para atras(click en primera pg)
				for (var j = paginaAc-4; j <= data; j++) {
					if(j<=paginaAc){
						if(paginaAc==j){
							$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" style="background: #ffc187;">'+j+'</a></li>');
						}else{
							$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute">'+j+'</a></li>');
						}
						con=j;
					}
				}
			}
		if(paginaAc<totalPaginas-3){
			$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" >...</a></li>');		
			$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" >'+totalPaginas+'</a></li>');		
		}
		$("#pagination").append('<li class="page-item"><a href="#" class="page-link text-mute" id="sig">&nbsp;<i class="far fa-angle-double-right"></i></a></li>');				
		
		primerapg = con-4;
		cambiarPagina();
		cambiarPaginaSig();
		cambiarPaginaAnt();
	});
}

/*-----------------------------------------------------------------*/
/*-----------------------------------------------------------------*/
let listar=(param)=>{/*muestra los registros solicitados*/
	$.ajax({
		url: '../controllers/historial/Lista.php',
		method:'post',
		data:{
			termino:param,
			tabla:tabla,
			pagina: paginaAc,
		}
	})
	.done(function(data) {
		$("#div_tabla").html(data);
		crearPaginacion(2);
	});	
}
let tipoListado=(input)=>{/*comprueba que registros se solicitan*/
	$(input).on("keyup",function(){
		let termino='';
		if($(this).val()!=''){
			termino=$(this).val();
		}
		listar(termino);
	});
}
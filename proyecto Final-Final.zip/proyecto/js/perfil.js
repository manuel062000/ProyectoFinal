$(document).ready(function(){
	$("#validacionC").hide();
	$("#validacion").hide();
	$.ajax({
		url: '../controllers/logear/cargarPerfil.php',
		type: 'post',
		dataType: 'json',
	}).done(function(data){
		$("#correo").html(data.c);
		$("#nombre").html(data.n);
		$("#apellido").html(data.a);
		$("#edad").html(CalcuEdad(data.fn,data.fa));
		if(data.g=='M'){
			$("#genero").html('MASCULINO');
		}else{
			$("#genero").html('FEMENINO');
		}
		$("#rol").html(data.rol);
		$("#imagen").attr('src','../../images/'+data.img);
	});

	$("#aContra").on('click',function(){
		$("#opcion").val('contra');
		$("#titulo").html('MODIFICAR CONTRASEÑA');
		$("#nCorreo").hide();
		$("#acContra").show();
		$("#nContra").show();
		$("#rContra").show();
	});
	$("#aCorreo").on('click',function(){
		$("#opcion").val('correo');
		$("#titulo").html('MODIFICAR CORREO');
		$("#nCorreo").show();
		$("#acContra").hide();
		$("#nContra").hide();
		$("#rContra").hide();
	});
	$("#btn_guardar_cambios").on('click',function(){
		let ContraAn=$("#txt_aContra").val();
		let ContraNue=$("#txt_nContra").val();
		let ContraRep=$("#txt_rContra").val();

		if(ContraNue!=ContraRep){
			$("#validacionC").fadeIn(300);
			$("#txt_nContra").addClass('is-invalid');
			$("#txt_rContra").addClass('is-invalid');
		}else {
			$("#validacionC").fadeOut(300);
			$("#txt_nContra").removeClass('is-invalid');
			$("#txt_rContra").removeClass('is-invalid');
			$.ajax({
				url: '../controllers/logear/cambiarContra.php',
				type: 'post',
				data: {
					ContraAn: ContraAn,
					ContraNue: ContraNue,
				},
			})
			.done(function(data) {
				if(data=='BIEN'){
					swal({
					  	title: "Cambio de contraseña exitoso",
						icon: "success",
						timer: 10000,
						confirmButtonColor:	"#FF6B5C",
	             		showConfirmButton: true,
					}).then((value) => {
					  $("#ventanaModal").modal('toggle');
					});
				}else if(data=='CONTRA'){
					swal({
					  	title: "Contraseña anterior incorrecta",
						icon: "warning",
						timer: 10000,
						confirmButtonColor:	"#FF6B5C",
	             		showConfirmButton: true,
					});
				}else{
					swal({
					  	title: "¡Ha ocurrido un error!",
						icon: "warning",
						timer: 10000,
						confirmButtonColor:	"#FF6B5C",
	             		showConfirmButton: true,
					});
				}
			});
		}

	});
	
});

let CalcuEdad=(fecha,fechaA)=>{
	let anioA=fechaA.substring(0, 4);
	let mesA=fechaA.substring(5, 7);
	let diaA=fechaA.substring(8, 10);
	let anio=fecha.substring(0, 4);
	let mes=fecha.substring(5, 7);
	let dia=fecha.substring(8, 10);
	let edad=parseInt(anioA)-parseInt(anio);
	if(parseInt(mes)>parseInt(mesA)){
		edad--;
	}else if(parseInt(mes)==parseInt(mesA) && parseInt(dia)>parseInt(diaA)){
		edad--;
	}
	return edad;
}